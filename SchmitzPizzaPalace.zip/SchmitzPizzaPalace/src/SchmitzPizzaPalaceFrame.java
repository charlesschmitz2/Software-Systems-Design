import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.AbstractListModel;

public class SchmitzPizzaPalaceFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblSchmitzsPizzaPalace = new JLabel("Schmitz's Pizza Palace");
	private final JLabel lblName = new JLabel("Name : ");
	private final JTextField nameTF = new JTextField();
	private final JComboBox sizeComboBox = new JComboBox();
	private final JLabel lblSize = new JLabel("Size : ");
	private final JTextArea outputTextArea = new JTextArea();
	private final JButton btnPrint = new JButton("Print");
	private final JScrollPane scrollPane = new JScrollPane();
	private final JList toppingsList = new JList();
	private final JLabel lblToppings = new JLabel("Toppings :");
	private final JScrollPane scrollPane_1 = new JScrollPane();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzPizzaPalaceFrame frame = new SchmitzPizzaPalaceFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzPizzaPalaceFrame() {
		nameTF.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		nameTF.setBounds(130, 118, 186, 32);
		nameTF.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Schmitz Pizzeria");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 689, 606);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblSchmitzsPizzaPalace.setFont(new Font("Palatino Linotype", Font.BOLD | Font.ITALIC, 23));
		lblSchmitzsPizzaPalace.setBounds(213, 42, 319, 26);
		
		contentPane.add(lblSchmitzsPizzaPalace);
		lblName.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 21));
		lblName.setBounds(17, 119, 92, 26);
		
		contentPane.add(lblName);
		
		contentPane.add(nameTF);
		sizeComboBox.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		sizeComboBox.setModel(new DefaultComboBoxModel(new String[] {"Extra-Large", "Large", "Medium", "Small", "Personal"}));
		sizeComboBox.setBounds(130, 171, 186, 26);
		
		contentPane.add(sizeComboBox);
		lblSize.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 21));
		lblSize.setBounds(17, 169, 71, 26);
		
		contentPane.add(lblSize);
		scrollPane.setBounds(370, 103, 249, 285);
		
		contentPane.add(scrollPane);
		outputTextArea.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 13));
		scrollPane.setViewportView(outputTextArea);
		btnPrint.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 21));
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnPrint_actionPerformed(e);
			}
		});
		btnPrint.setBounds(432, 418, 141, 35);
		
		contentPane.add(btnPrint);
		scrollPane_1.setBounds(152, 218, 186, 107);
		
		contentPane.add(scrollPane_1);
		scrollPane_1.setViewportView(toppingsList);
		toppingsList.setModel(new AbstractListModel() {
			String[] values = new String[] {"Pepperoni", "Sausage", "Pinapple", "Bacon", "Onions", "Mushrooms", "Olives", "Peppers", "Anchovies", "Ham"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		toppingsList.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		lblToppings.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 21));
		lblToppings.setBounds(17, 218, 114, 26);
		
		contentPane.add(lblToppings);
	}
	protected void do_btnPrint_actionPerformed(ActionEvent e) {
		outputTextArea.setText(" ");
		
		if(nameTF.getText().isEmpty()) 
		{
			outputTextArea.append("Can't process order without names");
		}//if		
		else 
		{
			outputTextArea.append("Hello, " + nameTF.getText() + "!\n");
			//getSelectedItem returns object so it is best to use to string to turn in into a string
			outputTextArea.append("You ordered a(n) " + sizeComboBox.getSelectedItem().toString() + " pizza!\n");
			outputTextArea.append("with the following toppings : \n");
			
			//send the array of toppings into an object array called toppings
			if(toppingsList.getSelectedValues().length > 0) 
			{
				Object[] toppings = toppingsList.getSelectedValues();
				for(int i = 0; i < toppings.length; i++) 
					{
					outputTextArea.append(toppings[i].toString() + "\n");
					}//for
			}//if
			else 
			{
				outputTextArea.append("No toppings selected");
			}//else
		}//else
}
}
