import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SchmitzMaskFormatFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblSsn = new JLabel("SSN : ");
	private final JFormattedTextField ssnFormattedTextField = new JFormattedTextField();
	private final JLabel lblPhoneNumber = new JLabel("Phone Number : ");
	private final JFormattedTextField phoneNumberformattedTextField = new JFormattedTextField();
	private final JLabel lblState = new JLabel("State : ");
	private final JFormattedTextField stateformattedTextField = new JFormattedTextField();
	private final JLabel lblSndPhoneNumber = new JLabel("2nd Phone Number :");
	private final JFormattedTextField sndPhoneNumberformattedTextField = new JFormattedTextField();
	//https://docs.oracle.com/javase/tutorial/uiswing/components/formattedtextfield.html is the link for site with all formatted text fields
	//define the mask
	MaskFormatter ssnMask = createFormatter("### - ## - ####");
	
	//phone number mask
	MaskFormatter phoneMask = createFormatter("( ### ) ### - ####");
	
	//two character state mask
	MaskFormatter stateMask = createFormatter("UU");
	
	//Second Phone Mask
	MaskFormatter sndPhoneMask = createFormatter("( ### ) ### - ####");
	private final JButton btnPrint = new JButton("Print");
	private final JTextArea printTextArea = new JTextArea();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzMaskFormatFrame frame = new SchmitzMaskFormatFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	//place this code after main()
	public MaskFormatter createFormatter(String s) {
	     MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(s);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	      return formatter;
	}//createFormatter
	

	/**
	 * Create the frame.
	 */
	public SchmitzMaskFormatFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Mask Formats");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 688, 597);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblSsn.setBounds(47, 59, 77, 26);
		
		contentPane.add(lblSsn);
		ssnFormattedTextField.setBounds(133, 56, 319, 29);
		//set the place holder character
		ssnMask.setPlaceholderCharacter('#');
		//install the mask
		ssnMask.install(ssnFormattedTextField);
		
		contentPane.add(ssnFormattedTextField);
		
		
		lblPhoneNumber.setBounds(47, 136, 161, 26);
		//set the place holder character
		phoneMask.setPlaceholderCharacter('#');
		//instal the mask
		phoneMask.install(phoneNumberformattedTextField);
		
		contentPane.add(lblPhoneNumber);
		phoneNumberformattedTextField.setBounds(229, 133, 223, 29);
		contentPane.add(phoneNumberformattedTextField);
		
		lblState.setBounds(47, 266, 92, 26);
		//set the place holder character
		stateMask.setPlaceholderCharacter('U');
		//install the mask
		stateMask.install(stateformattedTextField);
		
		contentPane.add(lblState);
		stateformattedTextField.setBounds(133, 264, 319, 29);
		
		contentPane.add(stateformattedTextField);
		lblSndPhoneNumber.setBounds(47, 203, 223, 26);
		
		contentPane.add(lblSndPhoneNumber);
		sndPhoneNumberformattedTextField.setBounds(254, 200, 199, 29);
		//set the place holder character
		sndPhoneMask.setPlaceholderCharacter('#');
		//Install the mask
		sndPhoneMask.install(sndPhoneNumberformattedTextField);
		
		contentPane.add(sndPhoneNumberformattedTextField);
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnPrint_actionPerformed(e);
			}
		});
		btnPrint.setBounds(168, 314, 141, 35);
		
		contentPane.add(btnPrint);
		printTextArea.setBounds(21, 379, 607, 126);
		
		contentPane.add(printTextArea);
	}
	protected void do_btnPrint_actionPerformed(ActionEvent e) {
		printTextArea.setText("");
		printTextArea.append("SSN : " + ssnFormattedTextField.getText() + "\n");
		printTextArea.append("Phone Number 1 : " + phoneNumberformattedTextField.getText() + "\n");
		printTextArea.append("Phone Number 2 : " + sndPhoneNumberformattedTextField.getText() + "\n");
		printTextArea.append("State : " + stateformattedTextField.getText());
	}
}
