import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.text.NumberFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SchmitzInputVerifiersFrame extends JFrame {

	private JPanel contentPane;
	//define the numFormat constructor 
	NumberFormat numFormat = NumberFormat.getNumberInstance();
	NumberFormat curFormat = NumberFormat.getCurrencyInstance();
	
	private final JLabel lblNum = new JLabel("Num 1 :");
	private final JLabel lblNum_1 = new JLabel("Num 2 :");
	private final JLabel lblSum = new JLabel("Sum : ");
	//update constructor call for these constructor fields to use numFormat
	private final JFormattedTextField num2FTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField num1FTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField sumFTF = new JFormattedTextField(numFormat);
	private final JLabel lblNum1Text = new JLabel("num1Text");
	private final JLabel lblNum1value = new JLabel("num1Value");
	private final JLabel lblDifference = new JLabel("Difference : ");
	private final JFormattedTextField differenceFTF = new JFormattedTextField();
	
	private double num1 = 1;
	private double num2 = 2;
	private double sum = 0;
	private double difference = 0;
	



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzInputVerifiersFrame frame = new SchmitzInputVerifiersFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzInputVerifiersFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Input Verifiers");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 687, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//setNumber of digits to show up
		numFormat.setMinimumFractionDigits(2);
		
		lblNum.setBounds(39, 99, 92, 26);
		
		contentPane.add(lblNum);
		lblNum_1.setBounds(39, 158, 92, 26);
		
		contentPane.add(lblNum_1);
		lblSum.setBounds(39, 224, 92, 26);
		
		contentPane.add(lblSum);
				
		num2FTF.setBounds(119, 155, 256, 32);
		
		//initialize the numTextFields to start at 0
		num2FTF.setValue(0);
		num2FTF.setHorizontalAlignment(SwingConstants.RIGHT);

		contentPane.add(num2FTF);
		
		num1FTF.setBounds(119, 96, 256, 32);
		
		//initialize the numTextFields to start at 0
		num1FTF.setValue(0);
		num1FTF.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(num1FTF);
		sumFTF.setBounds(119, 221, 256, 32);
		
		//initialize the numTextFields to start at 0
		sumFTF.setValue(0);
		sumFTF.setHorizontalAlignment(SwingConstants.RIGHT);

		contentPane.add(sumFTF);
		lblNum1Text.setBounds(60, 359, 132, 55);
				
		contentPane.add(lblNum1Text);
		lblNum1value.setBounds(213, 359, 167, 55);
		
		contentPane.add(lblNum1value);
		
		lblDifference.setBounds(39, 274, 132, 26);
		contentPane.add(lblDifference);
		
		differenceFTF.setBounds(157, 271, 221, 29);
		differenceFTF.setValue(0);
		differenceFTF.setHorizontalAlignment(SwingConstants.RIGHT);

		
		contentPane.add(differenceFTF);
		
		num1FTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
				do_num1FTF_propertyChange(arg0);
			}
		});
		
		num2FTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_num2FTF_propertyChange(evt);
			}
		});
		
	}
	protected void do_num1FTF_propertyChange(PropertyChangeEvent arg0) {
		//num1 = (double) num1FTF.getValue();
		sumDoer();
		difference();
				
		//lblNum1Text.setText(num1FTF.getText());
		//lblNum1value.setText(num1FTF.getValue().toString());
		
	}
	
	protected void do_num2FTF_propertyChange(PropertyChangeEvent evt) {
		sumDoer();
		difference();
	}
	
	protected void sumDoer() {
		num1 = ((Number)num1FTF.getValue()).doubleValue();
		num2 = ((Number)num2FTF.getValue()).doubleValue();
		
		sum = num1+num2;
		sumFTF.setValue(sum);
		
		if(sum < 0) {
			sumFTF.setForeground(Color.RED);
		}//if
		else {
			sumFTF.setForeground(Color.black);
		}//else
	}//sumDoer
	
	protected void difference() {
		num1 = ((Number)num1FTF.getValue()).doubleValue();
		num2 = ((Number)num2FTF.getValue()).doubleValue();
		
		difference = num1-num2;
		differenceFTF.setValue(difference);
		
		if(difference < 0) {
			differenceFTF.setForeground(Color.RED);
		}//if
		else {
			differenceFTF.setForeground(Color.black);
		}//else
	}//difference
}
