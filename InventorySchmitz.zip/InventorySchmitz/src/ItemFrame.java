
public class ItemFrame {
	//Sort Filter (ORDER BY)
		private String myItemName;
		private String myRetailPrice;
		private String myCategory;
	
	//Filter Settings (WHERE)
		private String myLessThan;
		private String myGreaterThan;
		private String myMaxRange;
		private String myMinRange;
		
	//Filter Categories (WHERE)
		private String myDairy;
		private String myMeat;
		private String myFrozen;
		private String myCanned;
		private String myProduce;
		private String myBeverage;
		private String myPaper;
		private String mySnack;
		private String myCereal;
		private String myOther;
		
		
		public ItemFrame() {
			super();
			myItemName = "";
			myRetailPrice = "";
			myCategory = "";
			
			myLessThan = "999999999";
			myGreaterThan = "0";
			myMaxRange = "999999999";
			myMinRange = "0";
			
			myDairy = "false";
			myMeat = "false";
			myFrozen = "false";
			myCanned = "false";
			myProduce = "false";
			myBeverage = "false";
			myPaper = "false";
			mySnack = "false";
			myCereal = "false";
			myOther = "false";
			
		}
		
		public ItemFrame(String myItemName, String myRetailPrice, String myCategory, String myLessThan,
				String myGreaterThan, String myMaxRange, String myMinRange, String myDairy, String myMeat, String myFrozen,
				String myCanned, String myProduce, String myBeverage, String myPaper, String mySnack, String myCereal,
				String myOther) {
			super();
			this.myItemName = myItemName;
			this.myRetailPrice = myRetailPrice;
			this.myCategory = myCategory;
			this.myLessThan = myLessThan;
			this.myGreaterThan = myGreaterThan;
			this.myMaxRange = myMaxRange;
			this.myMinRange = myMinRange;
			this.myDairy = myDairy;
			this.myMeat = myMeat;
			this.myFrozen = myFrozen;
			this.myCanned = myCanned;
			this.myProduce = myProduce;
			this.myBeverage = myBeverage;
			this.myPaper = myPaper;
			this.mySnack = mySnack;
			this.myCereal = myCereal;
			this.myOther = myOther;
		}
		
		public String getMyItemName() {
			return myItemName;
		}

		public void setMyItemName(String myItemName) {
			this.myItemName = myItemName;
		}

		public String getMyRetailPrice() {
			return myRetailPrice;
		}

		public void setMyRetailPrice(String myRetailPrice) {
			this.myRetailPrice = myRetailPrice;
		}

		public String getMyCategory() {
			return myCategory;
		}

		public void setMyCategory(String myCategory) {
			this.myCategory = myCategory;
		}

		public String getMyLessThan() {
			return myLessThan;
		}

		public void setMyLessThan(String myLessThan) {
			this.myLessThan = myLessThan;
		}

		public String getMyGreaterThan() {
			return myGreaterThan;
		}

		public void setMyGreaterThan(String myGreaterThan) {
			this.myGreaterThan = myGreaterThan;
		}

		public String getMyMaxRange() {
			return myMaxRange;
		}

		public void setMyMaxRange(String myMaxRange) {
			this.myMaxRange = myMaxRange;
		}

		public String getMyMinRange() {
			return myMinRange;
		}

		public void setMyMinRange(String myMinRange) {
			this.myMinRange = myMinRange;
		}

		public String getMyDairy() {
			return myDairy;
		}

		public void setMyDairy(String myDairy) {
			this.myDairy = myDairy;
		}

		public String getMyMeat() {
			return myMeat;
		}

		public void setMyMeat(String myMeat) {
			this.myMeat = myMeat;
		}

		public String getMyCanned() {
			return myCanned;
		}

		public void setMyCanned(String myCanned) {
			this.myCanned = myCanned;
		}

		public String getMyProduce() {
			return myProduce;
		}

		public void setMyProduce(String myProduce) {
			this.myProduce = myProduce;
		}

		public String getMyBeverage() {
			return myBeverage;
		}

		public void setMyBeverage(String myBeverage) {
			this.myBeverage = myBeverage;
		}

		public String getMyPaper() {
			return myPaper;
		}

		public void setMyPaper(String myPaper) {
			this.myPaper = myPaper;
		}

		public String getMySnack() {
			return mySnack;
		}

		public void setMySnack(String mySnack) {
			this.mySnack = mySnack;
		}

		public String getMyCereal() {
			return myCereal;
		}

		public void setMyCereal(String myCereal) {
			this.myCereal = myCereal;
		}

		public String getMyOther() {
			return myOther;
		}

		public void setMyOther(String myOther) {
			this.myOther = myOther;
		}
		
		public String getMyFrozen() {
			return myFrozen;
		}

		public void setMyFrozen(String myFrozen) {
			this.myFrozen = myFrozen;
		}

		
			
	
}
