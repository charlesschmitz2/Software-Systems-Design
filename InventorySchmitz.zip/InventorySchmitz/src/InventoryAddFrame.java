import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;

import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;

public class InventoryAddFrame extends JFrame {

	private JPanel contentPane;
	//create numFormat for money(double) inputs
		NumberFormat numFormat = NumberFormat.getNumberInstance();
	//1a. Load the driver
		private String connString = "jdbc:ucanaccess://C:/Users/Public/InventorySchmitz.accdb";
		
	private final JButton btnAdd = new JButton("Add");
	private final JTextField textFieldItemName = new JTextField();
	private final JTextField textFieldQOH = new JTextField();
	private final JTextField textFieldClerk = new JTextField();
	private final JTextField textFieldItemCategory = new JTextField();
	private final JTextField textFieldMinQuant = new JTextField();
	private final JLabel lblWelcomeToThe = new JLabel("<html><center>Welcome to the Add Item Page!<br></br>\r\nHere you can select the category of item you wish to add, then the following corresponding fields</center></html>");
	private final JButton btnCancel = new JButton("Cancel");
	private final JRadioButton rdbtnDairy = new JRadioButton("Dairy");
	private final JRadioButton rdbtnMeat = new JRadioButton("Meat");
	private final JRadioButton rdbtnCanned = new JRadioButton("Canned");
	private final JRadioButton rdbtnCereal = new JRadioButton("Cereal");
	private final JRadioButton rdbtnProduce = new JRadioButton("Produce");
	private final JRadioButton rdbtnSnack = new JRadioButton("Snack");
	private final JRadioButton rdbtnFrozen = new JRadioButton("Frozen");
	private final JRadioButton rdbtnBeverage = new JRadioButton("Beverage");
	private final JRadioButton rdbtnPaper = new JRadioButton("Paper");
	private final JRadioButton rdbtnOther = new JRadioButton("Other");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JLabel lblItemID = new JLabel("ItemID :");
	private final JLabel lblItemcategory = new JLabel("ItemCategory :");
	private final JLabel lblRetailprice = new JLabel("RetailPrice :");
	private final JLabel lblMinquant = new JLabel("MinQuant :");
	private final JLabel lblItemname = new JLabel("ItemName :");
	private final JLabel lblWholesaleprice = new JLabel("WholesalePrice :");
	private final JLabel lblQoh = new JLabel("QOH :");
	private final JLabel lblClerk = new JLabel("Clerk :");
	
	//my data is to hold the data in Item components that will be added to database 
	private final JTextField textFieldItemID = new JTextField();
	private final JTextField textFieldRetailPrice = new JTextField();
	private final JTextField textFieldWholesalePrice = new JTextField();
	

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public InventoryAddFrame() {
		textFieldWholesalePrice.setBounds(488, 388, 123, 32);
		textFieldWholesalePrice.setColumns(10);
		textFieldRetailPrice.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textFieldRetailPrice_focusLost(e);
			}
		});
		textFieldRetailPrice.setBounds(144, 463, 123, 32);
		textFieldRetailPrice.setColumns(10);
		textFieldItemID.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textFieldItemID_focusLost(e);
			}
		});
		textFieldItemID.setBounds(144, 307, 123, 32);
		textFieldItemID.setColumns(10);
		textFieldMinQuant.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textFieldMinQuant_focusLost(e);
			}
		});
		textFieldMinQuant.setBounds(144, 550, 123, 32);
		textFieldMinQuant.setColumns(10);
		textFieldItemCategory.setEditable(false);
		
		textFieldItemCategory.setBounds(144, 385, 123, 32);
		textFieldItemCategory.setColumns(10);
		textFieldClerk.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textFieldClerk_focusLost(e);
			}
		});
		textFieldClerk.setBounds(488, 546, 123, 32);
		textFieldClerk.setColumns(10);
		textFieldQOH.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textFieldQOH_focusLost(e);
			}
		});
		textFieldQOH.setBounds(488, 463, 123, 32);
		textFieldQOH.setColumns(10);
		textFieldItemName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textFieldItemName_focusLost(e);
			}
		});
		textFieldItemName.setBounds(488, 307, 123, 32);
		textFieldItemName.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Add Item to Database");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 721, 719);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnAdd_actionPerformed(e);
			}
		});
		btnAdd.setBounds(241, 603, 109, 24);
		
		contentPane.add(btnAdd);
		
		contentPane.add(textFieldItemName);
		
		contentPane.add(textFieldQOH);
		
		contentPane.add(textFieldClerk);
		
		contentPane.add(textFieldItemCategory);
		
		contentPane.add(textFieldMinQuant);
		lblWelcomeToThe.setForeground(new Color(0, 0, 0));
		lblWelcomeToThe.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		lblWelcomeToThe.setBackground(new Color(255, 255, 255));
		lblWelcomeToThe.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblWelcomeToThe.setBounds(21, 21, 653, 74);
		
		contentPane.add(lblWelcomeToThe);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnCancel_actionPerformed(e);
			}
		});
		btnCancel.setBounds(368, 603, 109, 24);
		
		contentPane.add(btnCancel);
		buttonGroup.add(rdbtnDairy);
		rdbtnDairy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnDairy_actionPerformed(e);
			}
		});
		rdbtnDairy.setBackground(new Color(204, 204, 204));
		rdbtnDairy.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnDairy.setBounds(151, 112, 91, 35);
		
		contentPane.add(rdbtnDairy);
		buttonGroup.add(rdbtnMeat);
		rdbtnMeat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnMeat_actionPerformed(e);
			}
		});
		rdbtnMeat.setBackground(new Color(204, 204, 204));
		rdbtnMeat.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnMeat.setBounds(151, 160, 85, 35);
		
		contentPane.add(rdbtnMeat);
		buttonGroup.add(rdbtnCanned);
		rdbtnCanned.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnCanned_actionPerformed(e);
			}
		});
		rdbtnCanned.setBackground(new Color(204, 204, 204));
		rdbtnCanned.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnCanned.setBounds(298, 112, 98, 35);
		
		contentPane.add(rdbtnCanned);
		buttonGroup.add(rdbtnCereal);
		rdbtnCereal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnCereal_actionPerformed(e);
			}
		});
		rdbtnCereal.setBackground(new Color(204, 204, 204));
		rdbtnCereal.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnCereal.setBounds(469, 112, 201, 35);
		
		contentPane.add(rdbtnCereal);
		buttonGroup.add(rdbtnProduce);
		rdbtnProduce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnProduce_actionPerformed(e);
			}
		});
		rdbtnProduce.setBackground(new Color(204, 204, 204));
		rdbtnProduce.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnProduce.setBounds(298, 160, 109, 35);
		
		contentPane.add(rdbtnProduce);
		buttonGroup.add(rdbtnSnack);
		rdbtnSnack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnSnack_actionPerformed(e);
			}
		});
		rdbtnSnack.setBackground(new Color(204, 204, 204));
		rdbtnSnack.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnSnack.setBounds(469, 160, 79, 35);
		
		contentPane.add(rdbtnSnack);
		buttonGroup.add(rdbtnFrozen);
		rdbtnFrozen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnFrozen_actionPerformed(e);
			}
		});
		rdbtnFrozen.setBackground(new Color(204, 204, 204));
		rdbtnFrozen.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnFrozen.setBounds(151, 208, 91, 35);
		
		contentPane.add(rdbtnFrozen);
		buttonGroup.add(rdbtnBeverage);
		rdbtnBeverage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnBeverage_actionPerformed(e);
			}
		});
		rdbtnBeverage.setBackground(new Color(204, 204, 204));
		rdbtnBeverage.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnBeverage.setBounds(298, 208, 109, 35);
		
		contentPane.add(rdbtnBeverage);
		buttonGroup.add(rdbtnPaper);
		rdbtnPaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnPaper_actionPerformed(e);
			}
		});
		rdbtnPaper.setBackground(new Color(204, 204, 204));
		rdbtnPaper.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnPaper.setBounds(469, 208, 109, 35);
		
		contentPane.add(rdbtnPaper);
		buttonGroup.add(rdbtnOther);
		rdbtnOther.setSelected(true);
		rdbtnOther.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnOther_actionPerformed(e);
			}
		});
		rdbtnOther.setBackground(new Color(204, 204, 204));
		rdbtnOther.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 16));
		rdbtnOther.setBounds(298, 256, 98, 35);
		
		contentPane.add(rdbtnOther);
		lblItemID.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblItemID.setBounds(21, 310, 92, 26);
		
		contentPane.add(lblItemID);
		lblItemcategory.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblItemcategory.setBounds(21, 388, 116, 26);
		textFieldItemCategory.setText("Other");
		
		contentPane.add(lblItemcategory);
		lblRetailprice.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblRetailprice.setBounds(21, 466, 92, 26);
		
		contentPane.add(lblRetailprice);
		lblMinquant.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblMinquant.setBounds(21, 549, 92, 26);
		
		contentPane.add(lblMinquant);
		lblItemname.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblItemname.setBounds(385, 310, 92, 26);
		
		contentPane.add(lblItemname);
		lblWholesaleprice.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblWholesaleprice.setBounds(353, 389, 124, 26);
		
		contentPane.add(lblWholesaleprice);
		lblQoh.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblQoh.setBounds(428, 467, 58, 26);
		
		contentPane.add(lblQoh);
		lblClerk.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblClerk.setBounds(425, 550, 52, 26);
		
		contentPane.add(lblClerk);
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		contentPane.add(textFieldItemID);
		
		contentPane.add(textFieldRetailPrice);
		
		contentPane.add(textFieldWholesalePrice);
	}
	protected void do_btnAdd_actionPerformed(ActionEvent e) {
		/** myData.setMyItemID(textFieldItemID.getText().trim());
		myData.setMyItemName(textFieldItemName.getText().trim());
		myData.setMyItemCategory(textFieldItemCategory.getText().trim());
		myData.setMyWholesalePrice(textFieldWholesalePrice.getText().trim());
		myData.setMyRetailPrice(textFieldRetailPrice.getText().trim());
		myData.setMyQOH(textFieldQOH.getText().trim());
		myData.setMyMinQuant(textFieldMinQuant.getText().trim());
		myData.setMyClerk(textFieldClerk.getText().trim());**/
		
		if(textFieldItemID.getText().isEmpty() || textFieldWholesalePrice.getText().isEmpty() || textFieldRetailPrice.getText().isEmpty() || textFieldItemName.getText().isEmpty() || textFieldQOH.getText().isEmpty() || textFieldMinQuant.getText().isEmpty() || textFieldClerk.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Fill Out All of the Fields Listed Below", "All Fields Need to be Filled In", JOptionPane.INFORMATION_MESSAGE);
		}
		else {
		
			//create and run a second query so that the information entered in the add frame can be added into the database
					ResultSet rs = null;
					Statement stmtSelect = null;
					Statement stmtInsert = null;
					
					try
					{
						//2. Establish the connection
							Connection conn1 = DriverManager.getConnection(connString);
							
						
						//3. Create the statement
							stmtSelect = conn1.createStatement();
							String itemId = textFieldItemID.getText().trim();
							String itemName = textFieldItemName.getText().trim();
						
							String theQuerySelect = "SELECT ItemID FROM Items WHERE ItemID = '" + itemId + "' OR ItemName = '" + itemName + "'";
							
						
							System.out.println(theQuerySelect);
							
						//4. Execute the statement
							rs = stmtSelect.executeQuery(theQuerySelect);
						
							if(rs.next()) {
								JOptionPane.showMessageDialog(this, "The ItemID and/or Name you have entered already exisits in the database", "Duplicate Entry Error", JOptionPane.ERROR_MESSAGE);
						
							}
							else {
								//2. Establish the connection
								Connection conn2 = DriverManager.getConnection(connString);
								
								//3. Create the statement
								stmtInsert = conn2.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
								
								String theQueryInsert = "INSERT INTO Items (ItemID, ItemName, ItemCategory, WholesalePrice, RetailPrice, QOH, MinQuant, Clerk) VALUES (";
								theQueryInsert  += "'" + textFieldItemID.getText().trim() + "',";
								theQueryInsert  += "'" + textFieldItemName.getText().trim() + "',";
								theQueryInsert  += "'" + textFieldItemCategory.getText().trim() + "',";
								theQueryInsert  += "'" + textFieldWholesalePrice.getText().trim() + "',";
								theQueryInsert  += "'" + textFieldRetailPrice.getText().trim() + "',";
								theQueryInsert  += "'" + textFieldQOH.getText().trim() + "',";
								theQueryInsert  += "'" + textFieldMinQuant.getText().trim() + "',";
								theQueryInsert  += "'" + textFieldClerk.getText().trim() + "')";
								
								System.out.println(theQueryInsert);
								
								if(stmtInsert.executeUpdate(theQueryInsert) != 0) {
									System.out.println("Item Inserted");
								}
								else {
									System.out.println("Item Failed to Insert");
								}
								
								conn2.close();
								
							}
							
						//6. CLose stuff
							rs.close();
							stmtSelect.close();
							stmtInsert.close();
							conn1.close();
							
							
					}//try
					catch (SQLException ex)
					{
						System.out.println("SQL Exception: " + ex.getMessage());
						System.out.println("SQL State: " + ex.getSQLState());
						System.out.println("Vendor Error: " + ex.getErrorCode());
						ex.printStackTrace();
					} //catch
			
			
					this.dispose();
					
		}//else
	}//button add
	
	protected void do_btnCancel_actionPerformed(ActionEvent e) {
		this.dispose();
	}
	protected void do_textFieldItemName_focusLost(FocusEvent e) {
		if(textFieldItemName.getText().isEmpty()) 
		{
			lblItemname.setForeground(Color.red);
		}//if
		else {
			lblItemname.setForeground(Color.black);
		}
	}//focus lost for ItemName text field
	
	protected void do_textFieldQOH_focusLost(FocusEvent e) {
		if(textFieldQOH.getText().isEmpty()) 
		{
			lblQoh.setForeground(Color.red);
		}//if
		else {
			lblQoh.setForeground(Color.black);
		}
	}//focus lost for QOH text field
	
	protected void do_textFieldMinQuant_focusLost(FocusEvent e) {
		if(textFieldMinQuant.getText().isEmpty()) 
		{
			lblMinquant.setForeground(Color.red);
		}//if
		else {
			lblMinquant.setForeground(Color.black);
		}
	}//focus lost for MinQuant text field
	
	protected void do_textFieldClerk_focusLost(FocusEvent e) {
		if(textFieldClerk.getText().isEmpty()) 
		{
			lblClerk.setForeground(Color.red);
		}//if
		else {
			lblClerk.setForeground(Color.black);
		}
	}//focus lost for Clerk text field
	
	//sets the category text field to the corresponding selected Item Category
	protected void do_rdbtnOther_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Other");
	}
	protected void do_rdbtnPaper_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Paper");
	}
	protected void do_rdbtnCereal_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Cereal");
	}
	protected void do_rdbtnSnack_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Snack");
	}
	protected void do_rdbtnCanned_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Canned");
	}
	protected void do_rdbtnProduce_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Produce");
	}
	protected void do_rdbtnMeat_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Meat");
	}
	protected void do_rdbtnDairy_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Dairy");
	}
	protected void do_rdbtnFrozen_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Frozen");
	}
	protected void do_rdbtnBeverage_actionPerformed(ActionEvent e) {
		textFieldItemCategory.setText("Beverage");
	}
	
	protected void do_textFieldRetailPrice_focusLost(FocusEvent e) {
		if(textFieldRetailPrice.getText().isEmpty()) 
		{
			lblRetailprice.setForeground(Color.red);
		}//if
		else {
			lblRetailprice.setForeground(Color.black);
		}
	}//focus lost for Clerk text field
	protected void do_textFieldItemID_focusLost(FocusEvent e) {
		if(textFieldItemID.getText().isEmpty()) 
		{
			lblItemID.setForeground(Color.red);
		}//if
		else {
			lblItemID.setForeground(Color.black);
		}
	}//focus lost for Clerk text field
	
	
}
	

