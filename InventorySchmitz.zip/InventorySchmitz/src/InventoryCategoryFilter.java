import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.border.MatteBorder;
import java.awt.Cursor;

public class InventoryCategoryFilter extends JFrame {

	private JPanel contentPane;
	private final JLabel lblwelcomeToThe = new JLabel("<html><center>Welcome to the Inventory Filter Page!<br></br>\r\nHere you can select the category of item you wish to filter the database. One or more items may be chosen</center></html>");
	private final JCheckBox chckbxMeat = new JCheckBox("Meat");
	private final JCheckBox chckbxDairy = new JCheckBox("Dairy");
	private final JCheckBox chckbxFrozen = new JCheckBox("Frozen");
	private final JCheckBox chckbxCanned = new JCheckBox("Canned");
	private final JCheckBox chckbxProduce = new JCheckBox("Produce");
	private final JCheckBox chckbxBeverage = new JCheckBox("Beverage");
	private final JCheckBox chckbxSnack = new JCheckBox("Snack");
	private final JCheckBox chckbxPaper = new JCheckBox("Paper");
	private final JCheckBox chckbxCereal = new JCheckBox("Cereal");
	private final JCheckBox chckbxOther = new JCheckBox("Other");
	private final JLabel lblPleaseSelectThe = new JLabel("<html><center>Please Select the Category Field(s) <br></br> \r\nThat You Wish to Filter The Database By : </center></html>");
	private final JLabel lblonceDesiredBoxes = new JLabel("**Once Desired Boxes Are Checked Use the Update Button to Confirm Filter Selection(s)");
	
	ItemFrame theItem = new ItemFrame();
	private final JButton btnUpdateFilter = new JButton("Update Filter");


	/**
	 * Create the frame.
	 */
	public InventoryCategoryFilter(ItemFrame myData) {
		theItem = myData;
		jbInit();
	}
	private void jbInit() {
		setTitle("Inventory Filter");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 719, 721);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblwelcomeToThe.setForeground(Color.BLACK);
		lblwelcomeToThe.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblwelcomeToThe.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		lblwelcomeToThe.setBackground(Color.WHITE);
		lblwelcomeToThe.setBounds(21, 21, 653, 74);
		
		contentPane.add(lblwelcomeToThe);
		chckbxMeat.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxMeat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxMeat_actionPerformed(e);
			}
		});
		chckbxMeat.setOpaque(false);
		chckbxMeat.setMargin(new Insets(1, 1, 1, 1));
		chckbxMeat.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxMeat.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxMeat.setBounds(21, 275, 139, 35);
		
		contentPane.add(chckbxMeat);
		chckbxDairy.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxDairy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxDairy_actionPerformed(e);
			}
		});
		chckbxDairy.setOpaque(false);
		chckbxDairy.setMargin(new Insets(1, 1, 1, 1));
		chckbxDairy.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxDairy.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxDairy.setBounds(280, 275, 127, 35);
		
		contentPane.add(chckbxDairy);
		chckbxFrozen.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxFrozen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxFrozen_actionPerformed(e);
			}
		});
		chckbxFrozen.setOpaque(false);
		chckbxFrozen.setMargin(new Insets(1, 1, 1, 1));
		chckbxFrozen.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxFrozen.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxFrozen.setBounds(494, 354, 133, 35);
		
		contentPane.add(chckbxFrozen);
		chckbxCanned.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxCanned.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxCanned_actionPerformed(e);
			}
		});
		chckbxCanned.setOpaque(false);
		chckbxCanned.setMargin(new Insets(1, 1, 1, 1));
		chckbxCanned.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxCanned.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxCanned.setBounds(35, 354, 139, 35);
		
		contentPane.add(chckbxCanned);
		chckbxProduce.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxProduce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxProduce_actionPerformed(e);
			}
		});
		chckbxProduce.setOpaque(false);
		chckbxProduce.setMargin(new Insets(1, 1, 1, 1));
		chckbxProduce.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxProduce.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxProduce.setBounds(471, 275, 185, 35);
		
		contentPane.add(chckbxProduce);
		chckbxBeverage.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxBeverage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxBeverage_actionPerformed(e);
			}
		});
		chckbxBeverage.setOpaque(false);
		chckbxBeverage.setMargin(new Insets(1, 1, 1, 1));
		chckbxBeverage.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxBeverage.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxBeverage.setBounds(295, 354, 127, 35);
		
		contentPane.add(chckbxBeverage);
		chckbxSnack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxSnack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxSnack_actionPerformed(e);
			}
		});
		chckbxSnack.setOpaque(false);
		chckbxSnack.setMargin(new Insets(1, 1, 1, 1));
		chckbxSnack.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxSnack.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxSnack.setBounds(35, 434, 133, 35);
		
		contentPane.add(chckbxSnack);
		chckbxPaper.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxPaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxPaper_actionPerformed(e);
			}
		});
		chckbxPaper.setOpaque(false);
		chckbxPaper.setMargin(new Insets(1, 1, 1, 1));
		chckbxPaper.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxPaper.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxPaper.setBounds(494, 434, 133, 35);
		
		contentPane.add(chckbxPaper);
		chckbxCereal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxCereal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxCereal_actionPerformed(e);
			}
		});
		chckbxCereal.setOpaque(false);
		chckbxCereal.setMargin(new Insets(1, 1, 1, 1));
		chckbxCereal.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxCereal.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxCereal.setBounds(270, 434, 164, 35);
		
		contentPane.add(chckbxCereal);
		chckbxOther.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		chckbxOther.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxOther_actionPerformed(e);
			}
		});
		chckbxOther.setOpaque(false);
		chckbxOther.setMargin(new Insets(1, 1, 1, 1));
		chckbxOther.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxOther.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		chckbxOther.setBounds(295, 511, 119, 35);
		
		contentPane.add(chckbxOther);
		lblPleaseSelectThe.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblPleaseSelectThe.setBounds(186, 127, 360, 47);
		
		contentPane.add(lblPleaseSelectThe);
		lblonceDesiredBoxes.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		lblonceDesiredBoxes.setBounds(35, 603, 592, 26);
		
		contentPane.add(lblonceDesiredBoxes);
		btnUpdateFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnUpdateFilter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnUpdateFilter_actionPerformed(arg0);
			}
		});
		btnUpdateFilter.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		btnUpdateFilter.setBorder(new LineBorder(null));
		btnUpdateFilter.setBackground(Color.WHITE);
		btnUpdateFilter.setBounds(267, 205, 139, 27);
		
		contentPane.add(btnUpdateFilter);
		
		//adding an if statement to check to see if a filter has already been applied and the user comes back to change the filter
		//that the previously saved data will remain checked/unchecked for each of the item selections
			if(theItem.getMyMeat()=="true") {
				chckbxMeat.setSelected(true);
			}//if
			else {
				chckbxMeat.setSelected(false);
			}//meat
			
			if(theItem.getMyDairy()=="true") {
				chckbxDairy.setSelected(true);
			}//if
			else {
				chckbxDairy.setSelected(false);
			}//dairy
			
			if(theItem.getMyFrozen()=="true") {
				chckbxFrozen.setSelected(true);
			}//if
			else {
				chckbxFrozen.setSelected(false);
			}//Frozen
			
			if(theItem.getMyCanned()=="true") {
				chckbxCanned.setSelected(true);
			}//if
			else {
				chckbxCanned.setSelected(false);
			}//Canned
			
			if(theItem.getMyBeverage()=="true") {
				chckbxBeverage.setSelected(true);
			}//if
			else {
				chckbxBeverage.setSelected(false);
			}//Beverage
			
			if(theItem.getMyProduce()=="true") {
				chckbxProduce.setSelected(true);
			}//if
			else {
				chckbxProduce.setSelected(false);
			}//Produce
			
			if(theItem.getMySnack()=="true") {
				chckbxSnack.setSelected(true);
			}//if
			else {
				chckbxSnack.setSelected(false);
			}//Snack
			
			if(theItem.getMyCereal()=="true") {
				chckbxCereal.setSelected(true);
			}//if
			else {
				chckbxCereal.setSelected(false);
			}//Cereal
			
			if(theItem.getMyPaper()=="true") {
				chckbxPaper.setSelected(true);
			}//if
			else {
				chckbxPaper.setSelected(false);
			}//Paper
			
			if(theItem.getMyOther()=="true") {
				chckbxOther.setSelected(true);
			}//if
			else {
				chckbxOther.setSelected(false);
			}//Other
	}
	protected void do_chckbxMeat_actionPerformed(ActionEvent e) {
		if(chckbxMeat.isSelected()) {
			theItem.setMyMeat("true");
		}//if
		else if(!(chckbxMeat.isSelected())) {
			theItem.setMyMeat("false");
		}//else
	}//meat check box
	
	
	protected void do_chckbxDairy_actionPerformed(ActionEvent e) {
		if(chckbxDairy.isSelected()) {
			theItem.setMyDairy("true");
		}//if
		else if(!(chckbxDairy.isSelected())){
			theItem.setMyDairy("false");
		}//else
	}//Dairy Check Box
	
	protected void do_chckbxFrozen_actionPerformed(ActionEvent e) {
		if(chckbxFrozen.isSelected()) {
			theItem.setMyFrozen("true");
		}//if
		else if(!(chckbxFrozen.isSelected())) {
			theItem.setMyFrozen("false");
		}//else
	}//Frozen Check Box
	
	protected void do_chckbxCanned_actionPerformed(ActionEvent e) {
		if(chckbxCanned.isSelected()) {
			theItem.setMyCanned("true");
		}//if
		else if(!(chckbxCanned.isSelected())) {
			theItem.setMyCanned("false");
		}//else
	}//Canned Check Box
	
	protected void do_chckbxBeverage_actionPerformed(ActionEvent e) {
		if(chckbxBeverage.isSelected()) {
			theItem.setMyBeverage("true");
		}//if
		else if(!(chckbxBeverage.isSelected())){
			theItem.setMyBeverage("false");
		}//else
	}//Beverage Check Box
	
	protected void do_chckbxProduce_actionPerformed(ActionEvent e) {
		if(chckbxProduce.isSelected()) {
			theItem.setMyProduce("true");
		}//if
		else if(!(chckbxProduce.isSelected())){
			theItem.setMyProduce("false");
		}//else
	}//Produce Check Box
	
	protected void do_chckbxSnack_actionPerformed(ActionEvent e) {
		if(chckbxSnack.isSelected()) {
			theItem.setMySnack("true");
		}//if
		else if(!(chckbxSnack.isSelected())){
			theItem.setMySnack("false");
		}//else
	}//Snack Check Box
	
	protected void do_chckbxCereal_actionPerformed(ActionEvent e) {
		if(chckbxCereal.isSelected()) {
			theItem.setMyCereal("true");
		}//if
		else if(!(chckbxCereal.isSelected())){
			theItem.setMyCereal("false");
		}//else
	}//Cereal Check Box
	
	protected void do_chckbxPaper_actionPerformed(ActionEvent e) {
		if(chckbxPaper.isSelected()) {
			theItem.setMyPaper("true");
		}//if
		else if(!(chckbxPaper.isSelected())){
			theItem.setMyPaper("false");
		}//else
	}//Paper Check Box
	
	protected void do_chckbxOther_actionPerformed(ActionEvent e) {
		if(chckbxOther.isSelected()) {
			theItem.setMyOther("true");
		}//if
		else if(!(chckbxOther.isSelected())){
			theItem.setMyOther("false");
		}//else
	}//Other Check Box
	protected void do_btnUpdateFilter_actionPerformed(ActionEvent arg0) {
		this.dispose();
	}
}
