import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import java.awt.Font;
import javax.swing.JRadioButton;
import java.awt.Cursor;
import javax.swing.ButtonGroup;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class InventoryRetailFilterFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblwelcomeToThe = new JLabel("<html><center>Welcome to the Inventory Filter Page!<br></br>\r\nHere you can select the retail price of item you wish to add filter:\r\na max, min, or range should be inputed </center></html>");
	private final JLabel lblSelectOneOf = new JLabel("Select One of the Filter Methods :");
	private final JRadioButton rdbtnMax = new JRadioButton("Greater Than");
	private final JRadioButton rdbtnMin = new JRadioButton("Less Than");
	private final JRadioButton rdbtnRange = new JRadioButton("Range");
	private final JLabel lblMaxValue = new JLabel("Please Input the Value (Items More Than This Value Will Be Displayed) :");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JTextField textFieldMax = new JTextField();
	private final JLabel lblMinVal = new JLabel("Please Input the Value (Items Less Than This Value Will be Displayed) :");
	private final JTextField textFieldMin = new JTextField();
	private final JLabel lblRange = new JLabel("Please Input the Range In Which Items Will Appear) :");
	private final JTextField textFieldMaxRange = new JTextField();
	private final JLabel lblMaxRange = new JLabel("Max Value :");
	private final JLabel lblMinRange = new JLabel("Min Value :");
	private final JTextField textFieldMinRange = new JTextField();
	private final JButton btnUpdateFilter = new JButton("Update Filter");
	
	private ItemFrame retailData;
	


	/**
	 * Create the frame.
	 */
	public InventoryRetailFilterFrame(ItemFrame myData) {
		textFieldMaxRange.setEditable(false);
		textFieldMaxRange.setVisible(false);
		textFieldMaxRange.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		textFieldMaxRange.setBounds(142, 507, 447, 43);
		textFieldMaxRange.setColumns(10);
		textFieldMax.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldMax.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		textFieldMax.setBounds(75, 294, 514, 43);
		textFieldMax.setColumns(10);
		
		retailData = myData;
		
		jbInit();
	}
	private void jbInit() {
		setBackground(new Color(204, 204, 204));
		setTitle("Inventory Filter");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 719, 721);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblwelcomeToThe.setForeground(Color.BLACK);
		lblwelcomeToThe.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblwelcomeToThe.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		lblwelcomeToThe.setBackground(Color.WHITE);
		lblwelcomeToThe.setBounds(21, 21, 653, 74);
		
		contentPane.add(lblwelcomeToThe);
		lblSelectOneOf.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblSelectOneOf.setBounds(31, 116, 397, 26);
		
		contentPane.add(lblSelectOneOf);
		buttonGroup.add(rdbtnMax);
		rdbtnMax.setSelected(true);
		rdbtnMax.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnMax_actionPerformed(e);
			}
		});
		rdbtnMax.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		rdbtnMax.setBackground(new Color(204, 204, 204));
		rdbtnMax.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		rdbtnMax.setBounds(75, 169, 146, 35);
		
		contentPane.add(rdbtnMax);
		buttonGroup.add(rdbtnMin);
		rdbtnMin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnMin_actionPerformed(e);
			}
		});
		rdbtnMin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		rdbtnMin.setBackground(new Color(204, 204, 204));
		rdbtnMin.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		rdbtnMin.setBounds(270, 169, 135, 35);
		
		contentPane.add(rdbtnMin);
		buttonGroup.add(rdbtnRange);
		rdbtnRange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnRange_actionPerformed(e);
			}
		});
		rdbtnRange.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		rdbtnRange.setBackground(new Color(204, 204, 204));
		rdbtnRange.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		rdbtnRange.setBounds(468, 169, 100, 35);
		
		contentPane.add(rdbtnRange);
		lblMaxValue.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblMaxValue.setBounds(31, 233, 607, 26);
		
		contentPane.add(lblMaxValue);
		
		contentPane.add(textFieldMax);
		lblMinVal.setVisible(false);
		lblMinVal.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblMinVal.setBounds(31, 358, 592, 26);
		
		contentPane.add(lblMinVal);
		textFieldMin.setVisible(false);
		textFieldMin.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldMin.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		textFieldMin.setEditable(false);
		textFieldMin.setColumns(10);
		textFieldMin.setBounds(75, 405, 514, 43);
		
		contentPane.add(textFieldMin);
		lblRange.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblRange.setVisible(false);
		lblRange.setBounds(31, 469, 592, 26);
		
		contentPane.add(lblRange);
		
		contentPane.add(textFieldMaxRange);
		lblMaxRange.setVisible(false);
		lblMaxRange.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblMaxRange.setBounds(29, 516, 106, 26);
		
		contentPane.add(lblMaxRange);
		lblMinRange.setVisible(false);
		lblMinRange.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		lblMinRange.setBounds(29, 577, 106, 26);
		
		contentPane.add(lblMinRange);
		textFieldMinRange.setVisible(false);
		textFieldMinRange.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 18));
		textFieldMinRange.setEditable(false);
		textFieldMinRange.setColumns(10);
		textFieldMinRange.setBounds(142, 571, 447, 43);
		
		contentPane.add(textFieldMinRange);
		btnUpdateFilter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnUpdateFilter_actionPerformed(e);
			}
		});
		btnUpdateFilter.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 18));
		btnUpdateFilter.setBounds(244, 624, 150, 26);
		
		contentPane.add(btnUpdateFilter);
	}

	//based on the choice selected specific inputs will appear and become editable and disappear when not selected
	protected void do_rdbtnMax_actionPerformed(ActionEvent e) {
		lblMaxValue.setVisible(true);
		textFieldMax.setVisible(true);
		textFieldMax.setEditable(true);
		
		lblMinVal.setVisible(false);
		textFieldMin.setVisible(false);
		textFieldMin.setEditable(false);
		
		lblRange.setVisible(false);
		textFieldMaxRange.setVisible(false);
		textFieldMaxRange.setEditable(false);
		textFieldMinRange.setVisible(false);
		textFieldMinRange.setEditable(false);
		lblMinRange.setVisible(false);
		lblMaxRange.setVisible(false);
		
	}//max radio button
	protected void do_rdbtnMin_actionPerformed(ActionEvent e) {
		lblMaxValue.setVisible(false);
		textFieldMax.setVisible(false);
		textFieldMax.setEditable(false);
		
		lblMinVal.setVisible(true);
		textFieldMin.setVisible(true);
		textFieldMin.setEditable(true);
		
		lblRange.setVisible(false);
		textFieldMaxRange.setVisible(false);
		textFieldMaxRange.setEditable(false);
		textFieldMinRange.setVisible(false);
		textFieldMinRange.setEditable(false);
		lblMinRange.setVisible(false);
		lblMaxRange.setVisible(false);		
	}//min radio button
	protected void do_rdbtnRange_actionPerformed(ActionEvent e) {
		lblMaxValue.setVisible(false);
		textFieldMax.setVisible(false);
		textFieldMax.setEditable(false);
		
		lblMinVal.setVisible(false);
		textFieldMin.setVisible(false);
		textFieldMin.setEditable(false);
		
		lblRange.setVisible(true);
		textFieldMaxRange.setVisible(true);
		textFieldMaxRange.setEditable(true);
		textFieldMinRange.setVisible(true);
		textFieldMinRange.setEditable(true);
		lblMinRange.setVisible(true);
		lblMaxRange.setVisible(true);	
	}//range radio button
	protected void do_btnUpdateFilter_actionPerformed(ActionEvent e) {
		//updating the itemFrame object using there setters so that i can process the selections back in the mainframe
		if(rdbtnMin.isSelected()) {	
			retailData.setMyLessThan(textFieldMin.getText());
		}//if
		
		if(rdbtnMax.isSelected()) {
			retailData.setMyGreaterThan(textFieldMax.getText());
		}//if
		
		if(rdbtnRange.isSelected()) {
			retailData.setMyMinRange(textFieldMinRange.getText());
			retailData.setMyMaxRange(textFieldMaxRange.getText());
		}//if
		
		//Integer Min = theDataForQuery.getMyGreaterThan();
		//Integer Max = Integer.valueOf(theDataForQuery.getMyLessThan());
		//Integer MinRange = Integer.valueOf(theDataForQuery.getMyMinRange());
		//Integer MaxRange = Integer.valueOf(theDataForQuery.getMyMaxRange());
		
		//System.out.println("The Max Value Selected : " + Max + "\nThe Min Value Selected : " + Min + "\nThe Range Values Selected : " + MinRange + "-" + MaxRange);
		
		this.dispose();
	}//update filter button
	
	
}
