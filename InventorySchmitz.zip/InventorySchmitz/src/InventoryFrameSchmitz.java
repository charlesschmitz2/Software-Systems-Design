import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.Locale;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.MatteBorder;
import javax.swing.JButton;
import java.awt.Dimension;
import javax.swing.SwingConstants;
import java.awt.Cursor;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import java.awt.Insets;
import java.awt.Component;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;

public class InventoryFrameSchmitz extends JFrame {
	
	//1a. Load the driver
	private String connString = "jdbc:ucanaccess://C:/Users/Public/InventorySchmitz.accdb";
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenu mnTools = new JMenu("Tools");
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenuItem mntmExitProgram = new JMenuItem("Exit Program");
	private final JMenuItem mntmAddItem = new JMenuItem("Add Item");
	private final JMenuItem mntmOpenHelpWindow = new JMenuItem("Open Help Window");
	private final JScrollPane scrollPane = new JScrollPane();
	private final JTable table = new JTable();
	private final JButton btnUpdateQuery = new JButton("Update Query");
	
	static ItemFrame theDataForQuery = new ItemFrame();
	
	private final JMenu mnSetSort = new JMenu("Set Sort");
	private final JMenuItem mntmName = new JMenuItem("Name");
	private final JMenuItem mntmRetailPrice = new JMenuItem("Retail Price");
	private final JMenuItem mntmCategory = new JMenuItem("Category");

	private  Integer sortNum = 0;
	private final JMenuItem mntmItemid = new JMenuItem("ItemID");
	private final JMenu mnSetFilter = new JMenu("Set Filter");
	private final JMenuItem mntmRetailPrice_1 = new JMenuItem("Retail Price");
	private final JMenuItem mntmCategory_1 = new JMenuItem("Category");
	private final JMenuItem mntmRemoveFilter = new JMenuItem("Remove Filter");
	private final JLabel lbluseUpdateQuery = new JLabel("**Use Update Query Button to Update the Elements Being Displayed After Each Selection(s)");
	private final JLabel lblonlyOneFilter = new JLabel("**Only One Filter OR Sort Can Be Selected At a Time, but a Sort Can Be Applied to a Filter");
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InventoryFrameSchmitz frame = new InventoryFrameSchmitz(theDataForQuery);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InventoryFrameSchmitz(ItemFrame myData) {
		theDataForQuery = myData;
		jbInit();
	}
	private void jbInit() {
		getContentPane().setBackground(new Color(204, 204, 204));
		setBackground(new Color(204, 204, 204));
		setTitle("Inventory Project");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 721, 719);
		menuBar.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
		
		setJMenuBar(menuBar);
		mnFile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mnFile.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		
		menuBar.add(mnFile);
		mntmExitProgram.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmExitProgram.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		mntmExitProgram.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmExitProgram_actionPerformed(arg0);
			}
		});
		
		mnFile.add(mntmExitProgram);
		mnTools.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mnTools.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		
		menuBar.add(mnTools);
		mntmAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmAddItem_actionPerformed(arg0);
			}
		});
		mntmAddItem.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmAddItem.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnTools.add(mntmAddItem);
		mnSetSort.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mnSetSort.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnTools.add(mnSetSort);
		mntmName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmName_actionPerformed(e);
			}
		});
		mntmName.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmName.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnSetSort.add(mntmName);
		mntmRetailPrice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmRetailPrice_actionPerformed(e);
			}
		});
		mntmRetailPrice.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmRetailPrice.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnSetSort.add(mntmRetailPrice);
		mntmCategory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmCategory_actionPerformed(e);
			}
		});
		mntmCategory.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmCategory.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnSetSort.add(mntmCategory);
		mntmItemid.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmItemid_actionPerformed(e);
			}
		});
		mntmItemid.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		mntmItemid.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		mnSetSort.add(mntmItemid);
		mnSetFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mnSetFilter.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnTools.add(mnSetFilter);
		mntmRetailPrice_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmRetailPrice_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmRetailPrice_1_actionPerformed(e);
			}
		});
		mntmRetailPrice_1.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnSetFilter.add(mntmRetailPrice_1);
		mntmCategory_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmCategory_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmCategory_1_actionPerformed(e);
			}
		});
		mntmCategory_1.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnSetFilter.add(mntmCategory_1);
		mntmRemoveFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmRemoveFilter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmRemoveFilter_actionPerformed(arg0);
			}
		});
		mntmRemoveFilter.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		
		mnSetFilter.add(mntmRemoveFilter);
		mnHelp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mnHelp.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		
		menuBar.add(mnHelp);
		mntmOpenHelpWindow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		mntmOpenHelpWindow.setFont(new Font("Yu Gothic UI Semilight", Font.PLAIN, 20));
		mntmOpenHelpWindow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmOpenHelpWindow_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmOpenHelpWindow);
		getContentPane().setLayout(null);
		scrollPane.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		scrollPane.setViewportBorder(null);
		scrollPane.setBounds(21, 21, 652, 420);
		
		getContentPane().add(scrollPane);
		table.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
		table.setRowMargin(5);
		table.setSelectionBackground(new Color(135, 206, 250));
		table.setGridColor(new Color(204, 204, 204));
		table.setRowHeight(25);
		table.setShowHorizontalLines(false);
		table.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		table.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		table.setForeground(new Color(0, 0, 0));
		table.setBackground(new Color(255, 255, 255));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ItemID", "ItemName", "ItemCategory", "WholesalePrice", "RetailPrice", "QOH", "MinQuant", "Clerk"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, Double.class, Double.class, Integer.class, Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(1).setPreferredWidth(85);
		table.getColumnModel().getColumn(3).setPreferredWidth(90);
		table.getColumnModel().getColumn(4).setPreferredWidth(70);
		table.getColumnModel().getColumn(5).setPreferredWidth(60);
		
		scrollPane.setViewportView(table);
		btnUpdateQuery.setBackground(new Color(255, 255, 255));
		btnUpdateQuery.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnUpdateQuery.setBorder(new LineBorder(null));
		btnUpdateQuery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnUpdateQuery_actionPerformed(arg0);
			}
		});
		btnUpdateQuery.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		btnUpdateQuery.setBounds(258, 462, 139, 27);
		
		getContentPane().add(btnUpdateQuery);
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		lbluseUpdateQuery.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 10));
		lbluseUpdateQuery.setBounds(21, 593, 592, 26);
		
		getContentPane().add(lbluseUpdateQuery);
		lblonlyOneFilter.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 10));
		lblonlyOneFilter.setBounds(21, 582, 592, 26);
		
		getContentPane().add(lblonlyOneFilter);
	}
	protected void do_mntmExitProgram_actionPerformed(ActionEvent arg0) {
		Object[] options = { "NO", "YES"};
		if(JOptionPane.showConfirmDialog(this, "<HTML><center><font='Yu Gothic Medium'>Are you Sure you Would like to Exit the Program?<br></br></font></center></HTML>", "Exit Message", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {	  	   
		    this.dispose();
		}//if that verifies user wants to close the program
	}
	protected void do_mntmOpenHelpWindow_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this, "<HTML><center><font='Yu Gothic UI Semilight' size ='4'><U><em style=\"color:red\">Help Window</em></U><br></br>Welcome to the Help Window!<br></br>Here you can find all of the information about the database and/or the inventory tracking program<br></br>The purpose of this program is to allow our clients to keep track of the inventory they offer for sale"
				+ "<br></br><br></br><U><em style=\"color:red\">Tools</em></U><br></br>The Tools Tab displays the option to add, sort, or filter through the displayed data<br></br>"
				+ "<br></br><br></br><U><em style=\"color:red\">Add Page</em></U><br></br>The Add Page allows users to input all of the necessary fields and select that the item be added to the access database.<br></br>"
				+ "In order for the entry to be inputed properly all fields must be entered and the ItemID must be unique otherwise an error will appear in the console.<br></br>"
				+ "<br></br><br></br><U><em style=\"color:red\">Sorts</em></U><br></br>The Sort Selections once chosen use the SQL ORDER BY to give the chosen field the field by which the database is displayed.<br></br>"
				+ "This can be in the case of this database, by name, retail price, category, or the default value of ItemID.<br></br>"
				+ "<br></br><br></br><U><em style=\"color:red\">Filters</em></U><br></br>The Filter Page allows user to input how they would like the database to be filtered, either by retail price or by category.<br></br>"
				+ "When filtering by retail price, users input either a greater/less than (display all values above/below this value) value or a range max value and min value(display all values BETWEEN the max and min).<br></br>"
				+ "<br></br><br></br><U><em style=\"color:red\">Updating Query</em></U><br></br>After each filter/sort has been selected, the user should press the 'Update Query' Button in order for the changes to be displayed.<br></br>"
				+ "<br></br><br></br><U><em style=\"color:red\">Credits</em></U><br></br>[Project Designed and Written by Charlie Schmitz : Charles.Schmitz2@marist.edu]<br></br><br></br></font></center></HTML>", "Help Window", JOptionPane.INFORMATION_MESSAGE);
	}
	protected void do_btnUpdateQuery_actionPerformed(ActionEvent arg0) {
		ResultSet rs = null;
		Statement stmt = null;
		
		try
		{
			//2. Establish the connection
			Connection conn = DriverManager.getConnection(connString);
			
			//3. Create the statement
			stmt = conn.createStatement();
			
			String theQuery = "SELECT ItemID, ItemName, ItemCategory, WholesalePrice, RetailPrice, QOH, MinQuant, Clerk FROM Items WHERE (1=1)";
			
			
			Double greaterThan = Double.parseDouble(theDataForQuery.getMyGreaterThan());
			Double lessThan = Double.parseDouble(theDataForQuery.getMyLessThan());
			Double maxRange = Double.parseDouble(theDataForQuery.getMyMaxRange());
			Double minRange = Double.parseDouble(theDataForQuery.getMyMinRange());
			
			
			
			//Sort through the sort selections for the query using data stored in ItemFrame
			if (greaterThan!=0) {
				theQuery += " AND (RetailPrice >= '"+theDataForQuery.getMyGreaterThan()+"')";
			}//if
			if (lessThan!=999999999) {
				theQuery += " AND (RetailPrice <= '" +theDataForQuery.getMyLessThan()+"')";
			}//if 
			if(maxRange!=999999999 && minRange!=0) {
				theQuery += " AND (RetailPrice BETWEEN '"+theDataForQuery.getMyMinRange()+"'" + " AND '" + theDataForQuery.getMyMaxRange() + "')";
			}
			
			//Sort through the category sort selection If any one of the items is selected add the AND to the 
			if(theDataForQuery.getMyMeat()=="true" || theDataForQuery.getMyDairy()=="true" || theDataForQuery.getMyFrozen()=="true" || 
					theDataForQuery.getMyCanned()=="true" || theDataForQuery.getMyProduce()=="true" || theDataForQuery.getMyBeverage()=="true"
					|| theDataForQuery.getMyPaper()=="true" || theDataForQuery.getMySnack()=="true" || theDataForQuery.getMyOther()=="true"
					|| theDataForQuery.getMyCereal()=="true") {
				theQuery += "AND ((1=0) ";
			}
			if(theDataForQuery.getMyMeat()=="true") {
				theQuery+= " OR ItemCategory = 'Meat' ";
			}
			if(theDataForQuery.getMyDairy()=="true") {
				theQuery+= " OR ItemCategory = 'Dairy' ";
			}
			if(theDataForQuery.getMyFrozen()=="true") {
				theQuery+= " OR ItemCategory = 'Frozen' ";
			}
			if(theDataForQuery.getMyCanned()=="true") {
				theQuery+= " OR ItemCategory = 'Canned' ";
			}
			if(theDataForQuery.getMyProduce()=="true") {
				theQuery+= " OR ItemCategory = 'Produce' ";
			}
			if(theDataForQuery.getMyBeverage()=="true") {
				theQuery+= " OR ItemCategory = 'Beverage' ";
			}
			if(theDataForQuery.getMyPaper()=="true") {
				theQuery+= " OR ItemCategory = 'Paper' ";
			}
			if(theDataForQuery.getMySnack()=="true") {
				theQuery+= " OR ItemCategory = 'Snack' ";
			}
			if(theDataForQuery.getMyCereal()=="true") {
				theQuery+= " OR ItemCategory = 'Cereal' ";
			}
			if(theDataForQuery.getMyOther()=="true") {
				theQuery+= " OR ItemCategory = 'Other' ";
			}
			if(theDataForQuery.getMyMeat()=="true" || theDataForQuery.getMyDairy()=="true" || theDataForQuery.getMyFrozen()=="true" || 
					theDataForQuery.getMyCanned()=="true" || theDataForQuery.getMyProduce()=="true" || theDataForQuery.getMyBeverage()=="true"
					|| theDataForQuery.getMyPaper()=="true" || theDataForQuery.getMySnack()=="true" || theDataForQuery.getMyOther()=="true"
					|| theDataForQuery.getMyCereal()=="true") {
				theQuery += ")";
			}
			
				
			
			
			//The Sort Selected corresponds to a number which is used in the IF to determine how to put Order by into the query
			if (sortNum == 0) {
				theQuery += " ORDER BY ItemID";
			}//if
			if (sortNum == 1) {
				theQuery += " ORDER BY ItemName";
			}//if
			if (sortNum == 2) {
				theQuery += " ORDER BY RetailPrice";
			}//if
			if (sortNum == 3) {
				theQuery += " ORDER BY ItemCategory";
			}//if 
			
			
			
			System.out.println(theQuery);
			
			//4. Execute the statement
			rs = stmt.executeQuery(theQuery);
			
			//5. Process the results
				//remove any previously added rows from the table
				while (table.getRowCount() > 0) {
					((DefaultTableModel) table.getModel()).removeRow(0);
				}
				
				int numColumns = rs.getMetaData().getColumnCount();
				
				while(rs.next()) {
					//create an object array to hold a single record 
					Object[] row = new Object[numColumns];
					
					//get each field in the record
					for(int i = 0; i < numColumns; i++) {
						row[i] = rs.getObject(i+1);
					}//for
					
					//insert the record into our table
					((DefaultTableModel) table.getModel()).insertRow(rs.getRow()-1, row);
				}//while
			
				//6. CLose stuff
				rs.close();
				stmt.close();
				conn.close();
				
		}//try
		catch (SQLException ex)
		{
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		} //catch
	
	}
	protected void do_mntmAddItem_actionPerformed(ActionEvent arg0) {
		InventoryAddFrame addIt = new InventoryAddFrame();
		addIt.setLocation(this.getX()+35, this.getY() + 35);
		addIt.setVisible(true);
		
		
	}
	
	//Setting the number choices depending on the sort option
	protected void do_mntmName_actionPerformed(ActionEvent e) {
		sortNum = 1;
	}
	
	protected void do_mntmRetailPrice_actionPerformed(ActionEvent e) {
		sortNum = 2;
	}
	
	protected void do_mntmCategory_actionPerformed(ActionEvent e) {
		sortNum = 3;
	}
	protected void do_mntmItemid_actionPerformed(ActionEvent e) {
		sortNum = 0;
	}
	
	//These are the filter choices for the database
	protected void do_mntmRetailPrice_1_actionPerformed(ActionEvent e) {
		InventoryRetailFilterFrame retailFilter = new InventoryRetailFilterFrame(theDataForQuery);
		retailFilter.setLocation(this.getX()+35, this.getY()+35);
		retailFilter.setVisible(true);
		
		//Clears out all the category selections when retail filter is going to be applied
		theDataForQuery.setMyMeat("false");
		theDataForQuery.setMyDairy("false");
		theDataForQuery.setMyFrozen("false");
		theDataForQuery.setMyCanned("false");
		theDataForQuery.setMyProduce("false");
		theDataForQuery.setMyBeverage("false");
		theDataForQuery.setMyPaper("false");
		theDataForQuery.setMySnack("false");
		theDataForQuery.setMyCereal("false");
		theDataForQuery.setMyOther("false");
		//removes the retail price filter if category selected
				theDataForQuery.setMyGreaterThan("0");
				theDataForQuery.setMyLessThan("999999999");
				theDataForQuery.setMyMaxRange("999999999");
				theDataForQuery.setMyMinRange("0");
	}
	protected void do_mntmCategory_1_actionPerformed(ActionEvent e) {
		InventoryCategoryFilter categoryFilter = new InventoryCategoryFilter(theDataForQuery);
		categoryFilter.setLocation(this.getX()+35, this.getY()+35);
		categoryFilter.setVisible(true);
		
		//removes the retail price filter if category selected
		theDataForQuery.setMyGreaterThan("0");
		theDataForQuery.setMyLessThan("999999999");
		theDataForQuery.setMyMaxRange("999999999");
		theDataForQuery.setMyMinRange("0");
		
	}
	protected void do_mntmRemoveFilter_actionPerformed(ActionEvent arg0) {
		theDataForQuery.setMyGreaterThan("0");
		theDataForQuery.setMyLessThan("999999999");
		theDataForQuery.setMyMaxRange("999999999");
		theDataForQuery.setMyMinRange("0");
		
		theDataForQuery.setMyMeat("false");
		theDataForQuery.setMyDairy("false");
		theDataForQuery.setMyFrozen("false");
		theDataForQuery.setMyCanned("false");
		theDataForQuery.setMyProduce("false");
		theDataForQuery.setMyBeverage("false");
		theDataForQuery.setMyPaper("false");
		theDataForQuery.setMySnack("false");
		theDataForQuery.setMyCereal("false");
		theDataForQuery.setMyOther("false");
	}
}
