import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class newFrame1 extends JFrame {

	private JPanel contentPane;
	private final JLabel lblNewFrame = new JLabel("New Frame");
	private final JButton btnDone = new JButton("Done");
	private final JButton btnNewFrame = new JButton("New Frame 2");

	/**
	 * Launch the application.
	Comment out main to not launch the program in a subframe 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					newFrame1 frame = new newFrame1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/

	/**
	 * Create the frame.
	 */
	public newFrame1() {
		jbInit();
	}
	private void jbInit() {
		setTitle("New Frame");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 669, 453);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNewFrame.setBounds(237, 21, 223, 76);
		
		contentPane.add(lblNewFrame);
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnDone_actionPerformed(e);
			}
		});
		btnDone.setBounds(221, 118, 141, 35);
		
		contentPane.add(btnDone);
		btnNewFrame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnNewFrame_actionPerformed(e);
			}
		});
		btnNewFrame.setBounds(209, 188, 172, 35);
		
		contentPane.add(btnNewFrame);
	}
	protected void do_btnDone_actionPerformed(ActionEvent e) {
		//close the new frame
		this.dispose();
	}
	protected void do_btnNewFrame_actionPerformed(ActionEvent e) {
		newFrame2 new2 = new newFrame2();
		new2.setVisible(true);
	}
}
