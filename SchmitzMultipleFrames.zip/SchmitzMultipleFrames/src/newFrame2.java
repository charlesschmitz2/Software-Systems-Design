import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class newFrame2 extends JFrame {

	private JPanel contentPane;
	private final JLabel lblNewframe = new JLabel("newFrame2");
	private final JButton btnDone = new JButton("Done");

	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					newFrame2 frame = new newFrame2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	public newFrame2() {
		jbInit();
	}
	private void jbInit() {
		setTitle("newFrame2");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 643, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNewframe.setBounds(221, 74, 125, 26);
		
		contentPane.add(lblNewframe);
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnDone_actionPerformed(e);
			}
		});
		btnDone.setBounds(205, 121, 141, 35);
		
		contentPane.add(btnDone);
	}

	protected void do_btnDone_actionPerformed(ActionEvent e) {
		this.dispose();
	}
}
