import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class SchmitzMultipleFramesFrame extends JFrame {

	private JPanel contentPane;
	private final JButton btnNewFrame = new JButton("New Frame");
	private final JLabel lblMainFrame = new JLabel("Main Frame");
	private final JButton btnNewFrame_1 = new JButton("New Frame 2");
	private final JButton btnDone = new JButton("Done");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzMultipleFramesFrame frame = new SchmitzMultipleFramesFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzMultipleFramesFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Multiple Frames");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 681, 462);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		btnNewFrame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnNewFrame_actionPerformed(arg0);
			}
		});
		btnNewFrame.setBounds(250, 87, 141, 35);
		
		contentPane.add(btnNewFrame);
		lblMainFrame.setBounds(267, 40, 124, 26);
		
		contentPane.add(lblMainFrame);
		btnNewFrame_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnNewFrame_1_actionPerformed(e);
			}
		});
		btnNewFrame_1.setBounds(225, 143, 193, 35);
		
		contentPane.add(btnNewFrame_1);
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnDone_actionPerformed(e);
			}
		});
		btnDone.setBounds(250, 199, 141, 35);
		
		contentPane.add(btnDone);
	}
	protected void do_btnNewFrame_actionPerformed(ActionEvent arg0) {
		newFrame1 new1 = new newFrame1();
		new1.setVisible(true);
	}
	protected void do_btnDone_actionPerformed(ActionEvent e) {
		//this.dispose();
		//exits out of all the frames running not just the one frame
		System.exit(0);
	}
	protected void do_btnNewFrame_1_actionPerformed(ActionEvent e) {
		newFrame2 new2 = new newFrame2();
		new2.setVisible(true);
	}
}
