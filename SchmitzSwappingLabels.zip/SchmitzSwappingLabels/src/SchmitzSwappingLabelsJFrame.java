import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SchmitzSwappingLabelsJFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblHello = new JLabel("Hello");
	private final JLabel lblGoodbye = new JLabel("Goodbye");
	private final JButton btnClick = new JButton("CLICK");
	private final JLabel lblHowdy = new JLabel("Howdy");
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzSwappingLabelsJFrame frame = new SchmitzSwappingLabelsJFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzSwappingLabelsJFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Schmitz Swapping Labels");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 588, 506);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblHello.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 36));
		lblHello.setForeground(Color.WHITE);
		lblHello.setBounds(43, 81, 161, 54);
		
		contentPane.add(lblHello);
		lblGoodbye.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 46));
		lblGoodbye.setBounds(187, 208, 180, 67);
		
		contentPane.add(lblGoodbye);
		btnClick.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnClick_actionPerformed(arg0);
			}
		});
		btnClick.setBounds(214, 346, 120, 28);
		
		contentPane.add(btnClick);
		lblHowdy.setForeground(Color.RED);
		lblHowdy.setFont(new Font("Snap ITC", Font.PLAIN, 24));
		lblHowdy.setBackground(Color.WHITE);
		lblHowdy.setBounds(321, 81, 202, 54);
		
		contentPane.add(lblHowdy);
	}

	protected void do_btnClick_actionPerformed(ActionEvent arg0) {
		//Swapping the text of labels hello and goodbye and howdy
		String tempValue = lblHello.getText();
		String tempValue2 = lblGoodbye.getText();
		lblHello.setText(lblHowdy.getText());
		lblHowdy.setText(tempValue2);
		lblGoodbye.setText(tempValue);
		
		//Swapping the colors of labels goodbye and hello and howdy
		Color tempColor = lblHello.getForeground();
		Color tempColor2 = lblGoodbye.getForeground();
		lblHello.setForeground(lblHowdy.getForeground());
		lblHowdy.setForeground(tempColor2);
		lblGoodbye.setForeground(tempColor);
		
		//Swapping the colors of labels goodbye and hello and howdy
		Font tempFont = lblHello.getFont();
		Font tempFont2 = lblGoodbye.getFont();
		lblHello.setFont(lblHowdy.getFont());
		lblHowdy.setFont(tempFont2);
		lblGoodbye.setFont(tempFont); 
	}
}
