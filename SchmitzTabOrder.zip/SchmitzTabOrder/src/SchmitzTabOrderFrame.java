import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.eclipse.wb.swing.FocusTraversalOnArray;

import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import java.awt.Component;
import java.awt.Container;
import java.awt.FocusTraversalPolicy;

public class SchmitzTabOrderFrame extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel panel1 = new JPanel();
	private final JPanel panel2 = new JPanel();
	private final JPanel panel3 = new JPanel();
	private final JPanel panel4 = new JPanel();
	private final JTextField txtFive = new JTextField();
	private final JTextField txtSix = new JTextField();
	private final JTextField txtSeven = new JTextField();
	private final JTextField txtEight = new JTextField();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzTabOrderFrame frame = new SchmitzTabOrderFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzTabOrderFrame() {
		txtEight.setText("Eight");
		txtEight.setBounds(282, 161, 186, 32);
		txtEight.setColumns(10);
		txtSeven.setText("Seven");
		txtSeven.setBounds(21, 161, 186, 32);
		txtSeven.setColumns(10);
		txtSix.setText("Six");
		txtSix.setBounds(282, 71, 186, 32);
		txtSix.setColumns(10);
		txtFive.setText("Five");
		txtFive.setBounds(21, 71, 186, 32);
		txtFive.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Tab Order");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 686, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.setBounds(21, 21, 618, 437);
		
		contentPane.add(tabbedPane);
		
		tabbedPane.addTab("One", null, panel1, null);
		panel1.setLayout(null);
		
		panel1.add(txtFive);
		
		panel1.add(txtSix);
		
		panel1.add(txtSeven);
		
		panel1.add(txtEight);
		
		tabbedPane.addTab("Two", null, panel2, null);
		
		tabbedPane.addTab("Three", null, panel3, null);
		
		tabbedPane.addTab("Four", null, panel4, null);
		

		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{txtFive,txtSeven,txtSix,txtEight}));
	}
}
