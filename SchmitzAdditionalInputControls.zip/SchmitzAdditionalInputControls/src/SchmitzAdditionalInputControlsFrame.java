import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.accessibility.AccessibleContext;
import javax.swing.ButtonGroup;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class SchmitzAdditionalInputControlsFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblSelectedlabel = new JLabel("selectedLabel");
	private final JRadioButton rdbtnFirst = new JRadioButton("First");
	private final JRadioButton rdbtnSecond = new JRadioButton("Second");
	private final JRadioButton rdbtnThird = new JRadioButton("Third");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JSlider slider = new JSlider();
	private final JLabel lblSliderlabel = new JLabel("Slider :");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzAdditionalInputControlsFrame frame = new SchmitzAdditionalInputControlsFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzAdditionalInputControlsFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Input Controls");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 686, 595);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblSelectedlabel.setFont(new Font("Arial", Font.PLAIN, 21));
		lblSelectedlabel.setBounds(51, 53, 145, 58);
		
		contentPane.add(lblSelectedlabel);
		buttonGroup.add(rdbtnFirst);
		rdbtnFirst.setToolTipText("Select Value for Selected Label");
		rdbtnFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_rdbtnFirst_actionPerformed(arg0);
			}
		});
		rdbtnFirst.setFont(new Font("Arial", Font.PLAIN, 21));
		rdbtnFirst.setBounds(51, 126, 201, 35);
		
		contentPane.add(rdbtnFirst);
		buttonGroup.add(rdbtnSecond);
		rdbtnSecond.setToolTipText("Select Value for Selected Label");
		rdbtnSecond.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnSecond_actionPerformed(e);
			}
		});
		rdbtnSecond.setFont(new Font("Arial", Font.PLAIN, 21));
		rdbtnSecond.setBounds(51, 189, 201, 35);
		
		contentPane.add(rdbtnSecond);
		buttonGroup.add(rdbtnThird);
		rdbtnThird.setToolTipText("Select Value for Selected Label");
		rdbtnThird.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnThird_actionPerformed(e);
			}
		});
		rdbtnThird.setFont(new Font("Arial", Font.PLAIN, 21));
		rdbtnThird.setBounds(51, 250, 201, 35);
		
		contentPane.add(rdbtnThird);
		slider.setToolTipText("Slide pointer along slider to select value\r\n");
		slider.setValue(0);
		slider.setMaximum(50);
		slider.setMinimum(-50);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				do_slider_stateChanged(arg0);
			}
		});
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);
		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(5);
		slider.setBounds(266, 158, 341, 76);
		
		contentPane.add(slider);
		lblSliderlabel.setBounds(404, 254, 145, 26);
		
		lblSliderlabel.setText("Slider : " + slider.getValue());
		contentPane.add(lblSliderlabel);
	}
	protected void do_rdbtnFirst_actionPerformed(ActionEvent arg0) {
		lblSelectedlabel.setText("First");
	}
	protected void do_rdbtnSecond_actionPerformed(ActionEvent e) {
		lblSelectedlabel.setText("Second");
	}
	protected void do_rdbtnThird_actionPerformed(ActionEvent e) {
		lblSelectedlabel.setText("Third");
	}
	protected void do_slider_stateChanged(ChangeEvent arg0) {
		lblSliderlabel.setText("Slider : " + slider.getValue());		
	}
}
