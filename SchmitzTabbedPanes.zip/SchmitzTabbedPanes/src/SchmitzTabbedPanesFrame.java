import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import javax.swing.JFormattedTextField;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class SchmitzTabbedPanesFrame extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel namePanel = new JPanel();
	private final JPanel addressPanel = new JPanel();
	private final JPanel summaryPanel = new JPanel();
	private final JLabel lblName = new JLabel("Name : ");
	private final JTextField nameTextField = new JTextField();
	private final JLabel lblAddress = new JLabel("Address : ");
	private final JTextField addressTextField = new JTextField();
	private final JLabel lblSummaryName = new JLabel("Name :");
	private final JLabel lblSummaryAddress = new JLabel("Address : ");
	
	private String name = "";
	private String address = "";
	private final JTextField addressTextFieldSummary = new JTextField();
	private final JTextField nameTextFieldSummary = new JTextField();
	private final JLabel lblhitTabTo = new JLabel("*hit tab to confirm changes*");
	private final JLabel lblhitTabTo_1 = new JLabel("*hit tab to confirm changes*");
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzTabbedPanesFrame frame = new SchmitzTabbedPanesFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzTabbedPanesFrame() {
		nameTextFieldSummary.setBounds(116, 28, 327, 32);
		nameTextFieldSummary.setColumns(10);
		addressTextFieldSummary.setBounds(146, 103, 297, 32);
		addressTextFieldSummary.setColumns(10);
		addressTextField.setBounds(138, 60, 186, 32);
		addressTextField.setColumns(10);
		nameTextField.setBounds(100, 46, 186, 32);
		nameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Tabbed Panes");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 691, 594);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_tabbedPane_stateChanged(e);
			}
		});
		tabbedPane.setBounds(21, 21, 623, 481);
		
		contentPane.add(tabbedPane);
		
		
		
		tabbedPane.addTab("Name", null, namePanel, null);
		namePanel.setLayout(null);
		lblName.setBounds(21, 49, 92, 26);
		
		namePanel.add(lblName);
		
		namePanel.add(nameTextField);
		
		
		tabbedPane.addTab("Address", null, addressPanel, null);
		addressPanel.setLayout(null);
		lblAddress.setBounds(21, 63, 105, 26);
		
		addressPanel.add(lblAddress);
		
		addressPanel.add(addressTextField);
		
		tabbedPane.addTab("Summary", null, summaryPanel, null);
		summaryPanel.setLayout(null);
		lblSummaryName.setBounds(31, 31, 92, 26);
		
		summaryPanel.add(lblSummaryName);
		lblSummaryAddress.setBounds(31, 103, 124, 26);
		
		summaryPanel.add(lblSummaryAddress);
		
		summaryPanel.add(addressTextFieldSummary);
		
		summaryPanel.add(nameTextFieldSummary);
		
		lblSummaryName.setForeground(Color.RED);
		lblSummaryAddress.setForeground(Color.RED);
		lblName.setForeground(Color.RED);
		lblhitTabTo_1.setBounds(161, 394, 286, 26);
		
		namePanel.add(lblhitTabTo_1);
		lblAddress.setForeground(Color.RED);
		lblhitTabTo.setBounds(156, 380, 286, 26);
		
		addressPanel.add(lblhitTabTo);
	}
	
	protected void do_tabbedPane_stateChanged(ChangeEvent e) {
	//if name or address not filled in the label is red, otherwise it is lack		
		if(!nameTextFieldSummary.getText().isEmpty()) {
			lblSummaryName.setForeground(Color.black);
		}//if
		else {
			lblSummaryName.setForeground(Color.red);
		}
		
		if(!addressTextFieldSummary.getText().isEmpty()) {
			lblSummaryAddress.setForeground(Color.black);
		}
		else {
			lblSummaryAddress.setForeground(Color.red);
		}
		if(!nameTextField.getText().isEmpty()) {
			lblName.setForeground(Color.black);
		}//if
		else {
			lblName.setForeground(Color.red);
		}
		if(!addressTextField.getText().isEmpty()) {
			lblAddress.setForeground(Color.black);
		}//if
		else {
			lblAddress.setForeground(Color.red);
		}
		
	//set name variable and update the text field
		name = nameTextField.getText();
		nameTextFieldSummary.setText(name);
	//set address variable and update the text field	
		address = addressTextField.getText();
		addressTextFieldSummary.setText(address);
	}
	
}
