import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class SchmitzChallenge4Frame extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel addPanel = new JPanel();
	private final JPanel subtractPanel = new JPanel();
	private final JTextField numOneTextField = new JTextField();
	private final JTextField numTwoTextField = new JTextField();
	private final JLabel label = new JLabel("+");
	private final JLabel label_1 = new JLabel("___________________________");
	
	private int numOne = 0;
	private int numTwo = 0;
	private int sum = 0;
	private final JTextField sumTextField = new JTextField();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzChallenge4Frame frame = new SchmitzChallenge4Frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzChallenge4Frame() {
		sumTextField.setEnabled(false);
		sumTextField.setBounds(193, 222, 186, 26);
		sumTextField.setColumns(10);
		numOneTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_numOneTextField_focusLost(arg0);
			}
		});
		numOneTextField.setBounds(193, 69, 186, 32);
		numOneTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Challenge 3");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 691, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.setBounds(10, 21, 634, 375);
		
		contentPane.add(tabbedPane);
		
		tabbedPane.addTab("Add", null, addPanel, null);
		addPanel.setLayout(null);
		
		numOneTextField.setText("0");
		addPanel.add(numOneTextField);
		numTwoTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_numTwoTextField_focusLost(e);
			}
		});
		numTwoTextField.setColumns(10);
		numTwoTextField.setBounds(193, 122, 186, 32);
		
		numTwoTextField.setText("0");
		addPanel.add(numTwoTextField);
		label.setBounds(145, 125, 27, 26);
		
		addPanel.add(label);
		label_1.setBounds(168, 175, 318, 26);
		
		addPanel.add(label_1);
		
		addPanel.add(sumTextField);
		
		tabbedPane.addTab("Subtract", null, subtractPanel, null);
		subtractPanel.setLayout(null);
	}
	protected void do_numOneTextField_focusLost(FocusEvent arg0) {
		sum = sum();
		sumTextField.setText(Integer.toString(sum));
	}
	protected void do_numTwoTextField_focusLost(FocusEvent e) {
		sum = sum();
		sumTextField.setText(Integer.toString(sum));
	}
	
	protected int sum() {
		numOne = Integer.parseInt(numOneTextField.getText().trim());
		numTwo = Integer.parseInt(numTwoTextField.getText().trim());
		sum = numOne + numTwo;
		return sum;
	}
}
