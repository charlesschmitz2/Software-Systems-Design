import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class SchmitzTextExampleFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblName = new JLabel("Name : ");
	private final JLabel lblAge = new JLabel("Age : ");
	private final JTextField NameTextField = new JTextField();
	private final JTextField AgeTextField = new JTextField();
	private final JButton btnPrint = new JButton("Print");
	private final JTextArea OutputTextArea = new JTextArea();
	private final JScrollPane scrollPane = new JScrollPane();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzTextExampleFrame frame = new SchmitzTextExampleFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzTextExampleFrame() {
		AgeTextField.setBounds(117, 87, 186, 32);
		AgeTextField.setColumns(10);
		NameTextField.setBounds(117, 40, 186, 32);
		NameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Schmitz Text Example");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 584, 512);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblName.setBounds(38, 43, 92, 26);
		
		contentPane.add(lblName);
		lblAge.setBounds(38, 90, 92, 26);
		
		contentPane.add(lblAge);
		
		contentPane.add(NameTextField);
		
		contentPane.add(AgeTextField);
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnPrint_actionPerformed(arg0);
			}
		});
		btnPrint.setBounds(137, 147, 141, 35);
		
		contentPane.add(btnPrint);
		scrollPane.setBounds(322, 43, 186, 152);
		
		//Adding a scroll bar --> right click, surround with, scroll pane
		contentPane.add(scrollPane);
		scrollPane.setViewportView(OutputTextArea);
	}
	protected void do_btnPrint_actionPerformed(ActionEvent arg0) {
		//Check to see if both fields are empty
		if(NameTextField.getText().isEmpty() && AgeTextField.getText().isEmpty()) 
		{
			OutputTextArea.append("NO TEXT INPUTED\n");
			lblName.setForeground(Color.RED);
			lblAge.setForeground(Color.RED);
		}//if
		
		//Check to see if just NAME field is empty
		else if (NameTextField.getText().isEmpty()) {
			OutputTextArea.append("Name : NOT INPUTED\n");
			OutputTextArea.append("Age : " + AgeTextField.getText()  + "\n");
			lblName.setForeground(Color.RED);
			lblAge.setForeground(Color.BLACK);
		}//else if
		
		//Check to see if AGE field is empty 
		else if (AgeTextField.getText().isEmpty()) {
			OutputTextArea.append("Name : " + NameTextField.getText() + "\n");
			OutputTextArea.append("Age : NOT INPUTED\n");
			lblAge.setForeground(Color.RED);
			lblName.setForeground(Color.BLACK);
		}//else if
		
		//If all fields are inputed, print out as normal
		else 
		{
			OutputTextArea.append("Name : " + NameTextField.getText() + "\n");
			OutputTextArea.append("Age : " + AgeTextField.getText()  + "\n");
			lblName.setForeground(Color.BLACK);
			lblAge.setForeground(Color.BLACK);
		}//else
		
	}
}
