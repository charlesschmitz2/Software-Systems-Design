import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SchmitzFlashingLabelsFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblCmptRocks = new JLabel("CMPT330 Rocks");
	private final JLabel lblOtherLabel = new JLabel("Other Label");
	private final JButton btnFancy = new JButton("Fancy");
	private final JButton btnFacier = new JButton("Facier");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzFlashingLabelsFrame frame = new SchmitzFlashingLabelsFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzFlashingLabelsFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Schmitz Flashing Labels");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblCmptRocks.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCmptRocks.setForeground(Color.BLUE);
		lblCmptRocks.setBounds(49, 40, 140, 60);
		
		contentPane.add(lblCmptRocks);
		lblOtherLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		lblOtherLabel.setBounds(49, 121, 92, 26);
		lblOtherLabel.setVisible(false);
		
		contentPane.add(lblOtherLabel);
		btnFancy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnFancy_actionPerformed(arg0);
			}
		});
		btnFancy.setFont(new Font("Script MT Bold", Font.PLAIN, 21));
		btnFancy.setBounds(221, 51, 92, 35);
		
		contentPane.add(btnFancy);
		btnFacier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnFacier_actionPerformed(e);
			}
		});
		btnFacier.setFont(new Font("Old English Text MT", Font.PLAIN, 21));
		btnFacier.setBounds(221, 114, 98, 35);
		
		contentPane.add(btnFacier);
	}
	protected void do_btnFancy_actionPerformed(ActionEvent arg0) {
		//Toggles the visibility of the CmptRocks label. Setting the visibility of the opposite of what it is
		lblCmptRocks.setVisible(!lblCmptRocks.isVisible());
	}//fancy button
	protected void do_btnFacier_actionPerformed(ActionEvent e) {
		//Toggles the visibility of both labels
		lblCmptRocks.setVisible(!lblCmptRocks.isVisible());
		lblOtherLabel.setVisible(!lblOtherLabel.isVisible());
	}//fancier button
}
