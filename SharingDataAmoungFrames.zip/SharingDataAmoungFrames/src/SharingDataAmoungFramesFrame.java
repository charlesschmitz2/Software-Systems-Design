import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SharingDataAmoungFramesFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblValue = new JLabel("Value 1:");
	private final JLabel lblValue_1 = new JLabel("Value 2:");
	private final JLabel lblValue_2 = new JLabel("Value 3:");
	private final JTextField value1TF = new JTextField();
	private final JTextField value2TF = new JTextField();
	private final JTextField value3TF = new JTextField();
	private final JButton btnAdd = new JButton("Add...");
	private final JButton btnUpdate = new JButton("Update");
	Item theData = new Item();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SharingDataAmoungFramesFrame frame = new SharingDataAmoungFramesFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SharingDataAmoungFramesFrame() {
		value3TF.setText("");
		value3TF.setBounds(163, 178, 186, 32);
		value3TF.setColumns(10);
		value2TF.setBounds(163, 116, 186, 32);
		value2TF.setColumns(10);
		value1TF.setBounds(163, 51, 186, 32);
		value1TF.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Main Frame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 840, 529);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblValue.setBounds(68, 54, 92, 26);
		
		contentPane.add(lblValue);
		lblValue_1.setBounds(68, 119, 92, 26);
		
		contentPane.add(lblValue_1);
		lblValue_2.setBounds(68, 181, 92, 26);
		
		contentPane.add(lblValue_2);
		
		contentPane.add(value1TF);
		
		contentPane.add(value2TF);
		
		contentPane.add(value3TF);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnAdd_actionPerformed(e);
			}
		});
		btnAdd.setBounds(89, 256, 141, 35);
		
		contentPane.add(btnAdd);
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnUpdate_actionPerformed(e);
			}
		});
		btnUpdate.setBounds(288, 256, 141, 35);
		
		contentPane.add(btnUpdate);
	}
	protected void do_btnAdd_actionPerformed(ActionEvent e) {
		theData = new Item(value1TF.getText().trim(), value2TF.getText().trim(), value3TF.getText().trim());
		AddFrame addIt = new AddFrame(theData);
		addIt.setLocation(this.getX()+35, this.getY() + 35);
		addIt.setVisible(true);
	}
	protected void do_btnUpdate_actionPerformed(ActionEvent e) {
		value1TF.setText(theData.getMyOne());
		value2TF.setText(theData.getMyTwo());
		value3TF.setText(theData.getMyThree());
	}
}
