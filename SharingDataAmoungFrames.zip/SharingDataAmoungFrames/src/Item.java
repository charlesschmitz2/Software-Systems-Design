
public class Item {
	private String myOne;
	private String myTwo;
	private String myThree;
	
	public Item()
	{
		myOne = "none";
		myTwo = "none";
		myThree = "none";
	}
	
	public Item(String myOne, String myTwo, String myThree) {
		super();
		this.myOne = myOne;
		this.myTwo = myTwo;
		this.myThree = myThree;
	}
	
	public String getMyOne() {
		return myOne;
	}
	public void setMyOne(String myOne) {
		this.myOne = myOne;
	}
	public String getMyTwo() {
		return myTwo;
	}
	public void setMyTwo(String myTwo) {
		this.myTwo = myTwo;
	}
	public String getMyThree() {
		return myThree;
	}
	public void setMyThree(String myThree) {
		this.myThree = myThree;
	}
	
	

}
