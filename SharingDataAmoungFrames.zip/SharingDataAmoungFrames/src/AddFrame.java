import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblFirst = new JLabel("First :");
	private final JLabel lblSecond = new JLabel("Second :");
	private final JLabel lblThird = new JLabel("Third :");
	private final JTextField firstTF = new JTextField();
	private final JTextField secondTF = new JTextField();
	private final JTextField thirdTF = new JTextField();
	private final JButton btnDone = new JButton("Done");

	//my data is to hold the data in Item of the one two and three and then have that be accessed for the update button in main frame as well
	private Item myData;
	
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddFrame frame = new AddFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the frame.
	 */
	public AddFrame(Item data) {
		thirdTF.setBounds(225, 189, 186, 32);
		thirdTF.setColumns(10);
		secondTF.setBounds(225, 129, 186, 32);
		secondTF.setColumns(10);
		firstTF.setBounds(225, 65, 186, 32);
		firstTF.setColumns(10);
		
		firstTF.setText(data.getMyOne());
		secondTF.setText(data.getMyTwo());
		thirdTF.setText(data.getMyThree());
		
		myData = data;
		
		jbInit();
	}
	private void jbInit() {
		setTitle("AddFrame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 829, 527);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblFirst.setBounds(92, 68, 92, 26);
		
		contentPane.add(lblFirst);
		lblSecond.setBounds(92, 132, 92, 26);
		
		contentPane.add(lblSecond);
		lblThird.setBounds(92, 192, 92, 26);
		
		contentPane.add(lblThird);
		
		contentPane.add(firstTF);
		
		contentPane.add(secondTF);
		
		contentPane.add(thirdTF);
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnDone_actionPerformed(arg0);
			}
		});
		btnDone.setBounds(169, 268, 141, 35);
		
		contentPane.add(btnDone);
	}

	protected void do_btnDone_actionPerformed(ActionEvent arg0) {
		myData.setMyOne(firstTF.getText().trim());
		myData.setMyTwo(secondTF.getText().trim());
		myData.setMyThree(thirdTF.getText().trim());
		this.dispose();
	}
}
