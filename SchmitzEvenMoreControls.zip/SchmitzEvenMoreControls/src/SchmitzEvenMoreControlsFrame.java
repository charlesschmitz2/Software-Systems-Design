import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JSlider;
import java.awt.Font;
import javax.swing.JSpinner;
import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class SchmitzEvenMoreControlsFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblRadioGroupValue = new JLabel("Radio Group Value : ");
	private final JLabel lblCheckBoxValues = new JLabel("Check Box Value(s) : ");
	private final JRadioButton rdbtnOne = new JRadioButton("One");
	private final JRadioButton rdbtnTwo = new JRadioButton("Two");
	private final JRadioButton rdbtnThree = new JRadioButton("Three");
	private final JRadioButton rdbtnFour = new JRadioButton("Four");
	private final JCheckBox chckbxFirst = new JCheckBox("First");
	private final JCheckBox chckbxSecond = new JCheckBox("Second");
	private final JCheckBox chckbxThird = new JCheckBox("Third");
	private final JSlider slider = new JSlider();
	private final JLabel lblSliderValue = new JLabel("Slider Value : ");
	private final JSpinner spinner = new JSpinner();
	private final JLabel lblSpinnerValue = new JLabel("Spinner Value : ");
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzEvenMoreControlsFrame frame = new SchmitzEvenMoreControlsFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzEvenMoreControlsFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("More Controls");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 676, 588);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblRadioGroupValue.setBounds(21, 21, 217, 26);
		
		contentPane.add(lblRadioGroupValue);
		lblCheckBoxValues.setBounds(259, 21, 370, 26);
		
		contentPane.add(lblCheckBoxValues);
		buttonGroup.add(rdbtnOne);
		rdbtnOne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_rdbtnOne_actionPerformed(arg0);
			}
		});
		rdbtnOne.setBounds(36, 76, 201, 35);
		
		contentPane.add(rdbtnOne);
		buttonGroup.add(rdbtnTwo);
		rdbtnTwo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnTwo_actionPerformed(e);
			}
		});
		rdbtnTwo.setBounds(36, 124, 201, 35);
		
		contentPane.add(rdbtnTwo);
		buttonGroup.add(rdbtnThree);
		rdbtnThree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnThree_actionPerformed(e);
			}
		});
		rdbtnThree.setBounds(36, 172, 201, 35);
		
		contentPane.add(rdbtnThree);
		buttonGroup.add(rdbtnFour);
		rdbtnFour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnFour_actionPerformed(e);
			}
		});
		rdbtnFour.setBounds(36, 221, 201, 35);
		
		contentPane.add(rdbtnFour);
		chckbxFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxFirst_actionPerformed(e);
			}
		});
		
		
		chckbxFirst.setBounds(375, 76, 179, 35);
		
		contentPane.add(chckbxFirst);
		chckbxSecond.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxSecond_actionPerformed(e);
			}
		});
		
		chckbxSecond.setBounds(375, 124, 179, 35);
		
		contentPane.add(chckbxSecond);
		chckbxThird.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxThird_actionPerformed(e);
			}
		});
		
		chckbxThird.setBounds(375, 172, 179, 35);
		
		contentPane.add(chckbxThird);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_slider_stateChanged(e);
			}
		});
		slider.setFont(new Font("Tahoma", Font.PLAIN, 18));
		slider.setMajorTickSpacing(10);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setBounds(21, 377, 385, 69);
		
		contentPane.add(slider);
		lblSliderValue.setBounds(106, 342, 194, 26);
		lblSliderValue.setText("Slider Value : " + slider.getValue());
		contentPane.add(lblSliderValue);
		spinner.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_spinner_stateChanged(e);
			}
		});
		spinner.setBounds(442, 377, 63, 51);
		lblSpinnerValue.setText("Spinner Value : " + spinner.getValue());
		contentPane.add(spinner);
		lblSpinnerValue.setBounds(410, 342, 219, 26);
		
		contentPane.add(lblSpinnerValue);
	}
	protected void do_rdbtnOne_actionPerformed(ActionEvent arg0) {
		lblRadioGroupValue.setText("Radio Group Value : " + rdbtnOne.getText());
	}
	protected void do_rdbtnTwo_actionPerformed(ActionEvent e) {
		lblRadioGroupValue.setText("Radio Group Value : " + rdbtnTwo.getText());
	}
	protected void do_rdbtnThree_actionPerformed(ActionEvent e) {
		lblRadioGroupValue.setText("Radio Group Value : " + rdbtnThree.getText());
	}
	protected void do_rdbtnFour_actionPerformed(ActionEvent e) {
		lblRadioGroupValue.setText("Radio Group Value : " + rdbtnFour.getText());
	}
	protected void do_slider_stateChanged(ChangeEvent e) {
		lblSliderValue.setText("Slider Value : " + slider.getValue());
	}
	protected void do_spinner_stateChanged(ChangeEvent e) {
		lblSpinnerValue.setText("Spinner Value : " + spinner.getValue());
	}
	
	protected void do_chckbxFirst_actionPerformed(ActionEvent e) {
		if(chckbxFirst.isSelected()) {
			lblCheckBoxValues.setText(lblCheckBoxValues.getText() + chckbxFirst.getText());		
		}//if
		else {
			String contents = lblCheckBoxValues.getText();
			contents = contents.replaceFirst(chckbxFirst.getText(), "");
			lblCheckBoxValues.setText(contents);
		}//else
	}
	
	protected void do_chckbxSecond_actionPerformed(ActionEvent e) {
		if(chckbxSecond.isSelected()) {
			lblCheckBoxValues.setText(lblCheckBoxValues.getText() + chckbxSecond.getText());
		}//if
		else {
			String contents = lblCheckBoxValues.getText();
			contents = contents.replaceFirst(chckbxSecond.getText(), "");
			lblCheckBoxValues.setText(contents);
		}//else
	}
	
	protected void do_chckbxThird_actionPerformed(ActionEvent e) {
		if(chckbxThird.isSelected()) {
			lblCheckBoxValues.setText(lblCheckBoxValues.getText() + chckbxThird.getText());
		}//if
		else {
			String contents = lblCheckBoxValues.getText();
			contents = contents.replaceFirst(chckbxThird.getText(), "");
			lblCheckBoxValues.setText(contents);
		}//else
	}
	
	
	}

