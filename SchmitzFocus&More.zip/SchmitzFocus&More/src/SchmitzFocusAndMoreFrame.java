import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Color;

public class SchmitzFocusAndMoreFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblPositive = new JLabel("Positive :");
	private final JLabel lblNegative = new JLabel("Negative : ");
	private final JTextField posTextField = new JTextField();
	private final JTextField negTextField = new JTextField();
	private final JLabel lblSum = new JLabel("Sum : ");
	private final JTextField sumTextField = new JTextField();
	
	private int posNum = 0;
	private int negNum = 0;
	private int sum = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzFocusAndMoreFrame frame = new SchmitzFocusAndMoreFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzFocusAndMoreFrame() {
		sumTextField.setFont(new Font("Gill Sans MT", Font.PLAIN, 21));
		sumTextField.setBounds(133, 195, 226, 32);
		sumTextField.setColumns(10);
		negTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_negTextField_focusLost(e);
			}
		});
		negTextField.setFont(new Font("Gill Sans MT", Font.PLAIN, 21));
		negTextField.setBounds(143, 119, 216, 32);
		negTextField.setColumns(10);
		posTextField.setToolTipText("<html> Please Enter <br></br> A Positive Number </html>\r\n");
		posTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_posTextField_focusLost(arg0);
			}
		});
		posTextField.setFont(new Font("Gill Sans MT", Font.PLAIN, 21));
		posTextField.setBounds(133, 48, 226, 32);
		posTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Focus and More");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 685, 593);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblPositive.setForeground(Color.WHITE);
		lblPositive.setFont(new Font("Gill Sans MT", Font.PLAIN, 21));
		lblPositive.setBounds(33, 50, 92, 26);
		
		contentPane.add(lblPositive);
		lblNegative.setForeground(Color.WHITE);
		lblNegative.setFont(new Font("Gill Sans MT", Font.PLAIN, 21));
		lblNegative.setBounds(33, 121, 117, 26);
		
		contentPane.add(lblNegative);
		
		posTextField.setText("0");
		contentPane.add(posTextField);
		negTextField.setText("0");
		contentPane.add(negTextField);
		lblSum.setFont(new Font("Gill Sans MT", Font.PLAIN, 21));
		lblSum.setForeground(Color.WHITE);
		lblSum.setBackground(Color.WHITE);
		lblSum.setBounds(33, 198, 92, 26);
		
		contentPane.add(lblSum);
		sumTextField.setText("0");
		contentPane.add(sumTextField);
	}
	protected void do_posTextField_focusLost(FocusEvent arg0) {
		/*if(!posTextField.getText().isEmpty()) 
		{
			if(Integer.parseInt(posTextField.getText().trim()) <= 0) 
			{
				JOptionPane.showMessageDialog(this, "The 'Positive' Field Must be Positive", "Error Message", JOptionPane.ERROR_MESSAGE);
				posTextField.grabFocus();
			}//if
			
		}//if	
		*/
		sum = sum();
		sumTextField.setText(Integer.toString(sum));
	}//focus lost on positive text field
	
	protected void do_negTextField_focusLost(FocusEvent e) {
		/*if(!negTextField.getText().isEmpty()) 
		{
			if(Integer.parseInt(negTextField.getText().trim()) <= 0) 
			{
				JOptionPane.showMessageDialog(this, "The 'Negative' Field Must be Negative", "Error Message", JOptionPane.ERROR_MESSAGE);
				negTextField.grabFocus();
			}//if
		}//if*/
		sum = sum();
		sumTextField.setText(Integer.toString(sum));
	}//focus lost on negative text field
	
	protected int sum() {
		posNum = Integer.parseInt(posTextField.getText().trim());
		negNum = Integer.parseInt(negTextField.getText().trim());
		sum = negNum + posNum;
		return sum;
	}
}
