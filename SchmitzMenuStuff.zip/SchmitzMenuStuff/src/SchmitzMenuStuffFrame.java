import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.KeyStroke;
import java.awt.event.InputEvent;
import javax.swing.JProgressBar;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class SchmitzMenuStuffFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblMenuOptions = new JLabel("Menu Options : ");
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mntmNew = new JMenuItem("New");
	private final JMenuItem mntmOpen = new JMenuItem("Open");
	private final JMenu mnMore = new JMenu("More");
	private final JMenuItem mntmFirst = new JMenuItem("First");
	private final JMenuItem mntmSecond = new JMenuItem("Second");
	private final JMenuItem mntmThird = new JMenuItem("Third");
	private final JMenu mnEdit = new JMenu("Edit");
	private final JMenu mnNavigate = new JMenu("Navigate");
	private final JMenu mnSearch = new JMenu("Search");
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenuItem mntmUndo = new JMenuItem("Undo");
	private final JMenuItem mntmRedo = new JMenuItem("Redo");
	private final JMenuItem mntmCute = new JMenuItem("Cut");
	private final JMenuItem mntmPaste = new JMenuItem("Paste");
	private final JMenu mnAppearance = new JMenu("Appearance");
	private final JMenuItem mntmTheme = new JMenuItem("Theme");
	private final JProgressBar progressBar = new JProgressBar();
	private final JButton btnRun = new JButton("Run");
	private final JLabel lblPassword = new JLabel("Password : ");
	private final JToggleButton tglbtnPassword = new JToggleButton("False");
	private final JTextField passwordTextField = new JTextField();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzMenuStuffFrame frame = new SchmitzMenuStuffFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzMenuStuffFrame() {
		passwordTextField.setBounds(421, 18, 186, 32);
		passwordTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Menu Stuff");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 598);
		
		setJMenuBar(menuBar);
		mnFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mnFile_actionPerformed(e);
			}
		});
		
		menuBar.add(mnFile);
		mntmNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));

		mntmNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmNew_actionPerformed(e);
			}
		});
		
		mnFile.add(mntmNew);
		mntmOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
		mntmOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmOpen_actionPerformed(e);
			}
		});
		
		mnFile.add(mntmOpen);
		mnMore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mnMore_actionPerformed(e);
			}
		});
		
		mnFile.add(mnMore);
		mntmFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmFirst_actionPerformed(e);
			}
		});
		
		mnMore.add(mntmFirst);
		mntmSecond.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmSecond_actionPerformed(e);
			}
		});
		
		mnMore.add(mntmSecond);
		mntmThird.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmThird_actionPerformed(e);
			}
		});
		
		mnMore.add(mntmThird);
		
		menuBar.add(mnEdit);
		mntmUndo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_UNDEFINED, 0));
		
		mnEdit.add(mntmUndo);
		
		mnEdit.add(mntmRedo);
		
		mnEdit.add(mntmCute);
		mntmPaste.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmPaste_actionPerformed(e);
			}
		});
		mntmPaste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));
		
		mnEdit.add(mntmPaste);
		
		mnEdit.add(mnAppearance);
		
		mnAppearance.add(mntmTheme);
		
		menuBar.add(mnNavigate);
		
		menuBar.add(mnSearch);
		
		menuBar.add(mnHelp);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblMenuOptions.setBounds(21, 181, 254, 26);
		
		contentPane.add(lblMenuOptions);
		progressBar.setStringPainted(true);
		progressBar.setBounds(170, 298, 325, 44);
		
		contentPane.add(progressBar);
		btnRun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnRun_actionPerformed(e);
			}
		});
		btnRun.setBounds(272, 363, 141, 35);
		
		contentPane.add(btnRun);
		lblPassword.setBounds(307, 21, 151, 26);
		
		contentPane.add(lblPassword);
		tglbtnPassword.setBounds(345, 68, 207, 35);
		
		contentPane.add(tglbtnPassword);
		
		contentPane.add(passwordTextField);
	}
	
	protected void do_mntmNew_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "New");
	}
	protected void do_mntmOpen_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "Open");
	}
	protected void do_mnMore_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "More");
	}
	protected void do_mntmFirst_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "First");
	}
	
	protected void do_mntmSecond_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "Second");
	}
	protected void do_mntmThird_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "Third");
	}
	
	protected void do_mnFile_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "File");
	}
	
	protected void do_mntmPaste_actionPerformed(ActionEvent e) {
		lblMenuOptions.setText(lblMenuOptions.getText() + "Paste");
	}
	protected void do_btnRun_actionPerformed(ActionEvent e) {
		progressBar.setValue(progressBar.getValue()+10);
	}
}
