import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JTabbedPane;
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import javax.swing.JSeparator;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.util.*;
import javax.swing.JTextPane;
import java.text.NumberFormat;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.SystemColor;

public class SchmitzSACAPframe extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel ApplicantPanel = new JPanel();
	private final JPanel HouseholdPanel = new JPanel();
	private final JPanel FinancialPanel = new JPanel();
	private final JLabel lblFirstName = new JLabel("*First Name :");
	private final JTextField FirstNameTextField = new JTextField();
	private final JLabel lblLastName = new JLabel("*Last Name : ");
	private final JTextField LastNameTextField = new JTextField();
	private final JLabel lblDateOfBirth = new JLabel("*Date of Birth :");
	private final JLabel lblAddress = new JLabel("*Address :");
	private final JLabel lblCity = new JLabel("*City : ");
	private final JLabel lblCounty = new JLabel("*County :");
	private final JLabel lblZip = new JLabel("*Zip :");
	private final JLabel lblPhoneNumber = new JLabel("*Phone Number :");
	private final JTextField CityTextField = new JTextField();
	private final JTextField AddressTextField = new JTextField();
	private final JFormattedTextField PhoneFormattedTextField = new JFormattedTextField();
	private final JFormattedTextField ZipFormattedTextField = new JFormattedTextField();
	private final JFormattedTextField DOBFormattedTextField = new JFormattedTextField();
	private final JScrollPane scrollPane = new JScrollPane();
	private final JList list = new JList();
	private final JRadioButton rdbtnWh = new JRadioButton("WH");
	private final JRadioButton rdbtnBL = new JRadioButton("BL");
	private final JRadioButton rdbtnHIS = new JRadioButton("HIS");
	private final JRadioButton rdbtnAsian = new JRadioButton("Asian");
	private final JRadioButton rdbtnAmerInd = new JRadioButton("AMER.IND");
	private final JRadioButton rdbtnOther = new JRadioButton("OTHER");
	private final JLabel lblEthnicity = new JLabel("Ethnicity :");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenuItem mntmPplication = new JMenuItem("Start New Application");
	private final JMenuItem mntmExit = new JMenuItem("Exit");
	private final JMenuItem mntmApplicantInfo = new JMenuItem("Applicant Info");
	private final JMenuItem mntmHouseholdInfo = new JMenuItem("Household Info");
	private final JMenuItem mntmFinancialInfo = new JMenuItem("Financial Info");
	private final JLabel lblSpouseName = new JLabel("Spouse Name :");
	private final JTextField spouseNametxtField = new JTextField();
	private final JLabel lblSpouseDOB = new JLabel("Spouse Date of Birth :");
	private final JLabel lblPresentProblem = new JLabel("Present Problem :");
	private final JLabel lblPlaceOfEmployment = new JLabel("Place of Employment :");
	private final JTextField POETextField = new JTextField();
	private final JCheckBox chckbxUneployed = new JCheckBox("Unemployed");
	private final JCheckBox chckbxEmployed = new JCheckBox("Employed");
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final JLabel lblIfMarriedFill = new JLabel("<HTML> <U> If married, fill in the following fields </U> <HTML>\r\n");
	private final JLabel lblName = new JLabel("Name :");
	private final JLabel lblAge = new JLabel("Age :");
	private final JLabel lblRelationship = new JLabel("Relationship :");
	private final JLabel lblSsn = new JLabel("SSN :");
	private final JTextField nameTextField_1 = new JTextField();
	private final JTextField nameTextField_2 = new JTextField();
	private final JTextField nameTextField_3 = new JTextField();
	private final JTextField nameTextField_4 = new JTextField();
	private final JTextField nameTextField_5 = new JTextField();
	private final JComboBox relationshipComboBox_1 = new JComboBox();
	private final JComboBox relationshipComboBox_2 = new JComboBox();
	private final JComboBox relationshipComboBox_3 = new JComboBox();
	private final JComboBox relationshipComboBox_4 = new JComboBox();
	private final JComboBox relationshipComboBox_5 = new JComboBox();
	private final JComboBox ageComboBox_1 = new JComboBox();
	private final JComboBox ageComboBox_2 = new JComboBox();
	private final JComboBox ageComboBox_3 = new JComboBox();
	private final JComboBox ageComboBox_4 = new JComboBox();
	private final JComboBox ageComboBox_5 = new JComboBox();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private final JLabel lblInputUpTo = new JLabel("<HTML> <U> Input up to FIVE Household Members if Applicable : </U> </HTML>");
	private final JFormattedTextField HSSNformattedTextField_1 = new JFormattedTextField();
	private final JFormattedTextField HSSNformattedTextField_2 = new JFormattedTextField();
	private final JFormattedTextField HSSNformattedTextField_3 = new JFormattedTextField();
	private final JFormattedTextField HSSNformattedTextField_4 = new JFormattedTextField();
	private final JFormattedTextField HSSNformattedTextField_5 = new JFormattedTextField();
	private final JCheckBox householdNumNewCheckBox_1 = new JCheckBox("One");
	private final JCheckBox householdNumNewCheckBox_2 = new JCheckBox("Two");
	private final JCheckBox householdNumNewCheckBox_3 = new JCheckBox("Three");
	private final JCheckBox householdNumNewCheckBox_4 = new JCheckBox("Four");
	private final JCheckBox householdNumNewCheckBox_5 = new JCheckBox("Five");
	private final JLabel lblPleaseSelectThe = new JLabel("<HTML><U>Please Select the Number of Household Members You Have</U> :</HTML>");
	private final JCheckBox chckbxNone = new JCheckBox("None");
	private final JLabel lblDate = new JLabel("");
	private final JTextPane presentProblemTextArea = new JTextPane();
	private final JLabel lblExpenses = new JLabel("<HTML> <U> Expenses</U> </HTML>\r\n ");
	private final JLabel lblIncome = new JLabel("<HTML> <U> Income</U> </HTML>\r\n");
	private final JLabel lblSalary = new JLabel("Salary :");
	private final JLabel lblUnemployment = new JLabel("Unemployment :");
	private final JLabel lblTanfafdc = new JLabel("TANF/AFDC :");
	private final JLabel lblSocialSecurity_1 = new JLabel("Social Security :");
	private final JLabel lblDisability = new JLabel("Disability :");
	private final JLabel lblChildSupport = new JLabel("Child Support :");
	private final JLabel lblUtilityAssistance = new JLabel("Utility Assistance :");
	private final JLabel lblFoodStamps = new JLabel("Food Stamps :");
	private final JLabel lblOther = new JLabel("Other :");
	
	NumberFormat numFormat = NumberFormat.getNumberInstance();
	private final JFormattedTextField SalaryFormattedTextField = new JFormattedTextField(numFormat);
	private final JFormattedTextField unemploymentFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField TAFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField socialSecurityFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField disabilityFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField childSupportFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField utilityAssistanceFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField foodStampsFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField incomeOtherFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField rentFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField phoneBillFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField gasWaterBillFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField lightBillFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField carPaymentFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField furnAppliancesFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField cableTVFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField doctorMedicalFTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField expenseOtherFTF = new JFormattedTextField(numFormat);
	private final JLabel lblRent = new JLabel("Rent :");
	private final JLabel lblPhoneBill = new JLabel("Phone Bill :");
	private final JLabel lblGaswater = new JLabel("Gas/Water :");
	private final JLabel lblLightBill = new JLabel("Light Bill :");
	private final JLabel lblCarPayment = new JLabel("Car Payment :");
	private final JLabel lblFurnappliances = new JLabel("Furn./Appliances :");
	private final JLabel lblCableTv = new JLabel("Cable TV :");
	private final JLabel lblDoctormedical = new JLabel("Doctor/Medical :");
	private final JLabel lblOther_1 = new JLabel("Other :");
	private final JFormattedTextField expenseSumFTF = new JFormattedTextField();
	private final JLabel lblTotalIncome = new JLabel("Total :");
	private final JLabel lblTotal = new JLabel("Total :");
	private final JFormattedTextField incomeSumFTF = new JFormattedTextField();
	private final JLabel lblTotalNetIncome = new JLabel("Total Net Income :");
	private final JFormattedTextField totalNetIncome = new JFormattedTextField();
	private final JLabel lblSpouseSocialSecurity = new JLabel("Spouse Social Security Number :");
	private final JFormattedTextField spouseSSNFormattedTextField = new JFormattedTextField();
	private final JFormattedTextField SocialSecuirtyFormattedTextField = new JFormattedTextField();
	private final JLabel lblSocialSecurity = new JLabel("*Social Security Number :");
	private final JLabel lblEnterYourFinancial = new JLabel("<HTML> <U> Enter Your Financial Information Below</U></HTML>");
	private final JLabel lblFiillOutThe = new JLabel("<HTML><U>Fill out the Personal Information Tabs Below ( * Fields Required)</U></HTML>");
	private final JFormattedTextField spouseDOBFTF = new JFormattedTextField();
	
	private String getDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
		Date date = new Date();
		return dateFormat.format(date);
	}//date
	private final JLabel lblDateView = new JLabel("New label");
	private final JLabel lblDateView_1 = new JLabel((String) null);
	private final JLabel lblDateView_2 = new JLabel((String) null);
	
	private double num1Income = 1;
	private double num2Income = 2;
	private double num3Income = 3;
	private double num4Income = 4;
	private double num5Income = 5;
	private double num6Income = 6;
	private double num7Income = 7;
	private double num8Income = 8;
	private double num9Income = 9;
	private double sumIncome = 0;
	
	private double num11Expense = 1;
	private double num12Expense = 2;
	private double num13Expense = 3;
	private double num14Expense = 4;
	private double num15Expense = 5;
	private double num16Expense = 6;
	private double num17Expense = 7;
	private double num18Expense = 8;
	private double num19Expense = 9;
	private double sumExpense = 0;
	
	private double ttlNetIncome = 0;

	
	//define the mask
		MaskFormatter ssnMask = createFormatter("### - ## - ####");
	//define the mask
			MaskFormatter SndssnMask = createFormatter("### - ## - ####");
	//SSN Masks for Household Members
			//define the mask
			MaskFormatter spousessnMask = createFormatter("### - ## - ####");
			//define the mask
			MaskFormatter ssnMask_1 = createFormatter("### - ## - ####");
			//define the mask
			MaskFormatter ssnMask_2 = createFormatter("### - ## - ####");
			//define the mask
			MaskFormatter ssnMask_3 = createFormatter("### - ## - ####");
			//define the mask
			MaskFormatter ssnMask_4 = createFormatter("### - ## - ####");
			//define the mask
			MaskFormatter ssnMask_5 = createFormatter("### - ## - ####");
	//phone number mask
		MaskFormatter phoneMask = createFormatter("( ### ) ### - ####");
	//two character state mask
		MaskFormatter DOBMask = createFormatter("##/##/####");		
	//Second Phone Mask
		MaskFormatter sndPhoneMask = createFormatter("( ### ) ### - ####");
	//Second Zip Mask
		MaskFormatter ZipMask = createFormatter("#####");
	//SpouseDOB Mask
		MaskFormatter spouseDOBMask = createFormatter("##/##/####");
		private final JLabel lblMaritalStatus = new JLabel("Marital Status :");
		private final JCheckBox chckbxNotMarried = new JCheckBox("Not Married");
		private final JCheckBox chckbxMarried = new JCheckBox("Married");
		private final ButtonGroup buttonGroup_3 = new ButtonGroup();
		private final JLabel labelNameVariable = new JLabel("");
		private final JLabel labelNameVariable_1 = new JLabel("");
		
		
		
		
		
		
		
	
		
		

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzSACAPframe frame = new SchmitzSACAPframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	//place this code after main()
	public MaskFormatter createFormatter(String s) {
	     MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(s);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	      return formatter;
	}//createFormatter

	/**
	 * Create the frame.
	 */
	public SchmitzSACAPframe() {
		nameTextField_1.setToolTipText("<HTML><center>Enter the Name of Each Household Member Applied</center></HTML>");
		nameTextField_1.setHorizontalAlignment(SwingConstants.CENTER);
		nameTextField_1.setFont(new Font("DialogInput", Font.PLAIN, 16));
		nameTextField_1.setEnabled(false);
		nameTextField_1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_nameTextField_1_focusLost(e);
			}
		});
		nameTextField_1.setBounds(21, 431, 131, 26);
		nameTextField_1.setColumns(10);
		POETextField.setToolTipText("<HTML><center>Input Your Current Employer</center></HTML>");
		POETextField.setHorizontalAlignment(SwingConstants.CENTER);
		POETextField.setEnabled(false);
		POETextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
		POETextField.setBounds(198, 553, 355, 29);
		POETextField.setColumns(10);
		CityTextField.setToolTipText("<HTML><center>Input Your City</center></HTML>");
		CityTextField.setHorizontalAlignment(SwingConstants.CENTER);
		CityTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_CityTextField_focusLost(e);
			}
		});
		CityTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
		CityTextField.setBounds(92, 416, 126, 26);
		CityTextField.setColumns(10);
		FirstNameTextField.setToolTipText("<HTML><center>Input Your First Name</center></HTML>");
		FirstNameTextField.setHorizontalAlignment(SwingConstants.CENTER);
		FirstNameTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_FirstNameTextField_focusLost(e);
			}
		});
		FirstNameTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
		FirstNameTextField.setBounds(149, 78, 404, 20);
		FirstNameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Schmitz - The Salvation Army Client Assistance Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 679, 994);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				do_tabbedPane_stateChanged(arg0);
			}
		});
		
		tabbedPane.setBackground(SystemColor.menu);
		tabbedPane.setBounds(10, 31, 643, 892);
		
		contentPane.add(tabbedPane);
		//set the place holder character
			phoneMask.setPlaceholderCharacter('#');
		//set the place holder character
			ZipMask.setPlaceholderCharacter('#');
		//set the place holder character
			DOBMask.setPlaceholderCharacter('#');
		//set the place holder character
			ssnMask.setPlaceholderCharacter('#');
		//set the place holder character
			SndssnMask.setPlaceholderCharacter('#');
		//set the place holder character
			ssnMask_1.setPlaceholderCharacter('#');
		//set the place holder character
			ssnMask_2.setPlaceholderCharacter('#');
		//set the place holder character
			ssnMask_3.setPlaceholderCharacter('#');
		//set the place holder character
			ssnMask_4.setPlaceholderCharacter('#');
		//set the place holder character
			ssnMask_5.setPlaceholderCharacter('#');
		//set the place holder character
			spousessnMask.setPlaceholderCharacter('#');
		//set the place holder character
			spouseDOBMask.setPlaceholderCharacter('#');
			
		//setNumber of digits to show up
			numFormat.setMinimumFractionDigits(2);
			
		ApplicantPanel.setForeground(Color.WHITE);
		ApplicantPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		ApplicantPanel.setBackground(SystemColor.controlDkShadow);
		
		tabbedPane.addTab("<html><font face=\"Calibri\" size = \"+1\" color = \"white\">Applicant Information</font></html>", null, ApplicantPanel, null);
		tabbedPane.setForegroundAt(0, Color.DARK_GRAY);
		tabbedPane.setBackgroundAt(0, SystemColor.controlDkShadow);
		ApplicantPanel.setLayout(null);
		lblFirstName.setForeground(Color.WHITE);
		lblFirstName.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblFirstName.setBounds(21, 74, 127, 26);
		
		ApplicantPanel.add(lblFirstName);
		
		ApplicantPanel.add(FirstNameTextField);
		lblLastName.setForeground(Color.WHITE);
		lblLastName.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblLastName.setBounds(21, 121, 127, 26);
		
		ApplicantPanel.add(lblLastName);
		LastNameTextField.setToolTipText("<HTML><center>Input Your Last Name</center></HTML>");
		LastNameTextField.setHorizontalAlignment(SwingConstants.CENTER);
		LastNameTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_LastNameTextField_focusLost(e);
			}
		});
		LastNameTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
		LastNameTextField.setColumns(10);
		LastNameTextField.setBounds(149, 125, 404, 20);
		
		ApplicantPanel.add(LastNameTextField);
		lblDateOfBirth.setForeground(Color.WHITE);
		lblDateOfBirth.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblDateOfBirth.setBounds(21, 168, 141, 26);
		
		ApplicantPanel.add(lblDateOfBirth);
		lblAddress.setForeground(Color.WHITE);
		lblAddress.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblAddress.setBounds(21, 274, 92, 26);
		
		ApplicantPanel.add(lblAddress);
		lblCity.setForeground(Color.WHITE);
		lblCity.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblCity.setBounds(21, 414, 64, 26);
		
		ApplicantPanel.add(lblCity);
		lblCounty.setForeground(Color.WHITE);
		lblCounty.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblCounty.setBounds(21, 321, 92, 26);
		
		ApplicantPanel.add(lblCounty);
		lblZip.setForeground(Color.WHITE);
		lblZip.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblZip.setBounds(21, 461, 64, 26);
		
		ApplicantPanel.add(lblZip);
		lblPhoneNumber.setForeground(Color.WHITE);
		lblPhoneNumber.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblPhoneNumber.setBounds(21, 227, 154, 26);
		
		ApplicantPanel.add(lblPhoneNumber);
		
		ApplicantPanel.add(CityTextField);
		AddressTextField.setToolTipText("<HTML><center>Input Your Street Address</center></HTML>");
		AddressTextField.setHorizontalAlignment(SwingConstants.CENTER);
		AddressTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_AddressTextField_focusLost(e);
			}
		});
		AddressTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
		AddressTextField.setColumns(10);
		AddressTextField.setBounds(125, 279, 428, 20);
		
		ApplicantPanel.add(AddressTextField);
		PhoneFormattedTextField.setToolTipText("<HTML><center>Input Your Phone Number Including Area Code</center></HTML>");
		PhoneFormattedTextField.setHorizontalAlignment(SwingConstants.CENTER);
		PhoneFormattedTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
		PhoneFormattedTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_PhoneFormattedTextField_focusLost(e);
			}
		});
		PhoneFormattedTextField.setBounds(176, 230, 377, 20);
		//install the mask
				phoneMask.install(PhoneFormattedTextField);
				ApplicantPanel.add(PhoneFormattedTextField);
				ZipFormattedTextField.setToolTipText("<HTML><center>Input Your Zip Code</center></HTML>");
				ZipFormattedTextField.setHorizontalAlignment(SwingConstants.CENTER);
				ZipFormattedTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
				ZipFormattedTextField.setBounds(81, 463, 119, 26);
				//install the mask
					ZipMask.install(ZipFormattedTextField);
					ApplicantPanel.add(ZipFormattedTextField);
					DOBFormattedTextField.setToolTipText("<HTML><center>Input Your Date Of Birth</center></HTML>");
					DOBFormattedTextField.setHorizontalAlignment(SwingConstants.CENTER);
					DOBFormattedTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
					DOBFormattedTextField.addFocusListener(new FocusAdapter() {
						@Override
						public void focusLost(FocusEvent e) {
							do_DOBFormattedTextField_focusLost(e);
						}
					});
					DOBFormattedTextField.setBounds(149, 172, 404, 20);
					//install the mask
						DOBMask.install(DOBFormattedTextField);
						ApplicantPanel.add(DOBFormattedTextField);
						scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
						scrollPane.setBounds(125, 323, 171, 72);
						
						ApplicantPanel.add(scrollPane);
						list.setToolTipText("<HTML><center>Choose Your County From the Pretermined List</center></HTML>");
						list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						list.setModel(new AbstractListModel() {
							String[] values = new String[] {"Albany County", "Allegany County", "Bronx County", "Broome County", "Cattaraugus County", "Cayuga County", "Chautauqua County", "Chemung County", "Chenango County", "Clinton County", "Columbia County", "Cortland County", "Delaware County", "Dutchess County", "Erie County", "Essex County", "Franklin County", "Fulton County", "Genesee County", "Greene County", "Hamilton County", "Herkimer County", "Jefferson County", "Kings County (Brooklyn)", "Lewis County", "Livingston County", "Madison County", "Monroe County", "Montgomery County", "Nassau County", "New York County (Manhattan)", "Niagara County", "Oneida County", "Onondaga County", "Ontario County", "Orange County", "Orleans County", "Oswego County", "Otsego County", "Putnam County", "Queens County", "Rensselaer County", "Richmond County (Staten Island)", "Rockland County", "Saint Lawrence County", "Saratoga County", "Schenectady County", "Schoharie County", "Schuyler County", "Seneca County", "Steuben County", "Suffolk County", "Sullivan County", "Tioga County", "Tompkins County", "Ulster County", "Warren County", "Washington County", "Wayne County", "Westchester County", "Wyoming County", "Yates County"};
							public int getSize() {
								return values.length;
							}
							public Object getElementAt(int index) {
								return values[index];
							}
						});
						list.setFont(new Font("DialogInput", Font.PLAIN, 16));
						
						scrollPane.setViewportView(list);
									buttonGroup.add(rdbtnWh);
									rdbtnWh.setToolTipText("<HTML><center>Select The Ethnicity That Defines You</center></HTML>");
									rdbtnWh.setForeground(Color.WHITE);
									rdbtnWh.setFont(new Font("DialogInput", Font.PLAIN, 16));
									rdbtnWh.setBackground(SystemColor.controlDkShadow);
									rdbtnWh.setBounds(21, 665, 64, 35);
									
									ApplicantPanel.add(rdbtnWh);
									buttonGroup.add(rdbtnBL);
									rdbtnBL.setToolTipText("<HTML><center>Select The Ethnicity That Defines You</center></HTML>");
									rdbtnBL.setForeground(Color.WHITE);
									rdbtnBL.setFont(new Font("DialogInput", Font.PLAIN, 16));
									rdbtnBL.setBackground(SystemColor.controlDkShadow);
									rdbtnBL.setBounds(89, 665, 73, 35);
									
									ApplicantPanel.add(rdbtnBL);
									buttonGroup.add(rdbtnHIS);
									rdbtnHIS.setToolTipText("<HTML><center>Select The Ethnicity That Defines You</center></HTML>");
									rdbtnHIS.setForeground(Color.WHITE);
									rdbtnHIS.setFont(new Font("DialogInput", Font.PLAIN, 16));
									rdbtnHIS.setBackground(SystemColor.controlDkShadow);
									rdbtnHIS.setBounds(159, 665, 86, 35);
									
									ApplicantPanel.add(rdbtnHIS);
									buttonGroup.add(rdbtnAsian);
									rdbtnAsian.setToolTipText("<HTML><center>Select The Ethnicity That Defines You</center></HTML>");
									rdbtnAsian.setForeground(Color.WHITE);
									rdbtnAsian.setFont(new Font("DialogInput", Font.PLAIN, 16));
									rdbtnAsian.setBackground(SystemColor.controlDkShadow);
									rdbtnAsian.setBounds(241, 665, 92, 35);
									
									ApplicantPanel.add(rdbtnAsian);
									buttonGroup.add(rdbtnAmerInd);
									rdbtnAmerInd.setToolTipText("<HTML><center>Select The Ethnicity That Defines You</center></HTML>");
									rdbtnAmerInd.setForeground(Color.WHITE);
									rdbtnAmerInd.setFont(new Font("DialogInput", Font.PLAIN, 16));
									rdbtnAmerInd.setBackground(SystemColor.controlDkShadow);
									rdbtnAmerInd.setBounds(346, 665, 127, 35);
									
									ApplicantPanel.add(rdbtnAmerInd);
									buttonGroup.add(rdbtnOther);
									rdbtnOther.setToolTipText("<HTML><center>Select The Ethnicity That Defines You</center></HTML>");
									rdbtnOther.setForeground(Color.WHITE);
									rdbtnOther.setFont(new Font("DialogInput", Font.PLAIN, 16));
									rdbtnOther.setBackground(SystemColor.controlDkShadow);
									rdbtnOther.setBounds(476, 665, 102, 35);
									
									ApplicantPanel.add(rdbtnOther);
									lblEthnicity.setForeground(Color.WHITE);
									lblEthnicity.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
									lblEthnicity.setBounds(21, 633, 92, 26);
									
									ApplicantPanel.add(lblEthnicity);
									lblPresentProblem.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
									lblPresentProblem.setForeground(Color.WHITE);
									lblPresentProblem.setBounds(21, 711, 195, 26);
									
									ApplicantPanel.add(lblPresentProblem);
									lblPlaceOfEmployment.setForeground(Color.WHITE);
									lblPlaceOfEmployment.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
									lblPlaceOfEmployment.setBounds(21, 553, 228, 26);
									
									ApplicantPanel.add(lblPlaceOfEmployment);
									
									ApplicantPanel.add(POETextField);
									buttonGroup_1.add(chckbxUneployed);
									chckbxUneployed.setToolTipText("<HTML><center>Select The Box That Applies To Your Employment Status</center></HTML>");
									chckbxUneployed.setSelected(true);
									chckbxUneployed.addActionListener(new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											do_chckbxUneployed_actionPerformed(e);
										}
									});
									chckbxUneployed.setFont(new Font("Dialog", Font.ITALIC, 16));
									chckbxUneployed.setForeground(Color.WHITE);
									chckbxUneployed.setBackground(SystemColor.controlDkShadow);
									chckbxUneployed.setBounds(17, 504, 179, 35);
									
									ApplicantPanel.add(chckbxUneployed);
									buttonGroup_1.add(chckbxEmployed);
									chckbxEmployed.setToolTipText("<HTML><center>Select The Box That Applies To Your Employment Status</center></HTML>");
									chckbxEmployed.addActionListener(new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											do_chckbxEmployed_actionPerformed(e);
										}
									});
									chckbxEmployed.setFont(new Font("Dialog", Font.ITALIC, 16));
									chckbxEmployed.setForeground(Color.WHITE);
									chckbxEmployed.setBackground(SystemColor.controlDkShadow);
									chckbxEmployed.setBounds(209, 504, 179, 35);
									
									ApplicantPanel.add(chckbxEmployed);
									presentProblemTextArea.setToolTipText("<HTML><center>If Any Problems Exist, List Them In The Input Field Here</center></HTML>");
									presentProblemTextArea.setBounds(31, 758, 522, 60);
									
									ApplicantPanel.add(presentProblemTextArea);
									lblFiillOutThe.setForeground(Color.WHITE);
									lblFiillOutThe.setFont(new Font("Dubai", Font.BOLD, 18));
									lblFiillOutThe.setBounds(43, 25, 506, 32);
									
									ApplicantPanel.add(lblFiillOutThe);
									lblDateView.setForeground(Color.WHITE);
									lblDateView.setFont(new Font("Dialog", Font.ITALIC, 16));
									lblDateView.setBounds(546, 0, 92, 26);
									
									lblDateView.setText(getDateTime());
									ApplicantPanel.add(lblDateView);
									lblMaritalStatus.setForeground(Color.WHITE);
									lblMaritalStatus.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
									lblMaritalStatus.setBounds(21, 599, 158, 26);
									
									ApplicantPanel.add(lblMaritalStatus);
									buttonGroup_3.add(chckbxNotMarried);
									chckbxNotMarried.setSelected(true);
									chckbxNotMarried.setToolTipText("<HTML><center>Select The Box That Applies To Your Employment Status</center></HTML>");
									chckbxNotMarried.addActionListener(new ActionListener() {
										public void actionPerformed(ActionEvent arg0) {
											do_chckbxNotMarried_actionPerformed(arg0);
										}
									});
									chckbxNotMarried.setFont(new Font("DialogInput", Font.PLAIN, 16));
									chckbxNotMarried.setForeground(Color.WHITE);
									chckbxNotMarried.setBackground(SystemColor.controlDkShadow);
									chckbxNotMarried.setBounds(154, 596, 179, 35);
									
									ApplicantPanel.add(chckbxNotMarried);
									buttonGroup_3.add(chckbxMarried);
									chckbxMarried.setToolTipText("<HTML><center>Select The Box That Applies To Your Employment Status</center></HTML>");
									chckbxMarried.addActionListener(new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											do_chckbxMarried_actionPerformed(e);
										}
									});
									chckbxMarried.setFont(new Font("DialogInput", Font.PLAIN, 16));
									chckbxMarried.setForeground(Color.WHITE);
									chckbxMarried.setBackground(SystemColor.controlDkShadow);
									chckbxMarried.setBounds(358, 599, 179, 35);
									
									ApplicantPanel.add(chckbxMarried);
		HouseholdPanel.setToolTipText("<HTML><center>Select the Relationship Status of Each Household Member Applied</center></HTML>");
		HouseholdPanel.setBackground(SystemColor.controlDkShadow);
		
		tabbedPane.addTab("<html><font face=\"Calibri\" size = \"+1\" color = \"white\">Household Information</font></html>", null, HouseholdPanel, null);
		HouseholdPanel.setLayout(null);
		lblSpouseName.setForeground(Color.WHITE);
		lblSpouseName.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblSpouseName.setBounds(21, 73, 178, 26);
		
		HouseholdPanel.add(lblSpouseName);
		spouseNametxtField.setToolTipText("<HTML><center>Input The Name Of Your Spouse</center></HTML>");
		spouseNametxtField.setHorizontalAlignment(SwingConstants.CENTER);
		spouseNametxtField.setEnabled(false);
		spouseNametxtField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_spouseNametxtField_focusLost(e);
			}
		});
		
		spouseNametxtField.setFont(new Font("DialogInput", Font.PLAIN, 18));
		spouseNametxtField.setColumns(10);
		spouseNametxtField.setBounds(187, 77, 257, 20);
		
		HouseholdPanel.add(spouseNametxtField);
		lblSpouseDOB.setForeground(Color.WHITE);
		lblSpouseDOB.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblSpouseDOB.setBounds(21, 120, 198, 26);
		
		HouseholdPanel.add(lblSpouseDOB);
		lblIfMarriedFill.setForeground(Color.WHITE);
		lblIfMarriedFill.setFont(new Font("Dubai", Font.BOLD, 18));
		lblIfMarriedFill.setBounds(21, 26, 555, 26);
		
		HouseholdPanel.add(lblIfMarriedFill);
		lblName.setForeground(Color.WHITE);
		lblName.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblName.setBounds(21, 372, 92, 26);
		
		HouseholdPanel.add(lblName);
		lblAge.setForeground(Color.WHITE);
		lblAge.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblAge.setBounds(380, 372, 92, 26);
		
		HouseholdPanel.add(lblAge);
		lblRelationship.setForeground(Color.WHITE);
		lblRelationship.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblRelationship.setBounds(198, 372, 142, 26);
		
		HouseholdPanel.add(lblRelationship);
		lblSsn.setForeground(Color.WHITE);
		lblSsn.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblSsn.setBounds(456, 372, 92, 26);
		
		HouseholdPanel.add(lblSsn);
		
		HouseholdPanel.add(nameTextField_1);
		nameTextField_2.setToolTipText("<HTML><center>Enter the Name of Each Household Member Applied</center></HTML>");
		nameTextField_2.setHorizontalAlignment(SwingConstants.CENTER);
		nameTextField_2.setEnabled(false);
		nameTextField_2.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_nameTextField_2_focusLost(e);
			}
		});
		nameTextField_2.setForeground(Color.white);
		nameTextField_2.setFont(new Font("DialogInput", Font.PLAIN, 16));
		nameTextField_2.setColumns(10);
		nameTextField_2.setBounds(21, 510, 131, 26);
		
		HouseholdPanel.add(nameTextField_2);
		nameTextField_3.setToolTipText("<HTML><center>Enter the Name of Each Household Member Applied</center></HTML>");
		nameTextField_3.setHorizontalAlignment(SwingConstants.CENTER);
		nameTextField_3.setFont(new Font("DialogInput", Font.PLAIN, 16));
		nameTextField_3.setEnabled(false);
		nameTextField_3.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_nameTextField_3_focusLost(e);
			}
		});
		nameTextField_3.setColumns(10);
		nameTextField_3.setBounds(21, 596, 131, 26);
		
		HouseholdPanel.add(nameTextField_3);
		nameTextField_4.setToolTipText("<HTML><center>Enter the Name of Each Household Member Applied</center></HTML>");
		nameTextField_4.setHorizontalAlignment(SwingConstants.CENTER);
		nameTextField_4.setFont(new Font("DialogInput", Font.PLAIN, 16));
		nameTextField_4.setEnabled(false);
		nameTextField_4.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_nameTextField_4_focusLost(e);
			}
		});
		nameTextField_4.setColumns(10);
		nameTextField_4.setBounds(21, 678, 131, 26);
		
		HouseholdPanel.add(nameTextField_4);
		nameTextField_5.setToolTipText("<HTML><center>Enter the Name of Each Household Member Applied</center></HTML>");
		nameTextField_5.setHorizontalAlignment(SwingConstants.CENTER);
		nameTextField_5.setFont(new Font("DialogInput", Font.PLAIN, 16));
		nameTextField_5.setEnabled(false);
		nameTextField_5.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_nameTextField_5_focusLost(e);
			}
		});
		nameTextField_5.setColumns(10);
		nameTextField_5.setBounds(21, 764, 131, 26);
		
		HouseholdPanel.add(nameTextField_5);
		relationshipComboBox_1.setToolTipText("<HTML><center>Select the Relationship Status of Each Household Member Applied</center></HTML>");
		relationshipComboBox_1.setFont(new Font("DialogInput", Font.PLAIN, 14));
		relationshipComboBox_1.setEnabled(false);
		relationshipComboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Child ", "GrandChild ", "Sibling", "Parent", "Grand Parent", "Extended Family ", "Other"}));
		relationshipComboBox_1.setBounds(198, 431, 142, 26);
		
		HouseholdPanel.add(relationshipComboBox_1);
		relationshipComboBox_2.setToolTipText("<HTML><center>Select the Relationship Status of Each Household Member Applied</center></HTML>");
		relationshipComboBox_2.setFont(new Font("DialogInput", Font.PLAIN, 14));
		relationshipComboBox_2.setEnabled(false);
		relationshipComboBox_2.setModel(new DefaultComboBoxModel(new String[] {"Child ", "GrandChild ", "Sibling", "Parent", "Grand Parent", "Extended Family ", "Other"}));
		relationshipComboBox_2.setBounds(198, 510, 142, 26);
		
		HouseholdPanel.add(relationshipComboBox_2);
		relationshipComboBox_3.setToolTipText("<HTML><center>Select the Relationship Status of Each Household Member Applied</center></HTML>");
		relationshipComboBox_3.setFont(new Font("DialogInput", Font.PLAIN, 14));
		relationshipComboBox_3.setEnabled(false);
		relationshipComboBox_3.setModel(new DefaultComboBoxModel(new String[] {"Child ", "GrandChild ", "Sibling", "Parent", "Grand Parent", "Extended Family ", "Other"}));
		relationshipComboBox_3.setBounds(198, 596, 142, 26);
		
		HouseholdPanel.add(relationshipComboBox_3);
		relationshipComboBox_4.setToolTipText("<HTML><center>Select the Relationship Status of Each Household Member Applied</center></HTML>");
		relationshipComboBox_4.setFont(new Font("DialogInput", Font.PLAIN, 14));
		relationshipComboBox_4.setEnabled(false);
		relationshipComboBox_4.setModel(new DefaultComboBoxModel(new String[] {"Child ", "GrandChild ", "Sibling", "Parent", "Grand Parent", "Extended Family ", "Other"}));
		relationshipComboBox_4.setBounds(198, 678, 142, 26);
		
		HouseholdPanel.add(relationshipComboBox_4);
		relationshipComboBox_5.setToolTipText("<HTML><center>Select the Relationship Status of Each Household Member Applied</center></HTML>");
		relationshipComboBox_5.setFont(new Font("DialogInput", Font.PLAIN, 14));
		relationshipComboBox_5.setEnabled(false);
		relationshipComboBox_5.setModel(new DefaultComboBoxModel(new String[] {" Child ", "GrandChild ", "Sibling, Parent", "GrandParent", "ExtendedFamily ", "Other"}));
		relationshipComboBox_5.setBounds(198, 764, 142, 26);
		
		HouseholdPanel.add(relationshipComboBox_5);
		ageComboBox_1.setToolTipText("<HTML><center>Select the Age of Each Household Member Applied</center></HTML>");
		ageComboBox_1.setFont(new Font("DialogInput", Font.PLAIN, 16));
		ageComboBox_1.setEnabled(false);
		ageComboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		ageComboBox_1.setBounds(383, 428, 44, 32);
		
		HouseholdPanel.add(ageComboBox_1);
		ageComboBox_2.setToolTipText("<HTML><center>Select the Age of Each Household Member Applied</center></HTML>");
		ageComboBox_2.setFont(new Font("DialogInput", Font.PLAIN, 16));
		ageComboBox_2.setEnabled(false);
		ageComboBox_2.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		ageComboBox_2.setBounds(383, 507, 44, 32);
		
		HouseholdPanel.add(ageComboBox_2);
		ageComboBox_3.setToolTipText("<HTML><center>Select the Age of Each Household Member Applied</center></HTML>");
		ageComboBox_3.setFont(new Font("DialogInput", Font.PLAIN, 16));
		ageComboBox_3.setEnabled(false);
		ageComboBox_3.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		ageComboBox_3.setBounds(383, 593, 44, 32);
		
		HouseholdPanel.add(ageComboBox_3);
		ageComboBox_4.setToolTipText("<HTML><center>Select the Age of Each Household Member Applied</center></HTML>");
		ageComboBox_4.setFont(new Font("DialogInput", Font.PLAIN, 16));
		ageComboBox_4.setEnabled(false);
		ageComboBox_4.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		ageComboBox_4.setBounds(383, 675, 44, 32);
		
		HouseholdPanel.add(ageComboBox_4);
		ageComboBox_5.setToolTipText("<HTML><center>Select the Age of Each Household Member Applied</center></HTML>");
		ageComboBox_5.setFont(new Font("DialogInput", Font.PLAIN, 16));
		ageComboBox_5.setEnabled(false);
		ageComboBox_5.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		ageComboBox_5.setBounds(383, 761, 44, 32);
		
		HouseholdPanel.add(ageComboBox_5);
		lblInputUpTo.setForeground(Color.WHITE);
		lblInputUpTo.setFont(new Font("Dubai", Font.BOLD | Font.ITALIC, 18));
		lblInputUpTo.setBounds(21, 325, 578, 26);
		
		HouseholdPanel.add(lblInputUpTo);
		HSSNformattedTextField_1.setToolTipText("<HTML><center>Enter the Social Security Number of Each Household Member Applied</center></HTML>");
		HSSNformattedTextField_1.setHorizontalAlignment(SwingConstants.CENTER);
		HSSNformattedTextField_1.setFont(new Font("DialogInput", Font.PLAIN, 14));
		HSSNformattedTextField_1.setEnabled(false);
		HSSNformattedTextField_1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_HSSNformattedTextField_1_focusLost(e);
			}
		});
		HSSNformattedTextField_1.setBounds(456, 428, 143, 29);
		
		//install the mask
		ssnMask_1.install(HSSNformattedTextField_1);
		HouseholdPanel.add(HSSNformattedTextField_1);
		HSSNformattedTextField_2.setToolTipText("<HTML><center>Enter the Social Security Number of Each Household Member Applied</center></HTML>");
		HSSNformattedTextField_2.setHorizontalAlignment(SwingConstants.CENTER);
		HSSNformattedTextField_2.setFont(new Font("DialogInput", Font.PLAIN, 14));
		HSSNformattedTextField_2.setEnabled(false);
		HSSNformattedTextField_2.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_HSSNformattedTextField_2_focusLost(e);
			}
		});
		HSSNformattedTextField_2.setBounds(456, 507, 143, 29);
		
		//install the mask
		ssnMask_2.install(HSSNformattedTextField_2);
		HouseholdPanel.add(HSSNformattedTextField_2);
		HSSNformattedTextField_3.setToolTipText("<HTML><center>Enter the Social Security Number of Each Household Member Applied</center></HTML>");
		HSSNformattedTextField_3.setHorizontalAlignment(SwingConstants.CENTER);
		HSSNformattedTextField_3.setFont(new Font("DialogInput", Font.PLAIN, 14));
		HSSNformattedTextField_3.setEnabled(false);
		HSSNformattedTextField_3.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_HSSNformattedTextField_3_focusLost(e);
			}
		});
		HSSNformattedTextField_3.setBounds(456, 593, 143, 29);
		
		//install the mask
		ssnMask_3.install(HSSNformattedTextField_3);
		HouseholdPanel.add(HSSNformattedTextField_3);
		HSSNformattedTextField_4.setToolTipText("<HTML><center>Enter the Social Security Number of Each Household Member Applied</center></HTML>");
		HSSNformattedTextField_4.setHorizontalAlignment(SwingConstants.CENTER);
		HSSNformattedTextField_4.setFont(new Font("DialogInput", Font.PLAIN, 14));
		HSSNformattedTextField_4.setEnabled(false);
		HSSNformattedTextField_4.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_HSSNformattedTextField_4_focusLost(e);
			}
		});
		HSSNformattedTextField_4.setBounds(456, 675, 143, 29);
		
		//install the mask
		ssnMask_4.install(HSSNformattedTextField_4);
		HouseholdPanel.add(HSSNformattedTextField_4);
		HSSNformattedTextField_5.setToolTipText("<HTML><center>Enter the Social Security Number of Each Household Member Applied</center></HTML>");
		HSSNformattedTextField_5.setHorizontalAlignment(SwingConstants.CENTER);
		HSSNformattedTextField_5.setFont(new Font("DialogInput", Font.PLAIN, 14));
		HSSNformattedTextField_5.setEnabled(false);
		HSSNformattedTextField_5.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_HSSNformattedTextField_5_focusLost(e);
			}
		});
		HSSNformattedTextField_5.setBounds(456, 761, 143, 29);
		
		//install the mask
		ssnMask_5.install(HSSNformattedTextField_5);
		HouseholdPanel.add(HSSNformattedTextField_5);
		buttonGroup_2.add(householdNumNewCheckBox_1);
		householdNumNewCheckBox_1.setToolTipText("<HTML><center>Select The Amount Of Household Memebers You Have</center></HTML>");
		householdNumNewCheckBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_householdNumNewCheckBox_1_actionPerformed(e);
			}
		});
		householdNumNewCheckBox_1.setFont(new Font("DialogInput", Font.PLAIN, 18));
		householdNumNewCheckBox_1.setBackground(SystemColor.controlDkShadow);
		householdNumNewCheckBox_1.setForeground(Color.WHITE);
		householdNumNewCheckBox_1.setBounds(40, 224, 179, 35);
		
		HouseholdPanel.add(householdNumNewCheckBox_1);
		buttonGroup_2.add(householdNumNewCheckBox_2);
		householdNumNewCheckBox_2.setToolTipText("<HTML><center>Select The Amount Of Household Memebers You Have</center></HTML>");
		householdNumNewCheckBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_householdNumNewCheckBox_2_actionPerformed(e);
			}
		});
		householdNumNewCheckBox_2.setFont(new Font("DialogInput", Font.PLAIN, 18));
		householdNumNewCheckBox_2.setBackground(SystemColor.controlDkShadow);
		householdNumNewCheckBox_2.setForeground(Color.WHITE);
		householdNumNewCheckBox_2.setBounds(248, 224, 179, 35);
		
		HouseholdPanel.add(householdNumNewCheckBox_2);
		buttonGroup_2.add(householdNumNewCheckBox_3);
		householdNumNewCheckBox_3.setToolTipText("<HTML><center>Select The Amount Of Household Memebers You Have</center></HTML>");
		householdNumNewCheckBox_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_householdNumNewCheckBox_3_actionPerformed(e);
			}
		});
		householdNumNewCheckBox_3.setFont(new Font("DialogInput", Font.PLAIN, 18));
		householdNumNewCheckBox_3.setBackground(SystemColor.controlDkShadow);
		householdNumNewCheckBox_3.setForeground(Color.WHITE);
		householdNumNewCheckBox_3.setBounds(440, 224, 179, 35);
		
		HouseholdPanel.add(householdNumNewCheckBox_3);
		buttonGroup_2.add(householdNumNewCheckBox_4);
		householdNumNewCheckBox_4.setToolTipText("<HTML><center>Select The Amount Of Household Memebers You Have</center></HTML>");
		householdNumNewCheckBox_4.setHorizontalAlignment(SwingConstants.CENTER);
		householdNumNewCheckBox_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_householdNumNewCheckBox_4_actionPerformed(e);
			}
		});
		householdNumNewCheckBox_4.setFont(new Font("DialogInput", Font.PLAIN, 18));
		householdNumNewCheckBox_4.setBackground(SystemColor.controlDkShadow);
		householdNumNewCheckBox_4.setForeground(Color.WHITE);
		householdNumNewCheckBox_4.setBounds(40, 273, 179, 35);
		
		HouseholdPanel.add(householdNumNewCheckBox_4);
		buttonGroup_2.add(householdNumNewCheckBox_5);
		householdNumNewCheckBox_5.setToolTipText("<HTML><center>Select The Amount Of Household Memebers You Have</center></HTML>");
		householdNumNewCheckBox_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_householdNumNewCheckBox_5_actionPerformed(e);
			}
		});
		householdNumNewCheckBox_5.setFont(new Font("DialogInput", Font.PLAIN, 18));
		householdNumNewCheckBox_5.setBackground(SystemColor.controlDkShadow);
		householdNumNewCheckBox_5.setForeground(Color.WHITE);
		householdNumNewCheckBox_5.setBounds(248, 273, 179, 35);
		
		HouseholdPanel.add(householdNumNewCheckBox_5);
		lblPleaseSelectThe.setForeground(Color.WHITE);
		lblPleaseSelectThe.setFont(new Font("Dubai", Font.BOLD, 18));
		lblPleaseSelectThe.setBounds(21, 181, 578, 26);
		
		HouseholdPanel.add(lblPleaseSelectThe);
		buttonGroup_2.add(chckbxNone);
		chckbxNone.setToolTipText("<HTML><center>Select The Amount Of Household Memebers You Have</center></HTML>");
		chckbxNone.setSelected(true);
		chckbxNone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxNone_actionPerformed(e);
			}
		});
		chckbxNone.setForeground(Color.WHITE);
		chckbxNone.setBackground(SystemColor.controlDkShadow);
		chckbxNone.setFont(new Font("DialogInput", Font.PLAIN, 18));
		chckbxNone.setBounds(440, 272, 179, 35);
		
		HouseholdPanel.add(chckbxNone);
		lblDate.setBounds(527, 811, 92, 26);
		
		
		HouseholdPanel.add(lblDate);
		spouseDOBFTF.setToolTipText("<HTML><center>Input the Date Of Birth Of Your Spouse</center></HTML>");
		spouseDOBFTF.setHorizontalAlignment(SwingConstants.CENTER);
		spouseDOBFTF.setEnabled(false);
		spouseDOBFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_spouseDOBFTF_focusLost(e);
			}
		});
		spouseDOBFTF.setFont(new Font("DialogInput", Font.PLAIN, 16));
		spouseDOBFTF.setBounds(197, 122, 247, 20);
		
		//install the mask
			spouseDOBMask.install(spouseDOBFTF);
		HouseholdPanel.add(spouseDOBFTF);
		lblDateView_1.setForeground(Color.WHITE);
		lblDateView_1.setFont(new Font("Dialog", Font.ITALIC, 16));
		lblDateView_1.setBounds(546, 0, 92, 26);
		
		lblDateView_1.setText(getDateTime());
		HouseholdPanel.add(lblDateView_1);
		labelNameVariable.setForeground(Color.WHITE);
		labelNameVariable.setFont(new Font("Dubai", Font.PLAIN, 16));
		labelNameVariable.setBounds(0, -1, 178, 26);
		
		HouseholdPanel.add(labelNameVariable);
		tabbedPane.setBackgroundAt(1, SystemColor.controlDkShadow);
		FinancialPanel.setBackground(SystemColor.controlDkShadow);
		
		tabbedPane.addTab("<html><font face=\"Calibri\" size = \"+1\" color = \"white\">Financial Information</font></html>", null, FinancialPanel, null);
		FinancialPanel.setLayout(null);
		lblExpenses.setForeground(Color.WHITE);
		lblExpenses.setFont(new Font("Dubai", Font.BOLD, 18));
		lblExpenses.setBounds(386, 139, 120, 26);
		
		FinancialPanel.add(lblExpenses);
		lblIncome.setForeground(Color.WHITE);
		lblIncome.setFont(new Font("Dubai", Font.BOLD, 18));
		lblIncome.setBounds(86, 139, 92, 26);
		
		FinancialPanel.add(lblIncome);
		lblSalary.setForeground(Color.WHITE);
		lblSalary.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblSalary.setBounds(21, 186, 127, 26);
		
		FinancialPanel.add(lblSalary);
		lblUnemployment.setForeground(Color.WHITE);
		lblUnemployment.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblUnemployment.setBounds(21, 237, 143, 26);
		
		FinancialPanel.add(lblUnemployment);
		lblTanfafdc.setForeground(Color.WHITE);
		lblTanfafdc.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblTanfafdc.setBounds(21, 284, 135, 26);
		
		FinancialPanel.add(lblTanfafdc);
		lblSocialSecurity_1.setForeground(Color.WHITE);
		lblSocialSecurity_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblSocialSecurity_1.setBounds(21, 331, 135, 26);
		
		FinancialPanel.add(lblSocialSecurity_1);
		lblDisability.setForeground(Color.WHITE);
		lblDisability.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblDisability.setBounds(21, 378, 135, 26);
		
		FinancialPanel.add(lblDisability);
		lblChildSupport.setForeground(Color.WHITE);
		lblChildSupport.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblChildSupport.setBounds(21, 425, 135, 26);
		
		FinancialPanel.add(lblChildSupport);
		lblUtilityAssistance.setForeground(Color.WHITE);
		lblUtilityAssistance.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblUtilityAssistance.setBounds(21, 472, 170, 26);
		
		FinancialPanel.add(lblUtilityAssistance);
		lblFoodStamps.setForeground(Color.WHITE);
		lblFoodStamps.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblFoodStamps.setBounds(21, 519, 135, 26);
		
		FinancialPanel.add(lblFoodStamps);
		lblOther.setForeground(Color.WHITE);
		lblOther.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblOther.setBounds(21, 566, 135, 26);
		
		FinancialPanel.add(lblOther);
	
		
		SalaryFormattedTextField.setForeground(Color.WHITE);
		SalaryFormattedTextField.setBackground(Color.DARK_GRAY);
		SalaryFormattedTextField.setBounds(171, 186, 92, 30);
		
		//initialize the numTextFields to start at 0
			SalaryFormattedTextField.setValue(0);
			SalaryFormattedTextField.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(SalaryFormattedTextField);
		
	
		unemploymentFTF.setForeground(Color.WHITE);
		unemploymentFTF.setBackground(Color.DARK_GRAY);
		unemploymentFTF.setBounds(171, 233, 92, 30);
		
		//initialize the numTextFields to start at 0
			unemploymentFTF.setValue(0);
			unemploymentFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(unemploymentFTF);
		
		TAFTF.setForeground(Color.WHITE);
		TAFTF.setBackground(Color.DARK_GRAY);
		TAFTF.setBounds(171, 280, 92, 30);
		
		//initialize the numTextFields to start at 0
			TAFTF.setValue(0);
			TAFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(TAFTF);
		
		socialSecurityFTF.setForeground(Color.WHITE);
		socialSecurityFTF.setBackground(Color.DARK_GRAY);
		socialSecurityFTF.setBounds(171, 327, 92, 30);
		
		//initialize the numTextFields to start at 0
			socialSecurityFTF.setValue(0);
			socialSecurityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(socialSecurityFTF);
		
		
		disabilityFTF.setForeground(Color.WHITE);
		disabilityFTF.setBackground(Color.DARK_GRAY);
		disabilityFTF.setBounds(171, 374, 92, 30);
		
		//initialize the numTextFields to start at 0
			disabilityFTF.setValue(0);
			disabilityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(disabilityFTF);
		
		
		childSupportFTF.setForeground(Color.WHITE);
		childSupportFTF.setBackground(Color.DARK_GRAY);
		childSupportFTF.setBounds(171, 421, 92, 30);
		
		//initialize the numTextFields to start at 0
			childSupportFTF.setValue(0);
			childSupportFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(childSupportFTF);
		
		
		utilityAssistanceFTF.setForeground(Color.WHITE);
		utilityAssistanceFTF.setBackground(Color.DARK_GRAY);
		utilityAssistanceFTF.setBounds(171, 468, 92, 30);
		
		//initialize the numTextFields to start at 0
			utilityAssistanceFTF.setValue(0);
			utilityAssistanceFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(utilityAssistanceFTF);
		
	
		foodStampsFTF.setForeground(Color.WHITE);
		foodStampsFTF.setBackground(Color.DARK_GRAY);
		foodStampsFTF.setBounds(171, 515, 92, 30);
		
		//initialize the numTextFields to start at 0
			foodStampsFTF.setValue(0);
			foodStampsFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(foodStampsFTF);
		
	
		incomeOtherFTF.setForeground(Color.WHITE);
		incomeOtherFTF.setBackground(Color.DARK_GRAY);
		incomeOtherFTF.setBounds(171, 562, 92, 30);
		
		//initialize the numTextFields to start at 0
			incomeOtherFTF.setValue(0);
			incomeOtherFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(incomeOtherFTF);
		
		
		rentFTF.setForeground(Color.RED);
		rentFTF.setBackground(Color.DARK_GRAY);
		rentFTF.setBounds(497, 186, 92, 30);
		
		//initialize the numTextFields to start at 0
			rentFTF.setValue(0);
			rentFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(rentFTF);
		
		
		phoneBillFTF.setForeground(Color.RED);
		phoneBillFTF.setBackground(Color.DARK_GRAY);
		phoneBillFTF.setBounds(497, 233, 92, 30);
		
		//initialize the numTextFields to start at 0
			phoneBillFTF.setValue(0);
			phoneBillFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(phoneBillFTF);
		
		
		gasWaterBillFTF.setForeground(Color.RED);
		gasWaterBillFTF.setBackground(Color.DARK_GRAY);
		gasWaterBillFTF.setBounds(497, 280, 92, 30);
		
		//initialize the numTextFields to start at 0
			gasWaterBillFTF.setValue(0);
			gasWaterBillFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(gasWaterBillFTF);
		
		
		lightBillFTF.setForeground(Color.RED);
		lightBillFTF.setBackground(Color.DARK_GRAY);
		lightBillFTF.setBounds(497, 327, 92, 30);
		
		//initialize the numTextFields to start at 0
			lightBillFTF.setValue(0);
			lightBillFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(lightBillFTF);
		
		
		carPaymentFTF.setForeground(Color.RED);
		carPaymentFTF.setBackground(Color.DARK_GRAY);
		carPaymentFTF.setBounds(497, 374, 92, 30);
		
		//initialize the numTextFields to start at 0
			carPaymentFTF.setValue(0);
			carPaymentFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(carPaymentFTF);
		
		
		furnAppliancesFTF.setForeground(Color.RED);
		furnAppliancesFTF.setBackground(Color.DARK_GRAY);
		furnAppliancesFTF.setBounds(497, 421, 92, 30);
		
		//initialize the numTextFields to start at 0
			furnAppliancesFTF.setValue(0);
			furnAppliancesFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(furnAppliancesFTF);
		
		
		cableTVFTF.setForeground(Color.RED);
		cableTVFTF.setBackground(Color.DARK_GRAY);
		cableTVFTF.setBounds(497, 468, 92, 30);
		
		//initialize the numTextFields to start at 0
			cableTVFTF.setValue(0);
			cableTVFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(cableTVFTF);
		
		
		doctorMedicalFTF.setForeground(Color.RED);
		doctorMedicalFTF.setBackground(Color.DARK_GRAY);
		doctorMedicalFTF.setBounds(497, 515, 92, 30);
		
		//initialize the numTextFields to start at 0
			doctorMedicalFTF.setValue(0);
			doctorMedicalFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(doctorMedicalFTF);
		
	
		expenseOtherFTF.setForeground(Color.RED);
		expenseOtherFTF.setBackground(Color.DARK_GRAY);
		expenseOtherFTF.setBounds(497, 562, 92, 30);
		
		//initialize the numTextFields to start at 0
			expenseOtherFTF.setValue(0);
			expenseOtherFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(expenseOtherFTF);
		lblRent.setForeground(Color.WHITE);
		lblRent.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblRent.setBounds(329, 186, 170, 26);
		
		FinancialPanel.add(lblRent);
		lblPhoneBill.setForeground(Color.WHITE);
		lblPhoneBill.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblPhoneBill.setBounds(329, 236, 170, 26);
		
		FinancialPanel.add(lblPhoneBill);
		lblGaswater.setForeground(Color.WHITE);
		lblGaswater.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblGaswater.setBounds(329, 283, 170, 26);
		
		FinancialPanel.add(lblGaswater);
		lblLightBill.setForeground(Color.WHITE);
		lblLightBill.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblLightBill.setBounds(329, 330, 170, 26);
		
		FinancialPanel.add(lblLightBill);
		lblCarPayment.setForeground(Color.WHITE);
		lblCarPayment.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblCarPayment.setBounds(329, 377, 170, 26);
		
		FinancialPanel.add(lblCarPayment);
		lblFurnappliances.setForeground(Color.WHITE);
		lblFurnappliances.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblFurnappliances.setBounds(329, 424, 170, 26);
		
		FinancialPanel.add(lblFurnappliances);
		lblCableTv.setForeground(Color.WHITE);
		lblCableTv.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblCableTv.setBounds(329, 471, 170, 26);
		
		FinancialPanel.add(lblCableTv);
		lblDoctormedical.setForeground(Color.WHITE);
		lblDoctormedical.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblDoctormedical.setBounds(329, 518, 170, 26);
		
		FinancialPanel.add(lblDoctormedical);
		lblOther_1.setForeground(Color.WHITE);
		lblOther_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblOther_1.setBounds(329, 565, 170, 26);
		
		FinancialPanel.add(lblOther_1);
		expenseSumFTF.setToolTipText("<HTML><center>The Total Sum of All Expense Fields</center></HTML>");
		
		expenseSumFTF.setBackground(Color.DARK_GRAY);
		expenseSumFTF.setForeground(Color.WHITE);
		expenseSumFTF.setFont(new Font("Dialog", Font.BOLD, 16));
		expenseSumFTF.setEditable(false);
		expenseSumFTF.setBounds(432, 647, 157, 30);
		
		//initialize the numTextFields to start at 0
		expenseSumFTF.setValue(0);
		expenseSumFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(expenseSumFTF);
		lblTotalIncome.setForeground(Color.WHITE);
		lblTotalIncome.setFont(new Font("Dialog", Font.BOLD, 16));
		lblTotalIncome.setBounds(21, 648, 92, 26);
		
		FinancialPanel.add(lblTotalIncome);
		lblTotal.setForeground(Color.WHITE);
		lblTotal.setFont(new Font("Dialog", Font.BOLD, 16));
		lblTotal.setBounds(329, 647, 92, 26);
		
		FinancialPanel.add(lblTotal);
		incomeSumFTF.setToolTipText("<HTML><center>The Total Sum of All Income Fields</center></HTML>");
		
		incomeSumFTF.setForeground(Color.WHITE);
		incomeSumFTF.setFont(new Font("Dialog", Font.BOLD, 16));
		incomeSumFTF.setEditable(false);
		incomeSumFTF.setBackground(Color.DARK_GRAY);
		incomeSumFTF.setBounds(95, 647, 157, 30);
		
		//initialize the numTextFields to start at 0
			incomeSumFTF.setValue(0);
			incomeSumFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(incomeSumFTF);
		lblTotalNetIncome.setForeground(Color.WHITE);
		lblTotalNetIncome.setBackground(new Color(255, 255, 255));
		lblTotalNetIncome.setFont(new Font("Dialog", Font.BOLD, 16));
		lblTotalNetIncome.setBounds(117, 735, 157, 26);
		
		FinancialPanel.add(lblTotalNetIncome);
		totalNetIncome.setToolTipText("<HTML><center>The Total Net Income = Total Income - Total Expenses</center></HTML>");
		totalNetIncome.setHorizontalAlignment(SwingConstants.RIGHT);
		totalNetIncome.setForeground(Color.WHITE);
		totalNetIncome.setFont(new Font("Dialog", Font.BOLD, 16));
		totalNetIncome.setEditable(false);
		totalNetIncome.setBackground(Color.DARK_GRAY);
		totalNetIncome.setBounds(264, 734, 157, 30);
		
		//initialize the numTextFields to start at 0
			totalNetIncome.setValue(0);
			totalNetIncome.setHorizontalAlignment(SwingConstants.RIGHT);
		FinancialPanel.add(totalNetIncome);
		lblSpouseSocialSecurity.setForeground(Color.WHITE);
		lblSpouseSocialSecurity.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblSpouseSocialSecurity.setBounds(21, 95, 268, 26);
		
		FinancialPanel.add(lblSpouseSocialSecurity);
		spouseSSNFormattedTextField.setToolTipText("<HTML><center>Input The Social Security Number Of Your Spouse</center></HTML>");
		spouseSSNFormattedTextField.setEnabled(false);
		spouseSSNFormattedTextField.setHorizontalAlignment(SwingConstants.CENTER);
		spouseSSNFormattedTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_spouseSSNFormattedTextField_focusLost(e);
			}
		});
		spouseSSNFormattedTextField.setFont(new Font("DialogInput", Font.PLAIN, 18));
		spouseSSNFormattedTextField.setBounds(286, 98, 240, 20);
		
		//install the mask
			SndssnMask.install(spouseSSNFormattedTextField);
		FinancialPanel.add(spouseSSNFormattedTextField);
		SocialSecuirtyFormattedTextField.setToolTipText("<HTML><center>Input Your Social Secuirty Number</center></HTML>");
		SocialSecuirtyFormattedTextField.setHorizontalAlignment(SwingConstants.CENTER);
		SocialSecuirtyFormattedTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_SocialSecuirtyFormattedTextField_focusLost(e);
			}
		});
		
		SocialSecuirtyFormattedTextField.setFont(new Font("DialogInput", Font.PLAIN, 16));
		SocialSecuirtyFormattedTextField.setBounds(222, 54, 304, 20);
		
		//install the mask
			ssnMask.install(SocialSecuirtyFormattedTextField);
		FinancialPanel.add(SocialSecuirtyFormattedTextField);
		lblSocialSecurity.setForeground(Color.WHITE);
		lblSocialSecurity.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblSocialSecurity.setBounds(21, 48, 478, 26);
		
		FinancialPanel.add(lblSocialSecurity);
		lblEnterYourFinancial.setFont(new Font("Dubai", Font.BOLD, 18));
		lblEnterYourFinancial.setForeground(Color.WHITE);
		lblEnterYourFinancial.setBounds(144, 10, 382, 26);
		
		FinancialPanel.add(lblEnterYourFinancial);
		lblDateView_2.setForeground(Color.WHITE);
		lblDateView_2.setFont(new Font("Dialog", Font.ITALIC, 16));
		lblDateView_2.setBounds(547, 0, 92, 26);
		
		lblDateView_2.setText(getDateTime());
		FinancialPanel.add(lblDateView_2);
		labelNameVariable_1.setForeground(Color.WHITE);
		labelNameVariable_1.setFont(new Font("Dubai", Font.PLAIN, 16));
		labelNameVariable_1.setBounds(0, 1, 178, 26);
		
		FinancialPanel.add(labelNameVariable_1);
		tabbedPane.setBackgroundAt(2, SystemColor.controlDkShadow);
		menuBar.setFont(new Font("Arial", Font.BOLD, 20));
		menuBar.setForeground(Color.DARK_GRAY);
		menuBar.setBackground(SystemColor.menu);
		menuBar.setBounds(0, 0, 663, 27);
		
		contentPane.add(menuBar);
		mnFile.setForeground(Color.BLACK);
		mnFile.setBackground(SystemColor.menu);
		mnFile.setFont(new Font("Calibri", Font.PLAIN, 20));
		
		menuBar.add(mnFile);
		mntmPplication.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmPplication_actionPerformed(e);
			}
		});
		
		mnFile.add(mntmPplication);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmExit_actionPerformed(arg0);
			}
		});
		
		mnFile.add(mntmExit);
		mnHelp.setForeground(Color.BLACK);
		mnHelp.setBackground(SystemColor.menu);
		mnHelp.setFont(new Font("Calibri", Font.PLAIN, 20));
		
		menuBar.add(mnHelp);
		mntmApplicantInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmApplicantInfo_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmApplicantInfo);
		mntmHouseholdInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmHouseholdInfo_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmHouseholdInfo);
		mntmFinancialInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmFinancialInfo_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmFinancialInfo);
		
		
		SalaryFormattedTextField.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
				do_SalaryFormattedTextField_propertyChange(arg0);
			}
		});
		
		unemploymentFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_unemploymentFTF_propertyChange(evt);
			}
		});
		
		TAFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_TAFTF_propertyChange(evt);
			}
		});
		
		socialSecurityFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_socialSecurityFTF_propertyChange(evt);
			}
		});
		
		disabilityFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_disabilityFTF_propertyChange(evt);
			}
		});
		
		childSupportFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_childSupportFTF_propertyChange(evt);
			}
		});
		
		utilityAssistanceFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_utilityAssistanceFTF_propertyChange(evt);
			}
		});
		
		foodStampsFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_foodStampsFTF_propertyChange(evt);
			}
		});
		
		incomeOtherFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_incomeOtherFTF_propertyChange(evt);
			}
		});
		
		rentFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_rentFTF_propertyChange(evt);
			}
		});
		
		phoneBillFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_phoneBillFTF_propertyChange(evt);
			}
		});
		
		gasWaterBillFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_gasWaterBillFTF_propertyChange(evt);
			}
		});
		
		lightBillFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_lightBillFTF_propertyChange(evt);
			}
		});
		
		carPaymentFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_carPaymentFTF_propertyChange(evt);
			}
		});
		
		furnAppliancesFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_furnAppliancesFTF_propertyChange(evt);
			}
		});
		
		cableTVFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_cableTVFTF_propertyChange(evt);
			}
		});
		
		doctorMedicalFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_doctorMedicalFTF_propertyChange(evt);
			}
		});
		
		expenseOtherFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_expenseOtherFTF_propertyChange(evt);
			}
		});
		
		expenseSumFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_expenseSumFTF_propertyChange(evt);
			}
		});
		
		incomeSumFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_incomeSumFTF_propertyChange(evt);
			}
		});
	}
	//Validation checks for fields, I had all the error messages for each field but in peer review users said it made the program difficult to use having too many pop ups so im limiting the amount
	protected void do_FirstNameTextField_focusLost(FocusEvent e) {
		if(FirstNameTextField.getText().isEmpty()) 
		{
			//JOptionPane.showMessageDialog(this, "You Must Input a First Name To Continue", "Error Message", JOptionPane.ERROR_MESSAGE);
			lblFirstName.setForeground(Color.red);
			//FirstNameTextField.grabFocus();
		}//if
		else {
			lblFirstName.setForeground(Color.white);
			labelNameVariable.setText("Name : " + FirstNameTextField.getText() + " " + LastNameTextField.getText());
			labelNameVariable_1.setText("Name : " + FirstNameTextField.getText() + " " + LastNameTextField.getText());
		}
	}
	protected void do_LastNameTextField_focusLost(FocusEvent e) {
		if(LastNameTextField.getText().isEmpty()) 
		{
			//JOptionPane.showMessageDialog(this, "You Must Input a Last Name To Continue", "Error Message", JOptionPane.ERROR_MESSAGE);
			lblLastName.setForeground(Color.red);
			//LastNameTextField.grabFocus();
		}//if
		else {
			lblLastName.setForeground(Color.white);
			labelNameVariable.setText("Name : " + FirstNameTextField.getText() + " " + LastNameTextField.getText());
			labelNameVariable_1.setText("Name : " + FirstNameTextField.getText() + " " + LastNameTextField.getText());
		}
	}
	protected void do_CityTextField_focusLost(FocusEvent e) {
		if(CityTextField.getText().isEmpty()) 
		{
			//JOptionPane.showMessageDialog(this, "You Must Input a City Name To Continue", "Error Message", JOptionPane.ERROR_MESSAGE);
			lblCity.setForeground(Color.red);
			//CityTextField.grabFocus();
		}//if
		else {
			lblCity.setForeground(Color.white);
		}
	}
	protected void do_AddressTextField_focusLost(FocusEvent e) {
		if(AddressTextField.getText().isEmpty()) 
		{
			//JOptionPane.showMessageDialog(this, "You Must Input a Address Name To Continue", "Error Message", JOptionPane.ERROR_MESSAGE);
			lblAddress.setForeground(Color.red);
			//AddressTextField.grabFocus();
		}//if
		else {
			lblAddress.setForeground(Color.white);
		}
	}
	protected void do_DOBFormattedTextField_focusLost(FocusEvent e) {
		String DOB = DOBFormattedTextField.getText();
		 if(DOB.indexOf('#')>=0) {
			 lblDateOfBirth.setForeground(Color.red);
			 //JOptionPane.showMessageDialog(this, "You Must Input a Date To Continue", "Error Message", JOptionPane.ERROR_MESSAGE);
			 //DOBFormattedTextField.grabFocus();
		 }
		 else {
			 lblDateOfBirth.setForeground(Color.white);
		 }
	}
	protected void do_mntmExit_actionPerformed(ActionEvent arg0) {
		this.dispose();
	}
	//Here is the help tab tasks and information
	protected void do_mntmApplicantInfo_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this, "<HTML><center>For Date Of Birth, Phone Number, and Zip field fill in the '#' symbols <br></br> Select One Ethnicity <br></br> If employed check the corresponding box and fill in the employer <br></br> The rest of the fields can be filled in as listed</center> </HTML>", "Applicant Information", JOptionPane.INFORMATION_MESSAGE);
	}
	protected void do_mntmHouseholdInfo_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this, "<HTML><center>If applicable, fill in spouse information<br></br>From the check boxes, select the number of Household members in your house or leave selected as 'None'<br></br>Fill in the Name, Relationship, Age, and Social Security Number for each Household Member</center></HTML>", "Household Information", JOptionPane.INFORMATION_MESSAGE);
	}
	protected void do_mntmFinancialInfo_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this, "<HTML><center>Fill in the personal Social Security Field<br></br>The Spouse Social Security Field can be filled in if applicable<br></br>For Income and Expenses all values are defaulted to 0, fill in the corresponding fields based on personal finances and totals will be displayed at the bottom</center></HTML>", "Financial Information", JOptionPane.INFORMATION_MESSAGE);
	}
	protected void do_mntmPplication_actionPerformed(ActionEvent e) {
		Object[] options = { "NO", "YES"};
		if(JOptionPane.showConfirmDialog(this, "Are you Sure you Would like to Exit the Program?\n\nDoing so Will Wipe the Application Clean\n\n", "Exit Message", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {	
			//reset all fields here
			SchmitzSACAPframe frame = new SchmitzSACAPframe();    
		    frame.setVisible(true);
		    
		    this.dispose();
		}
	}
	protected void do_PhoneFormattedTextField_focusLost(FocusEvent e) {
		String PhoneNum = PhoneFormattedTextField.getText();
		 if(PhoneNum.indexOf('#')>=0) {
			 //JOptionPane.showMessageDialog(this, "You Must Input a Phone Number To Continue", "Error Message", JOptionPane.ERROR_MESSAGE);
			 lblPhoneNumber.setForeground(Color.red);
			 //PhoneFormattedTextField.grabFocus();
		 }
		 else {
			 lblPhoneNumber.setForeground(Color.white);
		 }
	}
	protected void do_nameTextField_1_focusLost(FocusEvent e) {
		if(nameTextField_1.getText().isEmpty()) 
		{
			JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Name For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
			//nameTextField_1.grabFocus();
			lblName.setForeground(Color.red);
		}//if
		else {
			lblName.setForeground(Color.white);
		}
	}
	protected void do_nameTextField_2_focusLost(FocusEvent e) {
		if(nameTextField_2.getText().isEmpty()) 
		{
			JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Name For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
			//nameTextField_2.grabFocus();
			lblName.setForeground(Color.red);
		}//if
		else {
			lblName.setForeground(Color.white);
		}
	}
	protected void do_nameTextField_3_focusLost(FocusEvent e) {
		if(nameTextField_3.getText().isEmpty()) 
		{
			JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Name For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
			//nameTextField_3.grabFocus();
			lblName.setForeground(Color.red);
		}//if
		else {
			lblName.setForeground(Color.white);
		}
	}
	protected void do_nameTextField_4_focusLost(FocusEvent e) {
		if(nameTextField_4.getText().isEmpty()) 
		{
			JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Name For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
			//nameTextField_4.grabFocus();
			lblName.setForeground(Color.red);
		}//if
		else {
			lblName.setForeground(Color.white);
		}
	}
	protected void do_nameTextField_5_focusLost(FocusEvent e) {
		if(nameTextField_5.getText().isEmpty()) 
		{
			JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Name For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
			//nameTextField_5.grabFocus();
			lblName.setForeground(Color.red);
		}//if
		else {
			lblName.setForeground(Color.white);
		}
	}
	
	//Setting the error checking for the household SSN Numbers
			protected void do_HSSNformattedTextField_1_focusLost(FocusEvent e) {
				String SSN = HSSNformattedTextField_1.getText();
				 if(SSN.indexOf('#')>=0) {
					 lblSsn.setForeground(Color.red);
					 JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Valid SSN For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
					 //SocialSecuirtyFormattedTextField.grabFocus();
				 }
				 else {
					 lblSsn.setForeground(Color.white);
				 }
			}
			protected void do_HSSNformattedTextField_2_focusLost(FocusEvent e) {
				String SSN = HSSNformattedTextField_2.getText();
				 if(SSN.indexOf('#')>=0) {
					 lblSsn.setForeground(Color.red);
					 JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Valid SSN For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
					 //SocialSecuirtyFormattedTextField.grabFocus();
				 }
				 else {
					 lblSsn.setForeground(Color.white);
				 }
			}
			protected void do_HSSNformattedTextField_3_focusLost(FocusEvent e) {
				String SSN = HSSNformattedTextField_3.getText();
				 if(SSN.indexOf('#')>=0) {
					 lblSsn.setForeground(Color.red);
					 JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Valid SSN For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
					 //SocialSecuirtyFormattedTextField.grabFocus();
				 }
				 else {
					 lblSsn.setForeground(Color.white);
				 }
			}
			protected void do_HSSNformattedTextField_4_focusLost(FocusEvent e) {
				String SSN = HSSNformattedTextField_4.getText();
				 if(SSN.indexOf('#')>=0) {
					 lblSsn.setForeground(Color.red);
					 JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Valid SSN For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
					 //SocialSecuirtyFormattedTextField.grabFocus();
				 }
				 else {
					 lblSsn.setForeground(Color.white);
				 }
			}
			protected void do_HSSNformattedTextField_5_focusLost(FocusEvent e) {
				String SSN = HSSNformattedTextField_5.getText();
				 if(SSN.indexOf('#')>=0) {
					 lblSsn.setForeground(Color.red);
					 JOptionPane.showMessageDialog(this, "Careful : You Have Not Inputed a Valid SSN For this Household Member", "Error Message", JOptionPane.ERROR_MESSAGE);
					 //SocialSecuirtyFormattedTextField.grabFocus();
				 }
				 else {
					 lblSsn.setForeground(Color.white);
				 }
			}
	
	//If focus lost for spouse fields then display errors if not filled it. Not Required Fields so only change color to red
	protected void do_spouseNametxtField_focusLost(FocusEvent e) {
		if(spouseNametxtField.getText().isEmpty()) {
			lblSpouseName.setForeground(Color.red);
		}
		else {
			lblSpouseName.setForeground(Color.white);
		}
	}
	//enabling and disabling the number of household members based on the box checked
	protected void do_householdNumNewCheckBox_1_actionPerformed(ActionEvent e) {
	//enable the correct field
		nameTextField_1.setEnabled(isEnabled());
		relationshipComboBox_1.setEnabled(isEnabled());
		ageComboBox_1.setEnabled(isEnabled());
		HSSNformattedTextField_1.setEnabled(isEnabled());
	//disable all incorrect fields
		nameTextField_2.setEnabled(!isEnabled());
		relationshipComboBox_2.setEnabled(!isEnabled());
		ageComboBox_2.setEnabled(!isEnabled());
		HSSNformattedTextField_2.setEnabled(!isEnabled());
		
		nameTextField_3.setEnabled(!isEnabled());
		relationshipComboBox_3.setEnabled(!isEnabled());
		ageComboBox_3.setEnabled(!isEnabled());
		HSSNformattedTextField_3.setEnabled(!isEnabled());
		
		nameTextField_4.setEnabled(!isEnabled());
		relationshipComboBox_4.setEnabled(!isEnabled());
		ageComboBox_4.setEnabled(!isEnabled());
		HSSNformattedTextField_4.setEnabled(!isEnabled());
		
		nameTextField_5.setEnabled(!isEnabled());
		relationshipComboBox_5.setEnabled(!isEnabled());
		ageComboBox_5.setEnabled(!isEnabled());
		HSSNformattedTextField_5.setEnabled(!isEnabled());
		
	}
	protected void do_householdNumNewCheckBox_2_actionPerformed(ActionEvent e) {
	//enable the correct field
		nameTextField_1.setEnabled(isEnabled());
		relationshipComboBox_1.setEnabled(isEnabled());
		ageComboBox_1.setEnabled(isEnabled());
		HSSNformattedTextField_1.setEnabled(isEnabled());
		
		nameTextField_2.setEnabled(isEnabled());
		relationshipComboBox_2.setEnabled(isEnabled());
		ageComboBox_2.setEnabled(isEnabled());
		HSSNformattedTextField_2.setEnabled(isEnabled());
	//disable all incorrect fields	
		nameTextField_3.setEnabled(!isEnabled());
		relationshipComboBox_3.setEnabled(!isEnabled());
		ageComboBox_3.setEnabled(!isEnabled());
		HSSNformattedTextField_3.setEnabled(!isEnabled());
		
		nameTextField_4.setEnabled(!isEnabled());
		relationshipComboBox_4.setEnabled(!isEnabled());
		ageComboBox_4.setEnabled(!isEnabled());
		HSSNformattedTextField_4.setEnabled(!isEnabled());
		
		nameTextField_5.setEnabled(!isEnabled());
		relationshipComboBox_5.setEnabled(!isEnabled());
		ageComboBox_5.setEnabled(!isEnabled());
		HSSNformattedTextField_5.setEnabled(!isEnabled());
	}
	protected void do_householdNumNewCheckBox_3_actionPerformed(ActionEvent e) {
	//enable the correct field
		nameTextField_1.setEnabled(isEnabled());
		relationshipComboBox_1.setEnabled(isEnabled());
		ageComboBox_1.setEnabled(isEnabled());
		HSSNformattedTextField_1.setEnabled(isEnabled());
				
		nameTextField_2.setEnabled(isEnabled());
		relationshipComboBox_2.setEnabled(isEnabled());
		ageComboBox_2.setEnabled(isEnabled());
		HSSNformattedTextField_2.setEnabled(isEnabled());
		
		nameTextField_3.setEnabled(isEnabled());
		relationshipComboBox_3.setEnabled(isEnabled());
		ageComboBox_3.setEnabled(isEnabled());
		HSSNformattedTextField_3.setEnabled(isEnabled());
	//disable all incorrect fields	
		nameTextField_4.setEnabled(!isEnabled());
		relationshipComboBox_4.setEnabled(!isEnabled());
		ageComboBox_4.setEnabled(!isEnabled());
		HSSNformattedTextField_4.setEnabled(!isEnabled());
		
		nameTextField_5.setEnabled(!isEnabled());
		relationshipComboBox_5.setEnabled(!isEnabled());
		ageComboBox_5.setEnabled(!isEnabled());
		HSSNformattedTextField_5.setEnabled(!isEnabled());
	}
	protected void do_householdNumNewCheckBox_4_actionPerformed(ActionEvent e) {
	//enable the correct field
		nameTextField_1.setEnabled(isEnabled());
		relationshipComboBox_1.setEnabled(isEnabled());
		ageComboBox_1.setEnabled(isEnabled());
		HSSNformattedTextField_1.setEnabled(isEnabled());
						
		nameTextField_2.setEnabled(isEnabled());
		relationshipComboBox_2.setEnabled(isEnabled());
		ageComboBox_2.setEnabled(isEnabled());
		HSSNformattedTextField_2.setEnabled(isEnabled());
				
		nameTextField_3.setEnabled(isEnabled());
		relationshipComboBox_3.setEnabled(isEnabled());
		ageComboBox_3.setEnabled(isEnabled());
		HSSNformattedTextField_3.setEnabled(isEnabled());
		
		nameTextField_4.setEnabled(isEnabled());
		relationshipComboBox_4.setEnabled(isEnabled());
		ageComboBox_4.setEnabled(isEnabled());
		HSSNformattedTextField_4.setEnabled(isEnabled());
	//disable all incorrect fields	
		nameTextField_5.setEnabled(!isEnabled());
		relationshipComboBox_5.setEnabled(!isEnabled());
		ageComboBox_5.setEnabled(!isEnabled());
		HSSNformattedTextField_5.setEnabled(!isEnabled());
	}
	protected void do_householdNumNewCheckBox_5_actionPerformed(ActionEvent e) {
	//enable the correct field
		nameTextField_1.setEnabled(isEnabled());
		relationshipComboBox_1.setEnabled(isEnabled());
		ageComboBox_1.setEnabled(isEnabled());
		HSSNformattedTextField_1.setEnabled(isEnabled());
								
		nameTextField_2.setEnabled(isEnabled());
		relationshipComboBox_2.setEnabled(isEnabled());
		ageComboBox_2.setEnabled(isEnabled());
		HSSNformattedTextField_2.setEnabled(isEnabled());
						
		nameTextField_3.setEnabled(isEnabled());
		relationshipComboBox_3.setEnabled(isEnabled());
		ageComboBox_3.setEnabled(isEnabled());
		HSSNformattedTextField_3.setEnabled(isEnabled());
				
		nameTextField_4.setEnabled(isEnabled());
		relationshipComboBox_4.setEnabled(isEnabled());
		ageComboBox_4.setEnabled(isEnabled());
		HSSNformattedTextField_4.setEnabled(isEnabled());

		nameTextField_5.setEnabled(isEnabled());
		relationshipComboBox_5.setEnabled(isEnabled());
		ageComboBox_5.setEnabled(isEnabled());
		HSSNformattedTextField_5.setEnabled(isEnabled());
	}
	
	protected void do_chckbxNone_actionPerformed(ActionEvent e) {
		//disable all fields
		nameTextField_1.setEnabled(!isEnabled());
		relationshipComboBox_1.setEnabled(!isEnabled());
		ageComboBox_1.setEnabled(!isEnabled());
		HSSNformattedTextField_1.setEnabled(!isEnabled());
		
		nameTextField_2.setEnabled(!isEnabled());
		relationshipComboBox_2.setEnabled(!isEnabled());
		ageComboBox_2.setEnabled(!isEnabled());
		HSSNformattedTextField_2.setEnabled(!isEnabled());
		
		nameTextField_3.setEnabled(!isEnabled());
		relationshipComboBox_3.setEnabled(!isEnabled());
		ageComboBox_3.setEnabled(!isEnabled());
		HSSNformattedTextField_3.setEnabled(!isEnabled());
		
		nameTextField_4.setEnabled(!isEnabled());
		relationshipComboBox_4.setEnabled(!isEnabled());
		ageComboBox_4.setEnabled(!isEnabled());
		HSSNformattedTextField_4.setEnabled(!isEnabled());
		
		nameTextField_5.setEnabled(!isEnabled());
		relationshipComboBox_5.setEnabled(!isEnabled());
		ageComboBox_5.setEnabled(!isEnabled());
		HSSNformattedTextField_5.setEnabled(!isEnabled());
	}
	protected void do_chckbxEmployed_actionPerformed(ActionEvent e) {
		if(!POETextField.isEnabled()) {
			POETextField.setEnabled(isEnabled());
		}
		
	}
	protected void do_chckbxUneployed_actionPerformed(ActionEvent e) {
		if(POETextField.isEnabled()) {
			POETextField.setEnabled(!isEnabled());
			POETextField.setText("");
		}
		
	}
	
//property changes to call the sum functions for expenses and adjust the color of the number if positive or negative	
	protected void do_SalaryFormattedTextField_propertyChange(PropertyChangeEvent arg0) {
		sumDoerIncome();
		double temp = ((Number)SalaryFormattedTextField.getValue()).doubleValue();
		if(temp < 0) {
			SalaryFormattedTextField.setForeground(Color.red);
		}
		else {
			SalaryFormattedTextField.setForeground(Color.white);
		}
	}
	protected void do_unemploymentFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)unemploymentFTF.getValue()).doubleValue();
		if(temp < 0) {
			unemploymentFTF.setForeground(Color.red);
		}
		else {
			unemploymentFTF.setForeground(Color.white);
		}
	}
	protected void do_TAFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)TAFTF.getValue()).doubleValue();
		if(temp < 0) {
			TAFTF.setForeground(Color.red);
		}
		else {
			TAFTF.setForeground(Color.white);
		}
	}
	protected void do_socialSecurityFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)socialSecurityFTF.getValue()).doubleValue();
		if(temp < 0) {
			socialSecurityFTF.setForeground(Color.red);
		}
		else {
			socialSecurityFTF.setForeground(Color.white);
		}
	}
	protected void do_disabilityFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)disabilityFTF.getValue()).doubleValue();
		if(temp < 0) {
			disabilityFTF.setForeground(Color.red);
		}
		else {
			disabilityFTF.setForeground(Color.white);
		}
	}
	protected void do_childSupportFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)childSupportFTF.getValue()).doubleValue();
		if(temp < 0) {
			childSupportFTF.setForeground(Color.red);
		}
		else {
			childSupportFTF.setForeground(Color.white);
		}
	}
	protected void do_utilityAssistanceFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)utilityAssistanceFTF.getValue()).doubleValue();
		if(temp < 0) {
			utilityAssistanceFTF.setForeground(Color.red);
		}
		else {
			utilityAssistanceFTF.setForeground(Color.white);
		}
	}
	protected void do_foodStampsFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)foodStampsFTF.getValue()).doubleValue();
		if(temp < 0) {
			foodStampsFTF.setForeground(Color.red);
		}
		else {
			foodStampsFTF.setForeground(Color.white);
		}
	}
	protected void do_incomeOtherFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerIncome();
		double temp = ((Number)incomeOtherFTF.getValue()).doubleValue();
		if(temp < 0) {
			incomeOtherFTF.setForeground(Color.red);
		}
		else {
			incomeOtherFTF.setForeground(Color.white);
		}
	}
//property changes to call the sum functions for expenses
	protected void do_rentFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)rentFTF.getValue()).doubleValue();
		if(temp > 0) {
			rentFTF.setForeground(Color.white);
		}
		else {
			rentFTF.setForeground(Color.red);
		}
	}
	protected void do_phoneBillFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)phoneBillFTF.getValue()).doubleValue();
		if(temp > 0) {
			phoneBillFTF.setForeground(Color.white);
		}
		else {
			phoneBillFTF.setForeground(Color.red);
		}
	}
	protected void do_gasWaterBillFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)gasWaterBillFTF.getValue()).doubleValue();
		if(temp > 0) {
			gasWaterBillFTF.setForeground(Color.white);
		}
		else {
			gasWaterBillFTF.setForeground(Color.red);
		}
	}
	protected void do_lightBillFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)lightBillFTF.getValue()).doubleValue();
		if(temp > 0) {
			lightBillFTF.setForeground(Color.white);
		}
		else {
			lightBillFTF.setForeground(Color.red);
		}
	}
	protected void do_carPaymentFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)carPaymentFTF.getValue()).doubleValue();
		if(temp > 0) {
			carPaymentFTF.setForeground(Color.white);
		}
		else {
			carPaymentFTF.setForeground(Color.red);
		}
	}
	protected void do_furnAppliancesFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)furnAppliancesFTF.getValue()).doubleValue();
		if(temp > 0) {
			furnAppliancesFTF.setForeground(Color.white);
		}
		else {
			furnAppliancesFTF.setForeground(Color.red);
		}
	}
	protected void do_cableTVFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)cableTVFTF.getValue()).doubleValue();
		if(temp > 0) {
			cableTVFTF.setForeground(Color.white);
		}
		else {
			cableTVFTF.setForeground(Color.red);
		}
	}
	protected void do_doctorMedicalFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)doctorMedicalFTF.getValue()).doubleValue();
		if(temp > 0) {
			doctorMedicalFTF.setForeground(Color.white);
		}
		else {
			doctorMedicalFTF.setForeground(Color.red);
		}
	}
	protected void do_expenseOtherFTF_propertyChange(PropertyChangeEvent evt) {
		sumDoerExpense();
		double temp = ((Number)expenseOtherFTF.getValue()).doubleValue();
		if(temp > 0) {
			expenseOtherFTF.setForeground(Color.white);
		}
		else {
			expenseOtherFTF.setForeground(Color.red);
		}
	}
	
	//handles the adding and setting for the sum for financial tab for income and separate for income fields
	protected void sumDoerIncome() {
			num1Income = ((Number)SalaryFormattedTextField.getValue()).doubleValue();
			num2Income = ((Number)unemploymentFTF.getValue()).doubleValue();
			num3Income = ((Number)TAFTF.getValue()).doubleValue();
			num4Income = ((Number)socialSecurityFTF.getValue()).doubleValue();
			num5Income = ((Number)disabilityFTF.getValue()).doubleValue();
			num6Income = ((Number)childSupportFTF.getValue()).doubleValue();
			num7Income = ((Number)utilityAssistanceFTF.getValue()).doubleValue();
			num8Income = ((Number)foodStampsFTF.getValue()).doubleValue();
			num9Income = ((Number)incomeOtherFTF.getValue()).doubleValue();
			
			sumIncome = num1Income + num2Income + num3Income + num4Income + num5Income + num6Income + num7Income + num8Income + num9Income;
			incomeSumFTF.setValue(sumIncome);
			
			if(sumIncome < 0) {
				incomeSumFTF.setForeground(Color.RED);
			}//if
			else {
				incomeSumFTF.setForeground(Color.white);
			}//else
			
		}//sumDoerIncome
	//handles the adding and setting for the sum for financial tab for income and separate for expense fields	
	private void sumDoerExpense() {
			num11Expense = ((Number)rentFTF.getValue()).doubleValue();
			num12Expense = ((Number)phoneBillFTF.getValue()).doubleValue();
			num13Expense = ((Number)gasWaterBillFTF.getValue()).doubleValue();
			num14Expense = ((Number)lightBillFTF.getValue()).doubleValue();
			num15Expense = ((Number)carPaymentFTF.getValue()).doubleValue();
			num16Expense = ((Number)furnAppliancesFTF.getValue()).doubleValue();
			num17Expense = ((Number)cableTVFTF.getValue()).doubleValue();
			num18Expense = ((Number)doctorMedicalFTF.getValue()).doubleValue();
			num19Expense = ((Number)expenseOtherFTF.getValue()).doubleValue();
			
			sumExpense = num11Expense + num12Expense + num13Expense + num14Expense + num15Expense + num16Expense + num17Expense + num18Expense + num19Expense;
			expenseSumFTF.setValue(sumExpense);
			
			if(sumExpense < 0) {
				expenseSumFTF.setForeground(Color.RED);
			}//if
			else {
				expenseSumFTF.setForeground(Color.white);
			}//else
		}//sumDoer
	
	protected void do_incomeSumFTF_propertyChange(PropertyChangeEvent evt) {
		 double temp1 = ((Number)expenseSumFTF.getValue()).doubleValue();
		 double temp2 = ((Number)incomeSumFTF.getValue()).doubleValue();
		 ttlNetIncome = temp2 - temp1;
		 totalNetIncome.setValue(ttlNetIncome);
		 
		 if(ttlNetIncome < 0) {
			 totalNetIncome.setForeground(Color.RED);
			}//if
			else {
				totalNetIncome.setForeground(Color.white);
			}//else
	}
	protected void do_expenseSumFTF_propertyChange(PropertyChangeEvent evt) {
		 double temp1 = ((Number)expenseSumFTF.getValue()).doubleValue();
		 double temp2 = ((Number)incomeSumFTF.getValue()).doubleValue();
		 ttlNetIncome = temp2 - temp1;
		 totalNetIncome.setValue(ttlNetIncome);
		 
		 if(ttlNetIncome < 0) {
			 totalNetIncome.setForeground(Color.RED);
			}//if
			else {
				totalNetIncome.setForeground(Color.white);
			}//else
	}		
			

	protected void do_SocialSecuirtyFormattedTextField_focusLost(FocusEvent e) {
		String SSN = SocialSecuirtyFormattedTextField.getText();
		 if(SSN.indexOf('#')>=0) {
			 lblSocialSecurity.setForeground(Color.red);
			 JOptionPane.showMessageDialog(this, "You Must Input a SSN To Complete The Form", "Error Message", JOptionPane.ERROR_MESSAGE);
			 //DOBFormattedTextField.grabFocus();
		 }
		 else {
			 lblSocialSecurity.setForeground(Color.white);
		 }
	}
	protected void do_spouseSSNFormattedTextField_focusLost(FocusEvent e) {
		String SSNSpouse = spouseSSNFormattedTextField.getText();
		 if(SSNSpouse.indexOf('#')>=0) {
			 lblSpouseSocialSecurity.setForeground(Color.red);
			 JOptionPane.showMessageDialog(this, "You Must Input a Spouse SSN To Complete The Form ", "Error Message", JOptionPane.ERROR_MESSAGE);
			 //DOBFormattedTextField.grabFocus();
		 }
		 else {
			 lblSpouseSocialSecurity.setForeground(Color.white);
		 }
	}
	//check variables when switching between tabs
	protected void do_tabbedPane_stateChanged(ChangeEvent arg0) {
		
		if(FirstNameTextField.getText().isEmpty()) {
			lblFirstName.setForeground(Color.red);
		}
		else {
			lblFirstName.setForeground(Color.white);
		}//firstName
		
		if(LastNameTextField.getText().isEmpty()) {
			lblLastName.setForeground(Color.red);
		}
		else {
			lblLastName.setForeground(Color.white);
		}//lastName
		
		String DOB = DOBFormattedTextField.getText();
		 if(DOB.indexOf('#')>=0) {
			lblDateOfBirth.setForeground(Color.red);
		}
		else {
			lblDateOfBirth.setForeground(Color.white);
		}//DOB
		 
		 if(AddressTextField.getText().isEmpty()) {
			    lblAddress.setForeground(Color.red);
			}
			else {
				lblAddress.setForeground(Color.white);
			}//address
		 
		 if(CityTextField.getText().isEmpty()) {
			    lblCity.setForeground(Color.red);
			}
			else {
				lblCity.setForeground(Color.white);
			}//city
		 
		 String Zip = ZipFormattedTextField.getText();
		 if(Zip.indexOf('#')>=0) {
			    lblZip.setForeground(Color.red);
			}
			else {
				lblZip.setForeground(Color.white);
			}//zip
		 
		 String phone = PhoneFormattedTextField.getText();
		 if(phone.indexOf('#')>=0) {
			 	lblPhoneNumber.setForeground(Color.red);
			}
			else {
				lblPhoneNumber.setForeground(Color.white);
			}//phone#
		 
		 String ssn = SocialSecuirtyFormattedTextField.getText();
		 if(ssn.indexOf('#')>=0) {
			 	lblSocialSecurity.setForeground(Color.red);
			}
			else {
				lblSocialSecurity.setForeground(Color.white);
			}//SSN#
		 
		 if(spouseNametxtField.getText().isEmpty()) {
			 	lblSpouseName.setForeground(Color.red);
			}
			else {
				lblSpouseName.setForeground(Color.white);
			}//spouseName
		 
		 String DOB1 = spouseDOBFTF.getText();
		 if(DOB1.indexOf('#')>=0) {
			 	lblSpouseDOB.setForeground(Color.red);
			}
			else {
				lblSpouseDOB.setForeground(Color.white);
			}
		 
		 String ssn1 = spouseSSNFormattedTextField.getText();
		 if(ssn1.indexOf('#')>=0) {
			 	lblSpouseSocialSecurity.setForeground(Color.red);
			}
			else {
				lblSpouseSocialSecurity.setForeground(Color.white);
			}//SSN#
	}
	protected void do_spouseDOBFTF_focusLost(FocusEvent e) {
		String ssn = spouseDOBFTF.getText();
		 if(ssn.indexOf('#')>=0) {
			 	lblSpouseDOB.setForeground(Color.red);
			}
			else {
				lblSpouseDOB.setForeground(Color.white);
			}
	}
	protected void do_chckbxNotMarried_actionPerformed(ActionEvent arg0) {
		spouseNametxtField.setEnabled(!isEnabled());
		spouseDOBFTF.setEnabled(!isEnabled());
		spouseSSNFormattedTextField.setEnabled(!isEnabled());
		
	}
	protected void do_chckbxMarried_actionPerformed(ActionEvent e) {
		spouseNametxtField.setEnabled(isEnabled());
		spouseDOBFTF.setEnabled(isEnabled());
		spouseSSNFormattedTextField.setEnabled(isEnabled());
	}
}
