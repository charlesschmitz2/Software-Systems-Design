import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class SchmitzDialogFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblName = new JLabel("Name : ");
	private final JLabel lblResult = new JLabel("Result : ");
	private final JButton btnResult = new JButton("Show");
	private final JTextField nameTextField = new JTextField();
	private final JButton btnExit = new JButton("Exit");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchmitzDialogFrame frame = new SchmitzDialogFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchmitzDialogFrame() {
		nameTextField.setBounds(122, 96, 390, 32);
		nameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 664, 598);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblName.setBounds(44, 99, 92, 26);
		
		contentPane.add(lblName);
		lblResult.setBounds(44, 171, 495, 26);
		
		contentPane.add(lblResult);
		btnResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnResult_actionPerformed(arg0);
			}
		});
		btnResult.setBounds(105, 308, 141, 35);
		
		contentPane.add(btnResult);
		
		contentPane.add(nameTextField);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnExit_actionPerformed(arg0);
			}
		});
		btnExit.setBounds(371, 308, 141, 35);
		
		contentPane.add(btnExit);
	}
	protected void do_btnResult_actionPerformed(ActionEvent arg0){
		if(nameTextField.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please Enter a Name", "Empty Text Error", JOptionPane.ERROR_MESSAGE);
		}//if
		else {
			lblResult.setText("Result : " + nameTextField.getText());
		}//else
	}//button action performed result
	protected void do_btnExit_actionPerformed(ActionEvent arg0) {
		//clean-up stuff here, if necessary
		//DEFAULT_OPTION
		//YES_NO_OPTION
		//YES_NO_CANCEL_OPTION
		//OK_CANCEL_OPTION
		Object[] options = { "Ya", "Nah"};
		if(JOptionPane.showConfirmDialog(this, "Are you Sure you Would like to Exit the Program?", "Exit Message", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {	
			if(JOptionPane.showOptionDialog(this, "You sure Bro?", "BRO EXIT MESSAGE", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0])==JOptionPane.YES_OPTION) {
					this.dispose();
			}
		}//if
		
		//add more dialog options
		
	}
}
